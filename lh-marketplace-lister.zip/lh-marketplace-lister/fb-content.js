/* Runs on facebook.com. On the Marketplace vehicle composer it shows a small
 * panel that fills the "Vehicle for sale" form from a saved vehicle.
 * It never clicks Next or Publish: you review and publish yourself. */
(() => {
  if (window.__lhmlLoaded) return;
  window.__lhmlLoaded = true;

  const COMPOSER = /^\/marketplace\/create\/vehicle/;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const visible = (el) => !!(el && el.getClientRects().length);
  const PANEL_ID = 'lhml-panel';
  const inPanel = (el) => !!el.closest('#' + PANEL_ID);

  const ALIASES = {
    Gray: ['Gray', 'Grey'],
    'Automatic transmission': ['Automatic transmission', 'Automatic'],
    'Manual transmission': ['Manual transmission', 'Manual'],
    Gasoline: ['Gasoline', 'Petrol'],
    'Small Car': ['Small Car', 'Small car'],
  };

  // ---------- field helpers ----------
  function leafText(el) {
    const a = el.getAttribute('aria-label');
    if (a) return a;
    for (const s of el.querySelectorAll('span')) {
      if (!s.children.length && s.textContent.trim()) return s.textContent.trim();
    }
    return '';
  }

  function findField(label) {
    const want = norm(label);
    const els = [...document.querySelectorAll('label, [role="combobox"]')].filter((e) => visible(e) && !inPanel(e));
    return els.find((e) => norm(leafText(e)) === want) || els.find((e) => norm(leafText(e)).startsWith(want)) || null;
  }

  async function waitFor(fn, timeout = 6000, step = 120) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  function setNativeValue(input, value) {
    const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  async function typeInto(input, value) {
    value = String(value);
    input.focus();
    input.click();
    await sleep(60);
    input.select && input.select();
    document.execCommand('selectAll', false, null);
    let ok = false;
    try { ok = document.execCommand('insertText', false, value); } catch (e) {}
    await sleep(60);
    if (!ok || !norm(input.value).includes(norm(value).slice(0, 40))) setNativeValue(input, value);
    await sleep(80);
  }

  async function setText(label, value) {
    if (value === '' || value == null) return 'skipped (empty)';
    const f = await waitFor(() => findField(label), 4000);
    if (!f) throw new Error('field not on the page');
    const input = f.matches('input, textarea') ? f : f.querySelector('input, textarea');
    if (!input) throw new Error('no text box in field');
    await typeInto(input, value);
    input.blur();
    return String(value).length > 40 ? 'filled' : String(value);
  }

  function optionsFor(box) {
    const id = box.getAttribute('aria-controls');
    const lb = id ? document.getElementById(id) : null;
    if (lb) return [...lb.querySelectorAll('[role="option"]')];
    // Fallback: the visible listbox.
    const vis = [...document.querySelectorAll('[role="listbox"]')].filter(visible).pop();
    return vis ? [...vis.querySelectorAll('[role="option"]')] : [];
  }

  async function choose(label, value) {
    if (!value) {
      if (/color/i.test(label)) throw new Error('no color yet. Pick one, or add a Gemini key so the AI reads it from the photos');
      return 'skipped (no value)';
    }
    const box = await waitFor(() => findField(label), 5000);
    if (!box) throw new Error('field not on the page');
    const cands = (ALIASES[value] || [value]).map(norm);
    const matchIn = (opts) =>
      opts.find((o) => cands.includes(norm(o.textContent))) ||
      opts.find((o) => cands.some((c) => c && norm(o.textContent).startsWith(c)));

    const close = () => {
      if (box.getAttribute('aria-expanded') === 'true') box.click();
      document.activeElement && document.activeElement.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    };
    let opt = null;
    // Two tries: sometimes the list opens empty the first time.
    for (let t = 0; t < 2 && !opt; t++) {
      if (box.getAttribute('aria-expanded') !== 'true') box.click();
      opt = await waitFor(() => matchIn(optionsFor(box)), 3000);
      if (!opt) { close(); await sleep(400); }
    }
    if (!opt) {
      close();
      throw new Error(`"${value}" is not one of the choices`);
    }
    opt.scrollIntoView({ block: 'nearest' });
    await sleep(60);
    opt.click();
    await sleep(250);
    if (box.getAttribute('aria-expanded') === 'true') box.click();
    return opt.textContent.trim();
  }

  async function setCheckbox(ariaStart, checked) {
    const cb = [...document.querySelectorAll('input[type="checkbox"], [role="checkbox"]')].find((c) =>
      norm(c.getAttribute('aria-label')).startsWith(norm(ariaStart))
    );
    if (!cb) throw new Error('checkbox not on the page');
    const isOn = cb.getAttribute('aria-checked') === 'true' || cb.checked === true;
    if (isOn !== !!checked) { (cb.closest('label') || cb).click(); await sleep(200); }
    return checked ? 'checked' : 'left unchecked';
  }

  async function setLocation(value) {
    if (!value) return 'skipped (empty)';
    const input = document.querySelector('input[aria-label="Location"]') || (findField('Location') || {}).querySelector?.('input');
    if (!input) throw new Error('field not on the page');
    await typeInto(input, value);
    const id = input.getAttribute('aria-controls');
    const opt = await waitFor(() => {
      const lb = id && document.getElementById(id);
      const opts = lb ? [...lb.querySelectorAll('[role="option"]')] : [...document.querySelectorAll('[role="listbox"] [role="option"]')].filter(visible);
      return opts[0];
    }, 4000);
    if (!opt) throw new Error('no location suggestion appeared');
    opt.click();
    await sleep(250);
    return opt.textContent.trim();
  }

  // ---------- photos ----------
  function dataUrlToBlob(dataUrl) {
    const [head, b64] = dataUrl.split(',');
    const type = (head.match(/data:([^;]+)/) || [])[1] || 'image/jpeg';
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type });
  }

  async function addPhotos(images, report) {
    if (!images.length) return 'no photos selected';
    const input = [...document.querySelectorAll('input[type="file"]')].find((i) => /image/.test(i.accept || ''));
    if (!input) throw new Error('photo upload box not found');
    const files = new Array(images.length);
    let done = 0, failed = 0;
    let next = 0;
    const worker = async () => {
      while (next < images.length) {
        const i = next++;
        const r = await chrome.runtime.sendMessage({ type: 'fetchImage', url: images[i].url, fallback: images[i].fallback, local: images[i].local, cloud: images[i].cloud });
        if (r && r.ok) {
          const removeBanner = settingsCache.removeBanner !== false;
          const jpg = await LHImage.finalize(dataUrlToBlob(r.dataUrl), removeBanner ? images[i].cropTop || 0 : 0);
          files[i] = new File([jpg], `photo-${String(i + 1).padStart(2, '0')}.jpg`, { type: 'image/jpeg' });
        } else failed++;
        done++;
        report(`downloading ${done}/${images.length}`);
      }
    };
    await Promise.all([worker(), worker(), worker(), worker()]);
    const dt = new DataTransfer();
    files.filter(Boolean).forEach((f) => dt.items.add(f));
    if (!dt.files.length) throw new Error('none of the photos downloaded');
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    return `${dt.files.length} added${failed ? `, ${failed} failed` : ''}`;
  }

  // ---------- panel ----------
  let panel, logEl, selectEl, running = false;

  function log(name, state, detail) {
    let row = logEl.querySelector(`[data-step="${CSS.escape(name)}"]`);
    if (!row) {
      row = document.createElement('li');
      row.dataset.step = name;
      row.innerHTML = '<span class="ic"></span><span class="nm"></span><span class="dt"></span>';
      row.querySelector('.nm').textContent = name;
      logEl.appendChild(row);
    }
    row.className = state;
    row.querySelector('.ic').textContent = state === 'ok' ? '✓' : state === 'err' ? '!' : state === 'skip' ? '–' : '…';
    row.querySelector('.dt').textContent = detail || '';
  }

  async function step(name, fn) {
    await sleep(350 + Math.random() * 650); // human pace between fields
    log(name, 'run');
    try {
      const res = await fn((d) => log(name, 'run', d));
      log(name, /^skipped|^left/.test(res) ? 'skip' : 'ok', res);
    } catch (e) {
      log(name, 'err', e.message || String(e));
    }
  }

  // fromApp: opened by the app's Post button (or Auto post), so it publishes by itself.
  async function fill(listing, settings, only, fromApp = false) {
    const publish = only === null && (settings.autoPost || (fromApp && settings.publishOnPost !== false));
    if (running) return;
    running = true;
    panel.querySelectorAll('button').forEach((b) => (b.disabled = true));
    logEl.innerHTML = '';
    const fb = listing.fb;
    const photos = (listing.images || []).filter((i) => i.on).slice(0, settings.maxPhotos || 20);
    try {
      if (only === 'photos') { await step('Photos', (r) => addPhotos(photos, r)); return; }
      await step('Vehicle type', () => choose('Vehicle type', fb.vehicleType || 'Car/Truck'));
      await waitFor(() => findField('Mileage'), 5000);
      // VIN is optional: Facebook decodes it and can add its own (sometimes wrong)
      // specs like engine size. Filled first so our values win for the fields below.
      if (settings.fillVin && fb.vin) { await step('VIN', () => setText('VIN', fb.vin)); await sleep(1200); }
      const photoJob = only === 'details' ? null : step('Photos', (r) => addPhotos(photos, r));
      if (settings.fillLocation) await step('Location', () => setLocation(fb.location));
      await step('Year', () => choose('Year', String(fb.year)));
      await step('Make', async () => {
        const box = findField('Make');
        if (box && box.querySelector('input')) return setText('Make', fb.make);
        return choose('Make', fb.make);
      });
      await step('Model', () => setText('Model', fb.model));
      await step('Mileage', () => setText('Mileage', fb.mileage));
      await step('Price', () => setText('Price', fb.price));
      await step('Body style', () => choose('Body style', fb.bodyStyle));
      await step('Exterior color', () => choose('Exterior color', fb.exteriorColor));
      await step('Interior color', () => choose('Interior color', fb.interiorColor));
      await step('Clean title', () => setCheckbox('This vehicle has a clean title', fb.cleanTitle));
      await step('Condition', () => choose('Vehicle condition', fb.condition));
      await step('Fuel type', () => choose('Fuel type', fb.fuelType));
      await step('Transmission', () => choose('Transmission', fb.transmission));
      await step('Description', () => setText('Description', fb.description));
      if (photoJob) await photoJob;
      const errs = logEl.querySelectorAll('li.err').length;
      // Auto post needs Facebook's must-have fields; a missed optional one (say interior color) is OK.
      const MUST = ['Vehicle type', 'Year', 'Make', 'Model', 'Mileage', 'Price', 'Photos', 'Exterior color', 'Interior color'];
      const blocking = [...logEl.querySelectorAll('li.err')].map((li) => li.dataset.step).filter((s) => MUST.includes(s));
      const foot = panel.querySelector('.lhml-foot');
      if (publish && blocking.length) {
        foot.textContent = `Couldn't publish by itself: ${blocking.join(', ')} didn't fill. Fix ${blocking.length > 1 ? 'them' : 'it'}, then publish yourself.`;
        chrome.runtime.sendMessage({ type: 'needYou', id: listing.id, why: `${blocking.join(', ')} didn't fill` }).catch(() => {});
      } else if (publish) {
        foot.textContent = 'Publishing…';
        await step('Publish', (r) => autoPublish(listing, r));
        const failed = logEl.querySelector('li.err[data-step="Publish"]');
        foot.textContent = failed ? 'Could not publish automatically. Check the form and publish it yourself.' : 'Published. This tab closes by itself.';
        if (failed) chrome.runtime.sendMessage({ type: 'needYou', id: listing.id, why: "Facebook didn't take the Publish click" }).catch(() => {});
      } else {
        foot.textContent = errs
          ? `Done. ${errs} field${errs > 1 ? 's' : ''} need a quick look, then review and publish.`
          : 'Done. Review the listing, then publish it yourself.';
      }
    } finally {
      running = false;
      if (panel) panel.querySelectorAll('button').forEach((b) => (b.disabled = false));
    }
  }

  let settingsCache = {};
  async function getData() {
    const d = await chrome.storage.local.get(['listings', 'settings']);
    settingsCache = { maxPhotos: 20, fillLocation: false, autoFill: true, fillVin: false, removeBanner: true, autoPost: false, ...(d.settings || {}) };
    return { listings: d.listings || [], settings: settingsCache };
  }

  async function mount() {
    if (document.getElementById(PANEL_ID)) return;
    const { listings, settings } = await getData();
    const mine = await chrome.runtime.sendMessage({ type: 'myListing' }).catch(() => null);
    const pending = mine && mine.pending ? { id: mine.pending } : null;
    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="lhml-head"><strong>LH Marketplace Lister</strong><button class="lhml-min" title="Minimize">–</button></div>
      <div class="lhml-body">
        <select class="lhml-select"></select>
        <div class="lhml-actions">
          <button class="lhml-primary" data-act="all">Autofill</button>
          <button data-act="details">Details only</button>
          <button data-act="photos">Photos only</button>
        </div>
        <ul class="lhml-log"></ul>
        <div class="lhml-foot">Nothing gets published until you click Publish.</div>
      </div>`;
    document.body.appendChild(panel);
    logEl = panel.querySelector('.lhml-log');
    selectEl = panel.querySelector('.lhml-select');
    const active = listings.filter((l) => l.status !== 'posted');
    const list = active.length ? active : listings;
    if (!list.length) {
      selectEl.innerHTML = '<option value="">No vehicles yet. Import one in the app.</option>';
    } else {
      list.forEach((l) => {
        const o = document.createElement('option');
        o.value = l.id;
        o.textContent = `${l.fb.year} ${l.fb.make} ${l.fb.model}${l.fb.price ? ' · $' + Number(l.fb.price).toLocaleString() : ''}`;
        selectEl.appendChild(o);
      });
      if (pending && list.some((l) => l.id === pending.id)) selectEl.value = pending.id;
    }
    panel.querySelector('.lhml-min').onclick = () => panel.classList.toggle('min');
    watchManualPublish();
    panel.querySelectorAll('[data-act]').forEach((b) => {
      b.onclick = async () => {
        const d = await getData();
        const l = d.listings.find((x) => x.id === selectEl.value);
        if (!l) return;
        fill(l, d.settings, b.dataset.act === 'all' ? null : b.dataset.act);
      };
    });

    // Auto run when opened from the app.
    if (pending && settings.autoFill) {
      const l = listings.find((x) => x.id === pending.id);
      if (l) {
        await waitFor(() => findField('Vehicle type'), 15000, 250);
        await sleep(800);
        fill(l, settings, null, true);
      }
    }
  }

  // ---------- "Posted" confirmation ----------
  // When you click Publish yourself, watch for Facebook leaving the form, then mark the car posted.
  let publishWatch = false, watching = false;
  function watchManualPublish() {
    if (watching) return;
    watching = true;
    document.addEventListener('click', (e) => {
      const b = e.target.closest && e.target.closest('[role="button"], button');
      if (!b || inPanel(b) || !labelMatches(b, /^Publish$/) || publishWatch) return;
      const id = selectEl && selectEl.value;
      if (!id) return;
      publishWatch = true;
      (async () => {
        const left = await waitFor(() => !COMPOSER.test(location.pathname), 60000, 800);
        publishWatch = false;
        if (left) await postedDone(id);
      })();
    }, true);
  }
  async function postedDone(id) {
    const { listings = [] } = await chrome.storage.local.get('listings');
    const l = listings.find((x) => x.id === id);
    const name = l ? `${l.fb.year} ${l.fb.make} ${l.fb.model}` : 'Your car';
    await chrome.runtime.sendMessage({ type: 'markPosted', id }).catch(() => {});
    let box = document.getElementById('lhml-done');
    if (!box) { box = document.createElement('div'); box.id = 'lhml-done'; document.body.appendChild(box); }
    box.innerHTML = '<div class="lhml-done-card"><div class="lhml-done-check">✓</div><strong>Posted complete</strong><span></span><button type="button">OK</button></div>';
    box.querySelector('span').textContent = `${name} is live on Marketplace.`;
    box.querySelector('button').onclick = () => box.remove();
    if (panel) panel.remove();
    panel = null;
    setTimeout(() => box && box.remove(), 8000);
  }

  // ---------- auto post ----------
  // Facebook buttons often carry the same word as label AND text ("Next" + "Next"),
  // so test each one on its own.
  const labelMatches = (b, re) => re.test((b.getAttribute('aria-label') || '').trim()) || re.test((b.innerText || '').trim());
  const enabled = (b) => b.getAttribute('aria-disabled') !== 'true' && !b.disabled;
  const btnByText = (re) =>
    [...document.querySelectorAll('[role="button"], button')].find((b) => visible(b) && !inPanel(b) && labelMatches(b, re) && enabled(b));

  async function autoPublish(listing, report) {
    const want = (listing.images || []).filter((i) => i.on).slice(0, settingsCache.maxPhotos || 20).length;
    if (want) {
      report('waiting for photos to upload');
      // Facebook shows "Photos · N / 20" once uploads are in.
      await waitFor(() => { const m = document.body.innerText.match(/Photos\s*·\s*(\d+)\s*\/\s*\d+/); return m && +m[1] >= Math.min(want, 20) - 1; }, 90000, 1000);
      await sleep(4000);
    }
    report('clicking Next');
    const next = await waitFor(() => btnByText(/^Next$/), 60000, 1000);
    if (!next) throw new Error('Next button never became clickable');
    next.click();
    report('clicking Publish');
    const pub = await waitFor(() => btnByText(/^Publish$/), 30000, 800);
    if (!pub) throw new Error('Publish button not found');
    await sleep(1200);
    pub.click();
    const left = await waitFor(() => !/^\/marketplace\/create/.test(location.pathname), 45000, 1000);
    if (!left) throw new Error('Facebook did not confirm the post');
    publishWatch = true; // the click watcher shouldn't report it twice
    setTimeout(() => postedDone(listing.id), 300);
    return 'published';
  }

  // ---------- renew ----------
  // facebook.com/marketplace/selling/renew_listings/ shows a "Renew listings" box
  // with one row per listing that's ready, each with its own Renew button.
  const RENEW = /^\/marketplace\/selling\/renew_listings/;
  function renewRows() {
    const dlg = [...document.querySelectorAll('[role="dialog"]')].filter(visible).find((d) => /Renew listings/i.test(d.innerText)) || document.querySelector('[role="main"]');
    if (!dlg) return [];
    const btns = [...dlg.querySelectorAll('[role="button"], button')].filter((b) => visible(b) && labelMatches(b, /^Renew$/i));
    return btns.map((b) => {
      // The row: biggest box around this button that holds no other Renew button.
      let row = b;
      while (row.parentElement && row.parentElement !== dlg && [...row.parentElement.querySelectorAll('[role="button"], button')].filter((x) => labelMatches(x, /^Renew$/i)).length === 1) row = row.parentElement;
      const lines = textOf(row).split('\n').map((x) => x.trim()).filter((x) => x && !/^Renew$/i.test(x));
      const title = lines.find((x) => !/^\$[\d,]+/.test(x)) || '';
      const price = +(((lines.find((x) => /^\$[\d,]+/.test(x)) || '').match(/[\d,]+/) || ['0'])[0].replace(/,/g, ''));
      return { btn: b, title, price };
    });
  }

  async function renewListings(job) {
    await waitFor(() => renewRows().length || /no listings|nothing to renew|all caught up/i.test(document.body.innerText) || (openDialogs().length && /Renew listings/i.test(document.body.innerText)), 20000, 500);
    await sleep(1500);
    const carsOnly = job.carsOnly !== false;
    const only = job.titles && job.titles.length ? new Set(job.titles) : null;
    const renewed = [], skipped = [];
    for (const r of renewRows()) {
      const isCar = /^\d{4}\s/.test(r.title);
      if ((carsOnly && !isCar) || (only && !only.has(r.title))) { skipped.push(r.title); continue; }
      r.btn.scrollIntoView({ block: 'center' });
      r.btn.click();
      // The button changes (Renewed) or goes away once Facebook accepts it.
      const ok = await waitFor(() => !document.contains(r.btn) || !labelMatches(r.btn, /^Renew$/i) || !enabled(r.btn), 8000, 300);
      renewed.push(ok ? r.title : `${r.title} (not confirmed)`);
      if (renewed.length >= (job.max || 10)) break;
      await sleep(6000 + Math.random() * 9000); // human pace between renews
    }
    return { renewed, skipped };
  }

  // ---------- selling page: sync and listing actions ----------
  // Old page: /marketplace/you/selling (cards). New page (Oct 2026): /marketplace/seller/listings (a table with tabs).
  const SELLING = /^\/marketplace\/(you\/selling|seller\/listings)/;
  const EDIT = /^\/marketplace\/edit\//;

  // Listing ids and photos from the data Facebook embeds in the page.
  function embeddedListings() {
    const out = {};
    document.querySelectorAll('script[type="application/json"]').forEach((sc) => {
      const t = sc.textContent;
      if (!t.includes('marketplace_listing_title')) return;
      try {
        const walk = (o, d = 0) => {
          if (!o || typeof o !== 'object' || d > 60) return;
          if (Array.isArray(o)) return o.forEach((x) => walk(x, d + 1));
          if (o.marketplace_listing_title && o.id) {
            const photo = o.primary_listing_photo && (o.primary_listing_photo.image ? o.primary_listing_photo.image.uri : o.primary_listing_photo.listing_image && o.primary_listing_photo.listing_image.uri);
            out[o.marketplace_listing_title] = out[o.marketplace_listing_title] || [];
            const views = o.listing_insights && o.listing_insights.views && o.listing_insights.views[0] && o.listing_insights.views[0].count;
            const lp = o.listing_price && (o.listing_price.formatted_amount || o.listing_price.amount_with_offset_in_currency);
            out[o.marketplace_listing_title].push({ id: o.id, photo: photo || '', price: (o.formatted_price && o.formatted_price.text) || (lp ? String(lp) : ''), clicks: views == null ? null : views });
          }
          for (const k in o) walk(o[k], d + 1);
        };
        walk(JSON.parse(t));
      } catch (e) {}
    });
    return out;
  }

  const MORE = '[aria-label^="More options for "], [aria-label^="More actions for "]';
  const titleOfBtn = (b) => (b.getAttribute('aria-label') || '').replace(/^More (options|actions) for /, '').trim();
  const isTable = () => !!document.querySelector('[role="grid"] [role="row"] [aria-label^="More actions for "]');
  // Column number of a table header, e.g. "Clicks".
  function colIndex(name) {
    const h = [...document.querySelectorAll('[role="columnheader"]')].find((x) => x.innerText.trim().toLowerCase() === name.toLowerCase());
    return h ? h.getAttribute('aria-colindex') : null;
  }
  // Text of a card even when Facebook has stopped drawing it (off screen).
  const textOf = (el) => {
    const parts = [];
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) { const s = n.nodeValue.trim(); if (s) parts.push(s); }
    return parts.join('\n');
  };
  // Group inventory listings say "In stock" / "Out of stock" instead.
  const STATUS_RE = /(^|\n)(Active|Sold|Pending|In stock|Out of stock)(\n|$)/;
  const STATUS_MAP = { 'In stock': 'Active', 'Out of stock': 'Sold' };

  // The biggest box around this button that holds no other listing.
  function cardFor(btn) {
    const row = btn.closest('[role="row"]');
    if (row) return row;
    let el = btn, best = null;
    for (let k = 0; k < 20 && el.parentElement; k++) {
      const p = el.parentElement;
      const titles = new Set([...p.querySelectorAll(MORE)].map((b) => b.getAttribute('aria-label')));
      if (titles.size > 1) break;
      el = p;
      const t = textOf(el);
      if (/\$[\d,]+/.test(t) && STATUS_RE.test(t)) best = el;
    }
    return best;
  }

  async function loadAllCards() {
    let last = -1, same = 0;
    for (let i = 0; i < 60 && same < 4; i++) {
      window.scrollTo(0, document.body.scrollHeight);
      const rows = document.querySelectorAll('[role="grid"] [role="row"]');
      if (rows.length) rows[rows.length - 1].scrollIntoView({ block: 'end' });
      await sleep(900);
      collectRows();
      const n = document.querySelectorAll(MORE).length;
      if (n === last) same++; else { same = 0; last = n; }
    }
    window.scrollTo(0, 0);
  }

  // The table may drop rows that scroll out of view, so rows are collected as we go.
  let rowBag = new Map();
  function collectRows() { for (const r of scrapeCards()) rowBag.set(`${r.title}|${r.price}|${r.status}`, r); }

  function scrapeCards() {
    const emb = embeddedListings();
    const seen = new Set();
    const out = [];
    const clickCol = colIndex('Clicks');
    for (const btn of document.querySelectorAll(MORE)) {
      const title = titleOfBtn(btn);
      if (!/^\d{4}\s/.test(title)) continue; // skips Messenger names etc.
      const card = cardFor(btn);
      if (!card || seen.has(card)) continue;
      seen.add(card);
      const t = textOf(card);
      const price = ((t.match(/\$[\d,]+/) || [])[0] || '').replace(/[$,]/g, '');
      let raw = (t.match(STATUS_RE) || [])[2] || '';
      // A new post can show another word (e.g. "In review") for a while; on the table page
      // the tab it sits under tells us where it belongs.
      if (!raw && card.getAttribute('role') === 'row') {
        const tab = document.querySelector('[role="tab"][aria-selected="true"]');
        const tn = tab ? (tab.innerText.trim().match(/^(Active|Sold|Pending)/) || [])[1] : '';
        raw = /review|processing/i.test(t) ? 'Active' : tn || 'Active';
      }
      const listedOn = (t.match(/Listed on ([\d/]+)/) || [])[1] || '';
      let clicks = +((t.match(/([\d,]+) clicks? on listing/) || [])[1] || '0').replace(/,/g, '');
      if (clickCol && card.getAttribute('role') === 'row') {
        const cell = card.querySelector(`[aria-colindex="${clickCol}"]`);
        if (cell) clicks = +(cell.innerText.replace(/[^\d]/g, '') || 0);
      }
      const img = card.querySelector('img');
      const money = (x) => String(Math.round(parseFloat(String(x).replace(/[$,]/g, '')) || 0));
      const e = (emb[title] || []).find((c) => !c.taken && money(c.price) === money(price)) || (emb[title] || []).find((c) => !c.taken);
      if (e) e.taken = true;
      if (e && e.clicks != null && !clicks) clicks = e.clicks;
      out.push({ title, price: price ? +price : '', status: STATUS_MAP[raw] || raw, group: !!STATUS_MAP[raw], listedOn, clicks, id: e ? e.id : '', photo: (e && e.photo) || (img ? img.src : '') });
    }
    return out;
  }

  // The "More options" button of the job's listing (matching price if the title repeats).
  function findCardButton(job) {
    const btns = [...document.querySelectorAll(MORE)].filter((b) => titleOfBtn(b) === job.title);
    const cards = [...new Set(btns.map((b) => cardFor(b)).filter(Boolean))];
    const want = '$' + Number(job.price).toLocaleString('en-US');
    const card = cards.find((c) => textOf(c).includes(want)) || cards[0];
    return card ? { card, more: btns.find((b) => card.contains(b)) } : null;
  }

  // A button inside the listing's card, e.g. "Mark as sold" or "Mark out of stock".
  function cardButton(card, re) {
    return [...card.querySelectorAll('[role="button"], button')].find((b) => re.test(((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')).trim()));
  }

  // label: one name or a list of names (the old and new pages word some items differently).
  async function clickMenuItem(job, label) {
    const labels = [].concat(label);
    const hit = findCardButton(job);
    const more = hit && hit.more;
    if (!more) throw new Error('Listing not found on your selling page');
    more.scrollIntoView({ block: 'center' });
    more.click();
    const item = await waitFor(() => [...document.querySelectorAll('[role="menuitem"], [role="menu"] [role="button"], [role="menu"] a')].find((e) => visible(e) && labels.includes(e.innerText.trim())), 5000);
    if (!item) {
      document.activeElement && document.activeElement.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      throw new Error(`"${labels[0]}" is not offered for this listing`);
    }
    item.click();
  }

  // New table page: Active / Sold / Pending tabs.
  async function selectTab(name) {
    const tab = [...document.querySelectorAll('[role="tab"]')].find((t) => new RegExp(`^${name}\\b`, 'i').test(t.innerText.trim()));
    if (!tab) return false;
    if (tab.getAttribute('aria-selected') !== 'true') {
      tab.click();
      await waitFor(() => tab.getAttribute('aria-selected') === 'true', 5000, 200);
      await sleep(2500);
    }
    return true;
  }
  // Find the job's listing, looking through the tabs on the new page.
  async function locate(job, order) {
    if (findCardButton(job)) return true;
    if (!isTable() && !document.querySelector('[role="tab"]')) { await loadAllCards(); return !!findCardButton(job); }
    for (const t of order || ['Active', 'Pending', 'Sold']) {
      if (!(await selectTab(t))) continue;
      if (findCardButton(job)) return true;
      await loadAllCards();
      if (findCardButton(job)) return true;
    }
    return false;
  }

  // Facebook keeps other dialogs around (chats, notifications), so look in
  // every visible dialog, preferring the one that mentions this listing.
  const openDialogs = () => [...document.querySelectorAll('[role="dialog"], [role="alertdialog"]')].filter((d) => visible(d) && !inPanel(d));
  function dialogButton(confirmRe, hint) {
    const dlgs = openDialogs().sort((a, b) => (hint && b.innerText.includes(hint) ? 1 : 0) - (hint && a.innerText.includes(hint) ? 1 : 0));
    for (const d of dlgs) {
      const btn = [...d.querySelectorAll('[role="button"], button')].find((b) => visible(b) && enabled(b) && labelMatches(b, confirmRe));
      if (btn) return btn;
    }
    return null;
  }
  async function confirmDialog(confirmRe, timeout = 4000, hint = '') {
    const btn = await waitFor(() => dialogButton(confirmRe, hint), timeout);
    if (btn) { btn.click(); await sleep(1500); }
    return !!btn;
  }
  const dialogSummary = () => openDialogs().map((d) => d.innerText.replace(/\s+/g, ' ').slice(0, 160)).filter(Boolean).join(' / ');

  // Current status of the job's listing on the selling page ('' if it's gone).
  function listingStatus(job) {
    const hit = findCardButton(job);
    if (!hit) return '';
    const raw = (textOf(hit.card).match(STATUS_RE) || [])[2] || '';
    return STATUS_MAP[raw] || raw;
  }

  // Wait until Facebook shows the result, answering any follow up dialogs.
  async function waitForResult(job, done, answerRe) {
    for (let i = 0; i < 20; i++) {
      if (done()) return true;
      const b = dialogButton(answerRe, job.title);
      if (b) { b.click(); await sleep(1500); continue; }
      await sleep(800);
    }
    return done();
  }

  // ---------- replace the photos on a live listing ----------
  const photoCount = () => { const m = document.body.innerText.match(/Photos\s*·\s*(\d+)\s*\/\s*\d+/); return m ? +m[1] : document.querySelectorAll('[aria-label^="Remove photo "]').length; };

  async function setPhotosOnEditPage(images) {
    if (!images.length) throw new Error('No photos are selected for this car');
    await waitFor(() => document.querySelector('[aria-label^="Remove photo "]') && btnByText(/^Update$/), 20000, 400);
    await sleep(1500);
    // 1. Take the current photos off (nothing is saved until Update).
    for (let guard = 0; guard < 30; guard++) {
      const rm = [...document.querySelectorAll('[aria-label^="Remove photo "]')].filter(visible).pop();
      if (!rm) break;
      const before = photoCount();
      rm.click();
      await waitFor(() => photoCount() < before, 4000, 150);
    }
    if (document.querySelector('[aria-label^="Remove photo "]')) throw new Error("Couldn't remove the old photos");
    // 2. Upload the new set, same way as a new post (banner trimmed, your order).
    const msg = await addPhotos(images, () => {});
    const want = Math.min(images.length, 20);
    const ok = await waitFor(() => photoCount() >= want - 1, 120000, 1000);
    if (!ok) throw new Error(`Only ${photoCount()} of ${want} photos uploaded (${msg})`);
    await sleep(3000);
    // 3. Save.
    const upd = await waitFor(() => btnByText(/^Update$/), 30000, 500);
    if (!upd) throw new Error('Update button not found');
    upd.click();
    const done = await waitFor(() => !EDIT.test(location.pathname) || !btnByText(/^Update$/), 45000, 800);
    if (!done) throw new Error('Facebook did not confirm the new photos');
    return `${photoCount() || want} photos`;
  }

  // Read-only: the listing's current description. Nothing is changed or saved.
  async function readDescOnEditPage() {
    const f = await waitFor(() => findField('Description'), 20000, 300);
    if (!f) throw new Error('Description box not found');
    await sleep(800);
    const ta = f.matches('textarea') ? f : f.querySelector('textarea');
    return ta ? ta.value.trim() : '';
  }

  async function setPriceOnEditPage(newPrice) {
    await waitFor(() => findField('Price'), 20000, 300);
    await sleep(1500);
    await setText('Price', newPrice);
    await sleep(800);
    const upd = await waitFor(() => btnByText(/^Update$/), 10000, 400);
    if (!upd) throw new Error('Update button not found');
    upd.click();
    const done = await waitFor(() => !EDIT.test(location.pathname) || !btnByText(/^Update$/), 30000, 800);
    if (!done) throw new Error('Facebook did not confirm the new price');
  }

  // Replace the description on a live post.
  async function setDescOnEditPage(text) {
    const f = await waitFor(() => findField('Description'), 20000, 300);
    if (!f) throw new Error('Description box not found');
    await sleep(1200);
    await setText('Description', text);
    await sleep(800);
    const ta = f.matches('textarea') ? f : f.querySelector('textarea');
    if (ta && ta.value.trim().slice(0, 40) !== String(text).trim().slice(0, 40)) throw new Error("Couldn't type the new description");
    const upd = await waitFor(() => btnByText(/^Update$/), 10000, 400);
    if (!upd) throw new Error('Update button not found');
    upd.click();
    const done = await waitFor(() => !EDIT.test(location.pathname) || !btnByText(/^Update$/), 30000, 800);
    if (!done) throw new Error('Facebook did not confirm the new description');
  }

  // ---------- groups: "List in more places" ----------
  // Facebook lists the groups you're in, each with a checkbox (up to 20 per listing).
  const groupsDialog = () => openDialogs().find((d) => /List in more places/i.test(d.innerText));
  const normName = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  function groupRows(d) {
    return [...d.querySelectorAll('[role="checkbox"], input[type="checkbox"]')].map((c) => {
      let r = c;
      for (let i = 0; i < 8 && r.parentElement && !/members/i.test(r.innerText || ''); i++) r = r.parentElement;
      const lines = (r.innerText || '').split('\n').map((x) => x.trim()).filter(Boolean);
      const members = (lines.find((x) => /members/i.test(x)) || '').replace(/\s*members.*/i, '');
      return { box: c, name: lines[0] || '', members, privacy: /Private/.test(r.innerText) ? 'Private' : /Public/.test(r.innerText) ? 'Public' : '' };
    }).filter((g) => g.name);
  }
  const isChecked = (c) => c.getAttribute('aria-checked') === 'true' || c.checked === true;
  async function openGroupsFor(job) {
    await clickMenuItem(job, ['List in more places']);
    const d = await waitFor(() => { const x = groupsDialog(); return x && groupRows(x).length ? x : null; }, 15000, 400);
    if (!d) throw new Error('Facebook did not show your groups');
    await sleep(800);
    return d;
  }
  async function closeGroups(d) {
    const c = [...d.querySelectorAll('[role="button"]')].find((b) => /^Close$/i.test((b.getAttribute('aria-label') || '').trim()))
      || [...d.querySelectorAll('[role="button"]')].find((b) => /^(Close|Cancel)$/i.test((b.getAttribute('aria-label') || b.innerText || '').trim()));
    if (c) c.click();
    if (!(await waitFor(() => !groupsDialog(), 3000, 200))) {
      (document.activeElement || document.body).dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      await waitFor(() => !groupsDialog(), 2000, 200);
    }
  }
  // Read the list of groups (nothing is posted).
  async function readGroups() {
    await selectTab('Active');
    const first = [...document.querySelectorAll(MORE)].find((b) => /^\d{4}\s/.test(titleOfBtn(b))) || document.querySelector(MORE);
    if (!first) throw new Error('No active listing to read your groups from');
    const d = await openGroupsFor({ title: titleOfBtn(first), price: '' });
    const groups = groupRows(d).map(({ name, members, privacy }) => ({ name, members, privacy }));
    await closeGroups(d);
    await sleep(800);
    return groups;
  }
  // Read-only: which groups each listing is already in (Facebook shows those ticked or greyed out).
  async function checkGroups(items) {
    const out = {};
    for (const it of items) {
      try {
        if (!(await locate(it, ['Active', 'Pending']))) continue;
        const d = await openGroupsFor(it);
        out[`${it.title}|${it.price}`] = groupRows(d).filter((g) => isChecked(g.box) || g.box.getAttribute('aria-disabled') === 'true' || g.box.disabled).map((g) => g.name);
        await closeGroups(d);
        await sleep(1200 + Math.random() * 1500);
      } catch (e) { /* skip this one */ }
    }
    return out;
  }

  // Tick the chosen groups for one listing and post.
  async function postToGroups(job) {
    const d = await openGroupsFor(job);
    const want = (job.groups || []).slice(0, 20).map(normName);
    const rows = groupRows(d);
    const picked = [], missing = [];
    for (const w of want) {
      const g = rows.find((r) => normName(r.name) === w);
      if (!g) { missing.push(w); continue; }
      if (!isChecked(g.box)) { g.box.scrollIntoView({ block: 'center' }); g.box.click(); await sleep(400 + Math.random() * 500); }
      if (isChecked(g.box)) picked.push(g.name);
    }
    if (!picked.length) { await closeGroups(d); throw new Error(`None of your chosen groups were offered for this listing${missing.length ? ' (not found: ' + missing.join(', ') + ')' : ''}. Try "Sync my groups".`); }
    const post = [...d.querySelectorAll('[role="button"]')].filter((b) => visible(b) && enabled(b) && labelMatches(b, /^Post$/i)).pop();
    if (!post) throw new Error('Post button not found');
    await sleep(800);
    post.click();
    const closed = await waitFor(() => !groupsDialog(), 30000, 600);
    if (!closed) throw new Error(`Facebook didn't confirm${dialogSummary() ? ': ' + dialogSummary() : ''}`);
    return { picked, missing };
  }

  async function runJob(job) {
    // Tell the app "still working" every few seconds, so a frozen page is noticed quickly.
    const beat = setInterval(() => chrome.runtime.sendMessage({ type: 'jobBeat' }).catch(() => {}), 8000);
    const finish = (result) => { clearInterval(beat); return chrome.runtime.sendMessage({ type: 'jobDone', jobId: job.jobId, result }).catch(() => {}); };
    try {
      if (job.kind === 'desc' && EDIT.test(location.pathname)) {
        await setDescOnEditPage(job.description);
        return finish({ ok: true });
      }
      if (job.kind === 'price' && EDIT.test(location.pathname)) {
        await setPriceOnEditPage(job.newPrice);
        return finish({ ok: true });
      }
      if (job.kind === 'renew' && RENEW.test(location.pathname)) {
        const res = await renewListings(job);
        return finish({ ok: true, ...res });
      }
      if (job.kind === 'readDesc' && EDIT.test(location.pathname)) {
        return finish({ ok: true, description: await readDescOnEditPage() });
      }
      if (job.kind === 'photos' && EDIT.test(location.pathname)) {
        const res = await setPhotosOnEditPage(job.images || []);
        return finish({ ok: true, message: res });
      }
      if (!SELLING.test(location.pathname)) {
        // Facebook sent us somewhere else (it moves the listings page now and then and
        // redirects the old address to Marketplace home). Try the other address once.
        const wanted = SELLING.test(new URL(job.url || location.href, location.origin).pathname);
        // Login and security pages are left to the app's watchdog.
        if (wanted && /^\/marketplace\b/.test(location.pathname) && !EDIT.test(location.pathname) && !RENEW.test(location.pathname)) {
          const key = 'lhAlt_' + job.jobId;
          let tried = null; try { tried = sessionStorage.getItem(key); } catch (e) {}
          if (!tried) {
            try { sessionStorage.setItem(key, '1'); } catch (e) {}
            const alt = /seller\/listings/.test(job.url || '') ? '/marketplace/you/selling/' : '/marketplace/seller/listings/';
            clearInterval(beat);
            jobRunning = false;
            location.href = location.origin + alt;
            return;
          }
          return finish({ ok: false, error: "Facebook didn't open your listings page (it went to " + location.pathname + "). Tap Try again." });
        }
        clearInterval(beat); return;
      }
      chrome.runtime.sendMessage({ type: 'sellingWorked', path: location.pathname.match(SELLING)[0] }).catch(() => {});
      await waitFor(() => document.querySelector(MORE) || document.querySelector('[role="tab"]') || /no listings/i.test(document.body.innerText), 25000, 500);
      await sleep(1500);
      if (job.kind === 'groupsRead') return finish({ ok: true, groups: await readGroups() });
      if (job.kind === 'groupsCheck') return finish({ ok: true, inGroups: await checkGroups(job.items || []) });
      if (job.kind === 'groupsPost') {
        if (!(await locate(job, ['Active', 'Pending']))) throw new Error('Listing not found among your active listings. Try Sync first.');
        const r = await postToGroups(job);
        return finish({ ok: true, message: `Listed in ${r.picked.length} group${r.picked.length === 1 ? '' : 's'}${r.missing.length ? ` (${r.missing.length} not offered)` : ''}`, picked: r.picked });
      }
      if (job.kind === 'sync') {
        rowBag = new Map();
        if (document.querySelector('[role="tab"]')) {
          // New page: each status has its own tab.
          // Active and Pending are short lists: when every row loaded (the tab says how many),
          // the app knows anything else it had as Active/Pending is gone or renamed.
          var complete = [];
          for (const t of ['Active', 'Pending', 'Sold']) {
            if (!(await selectTab(t))) continue;
            collectRows();
            await loadAllCards();
            collectRows();
            const tab = [...document.querySelectorAll('[role="tab"]')].find((x) => new RegExp(`^${t}\\b`, 'i').test(x.innerText.trim()));
            const want = +(((tab && tab.innerText) || '').match(/\((\d+)\)/) || [])[1];
            const have = new Set([...document.querySelectorAll(MORE)].map((b) => cardFor(b)).filter(Boolean)).size;
            if (t !== 'Sold' && Number.isFinite(want) && have >= want) complete.push(t);
          }
        } else {
          await loadAllCards();
          collectRows();
        }
        // A background tab may not load the older listings; the app merges instead of replacing.
        return finish({ ok: true, listings: [...rowBag.values()], full: !document.hidden, complete: typeof complete === 'undefined' ? [] : complete });
      }
      const act = job.action;
      // Where to look first: a sold car to make available is under Sold, and so on.
      const order = act === 'available' ? ['Sold', 'Pending', 'Active'] : ['Active', 'Pending', 'Sold'];
      let found = await locate(job, order);
      if (!found && document.hidden && !job.quiet) {
        // Older listings only load in a visible tab: come to the front briefly.
        await chrome.runtime.sendMessage({ type: 'showMe' }).catch(() => {});
        await sleep(1500);
        found = await locate(job, order);
      }
      if (!found) throw new Error('Listing not found on your selling page. Try Sync first.');
      // Buttons that answer Facebook's follow up questions. Never Cancel/Close.
      const ANSWER = /^(Mark as sold|Mark as available|Mark as pending|Mark out of stock|Mark in stock|Skip|Not now|Done|Confirm|Continue|Next|Save|Submit|Someone else|Sold elsewhere|Sold somewhere else|I'm not sure|Prefer not to say)$/i;
      let ok = true;
      const before = listingStatus(job);
      const table = isTable();
      // On the table page a listing leaves the current tab when its status changes. Only count
      // it once it has stayed gone for a few checks and no follow-up question is open (a row
      // can vanish for a moment while Facebook redraws, which used to look like success).
      let gone = 0;
      const asking = () => openDialogs().some((d) => /sold|buyer|who|pending|available|mark/i.test(d.innerText) && d.querySelector('[role="button"], button'));
      const changed = (want) => {
        const s = listingStatus(job);
        if (s === want) return true;
        if (!table || s === before || asking()) { gone = 0; return false; }
        return ++gone >= 3;
      };
      if (act === 'sold' || act === 'available') {
        const hit = findCardButton(job);
        const b = cardButton(hit.card, act === 'sold' ? /^Mark (as sold|out of stock)\b/i : /^Mark (as available|in stock)\b/i);
        if (b) { b.scrollIntoView({ block: 'center' }); b.click(); }
        else await clickMenuItem(job, act === 'sold' ? ['Mark as sold', 'Mark out of stock'] : ['Mark as available', 'Mark in stock']);
        await sleep(1500);
        const want = act === 'sold' ? 'Sold' : 'Active';
        ok = await waitForResult(job, () => changed(want), ANSWER);
      } else if (act === 'pending') {
        await clickMenuItem(job, 'Mark as pending');
        await sleep(1500);
        ok = await waitForResult(job, () => changed('Pending'), ANSWER);
      } else if (act === 'delete') {
        await clickMenuItem(job, ['Delete listing', 'Delete']);
        const confirmed = await confirmDialog(/^Delete$/i, 8000, job.title);
        if (!confirmed) throw new Error(`Facebook did not show the delete confirmation${dialogSummary() ? ': ' + dialogSummary() : ''}`);
        ok = await waitForResult(job, () => !findCardButton(job), /^Delete$/i);
      }
      if (job.kind === 'action' && !ok) {
        const d = dialogSummary();
        throw new Error(`Facebook didn't apply it${d ? `. It showed: "${d}"` : ''}`);
      }
      // Table page: make sure it really landed under the right tab (Sold, Pending, Active).
      const target = { sold: 'Sold', pending: 'Pending', available: 'Active' }[act];
      if (job.kind === 'action' && table && target) {
        await sleep(1500);
        await selectTab(target);
        let there = !!findCardButton(job);
        if (!there) { await sleep(2500); there = !!findCardButton(job); }
        if (!there) { await loadAllCards(); there = !!findCardButton(job); }
        if (!there) {
          const d = dialogSummary();
          throw new Error(`Facebook didn't move it to ${target}${d ? `. It showed: "${d}"` : ''}. Open your listings on Facebook to check.`);
        }
        await sleep(1000);
        return finish({ ok: true, listings: scrapeCards(), full: false, status: target });
      }
      if (job.kind === 'price' || job.kind === 'photos' || job.kind === 'readDesc' || job.kind === 'desc') {
        await clickMenuItem(job, ['Edit listing', 'Edit']);
        await waitFor(() => EDIT.test(location.pathname), 15000, 400);
        if (job.kind === 'desc') { await setDescOnEditPage(job.description); return finish({ ok: true }); }
        if (job.kind === 'readDesc') return finish({ ok: true, description: await readDescOnEditPage() });
        if (job.kind === 'photos') return finish({ ok: true, message: await setPhotosOnEditPage(job.images || []) });
        await setPriceOnEditPage(job.newPrice);
        return finish({ ok: true });
      }
      await sleep(2500);
      // Partial list: the app merges it, so other tabs' listings aren't lost.
      return finish({ ok: true, listings: scrapeCards(), full: false });
    } catch (e) {
      return finish({ ok: false, error: e.message || String(e) });
    }
  }

  let jobRunning = false;
  // Ask a few times: the job can be registered a moment after the tab opens.
  async function checkJob() {
    if (jobRunning) return true;
    for (let i = 0; i < 8; i++) {
      const r = await chrome.runtime.sendMessage({ type: 'myJob' }).catch(() => null);
      if (r && r.job) {
        jobRunning = true;
        try { await runJob(r.job); } finally { jobRunning = false; }
        return true;
      }
      await sleep(1000);
    }
    return false;
  }

  // When you open your selling page yourself (for example after editing a
  // listing on Facebook), quietly send what's on screen to the app.
  async function passiveSync() {
    await waitFor(() => document.querySelector(MORE), 15000, 500);
    await sleep(2000);
    const listings = scrapeCards();
    if (listings.length) chrome.runtime.sendMessage({ type: 'passiveSync', listings }).catch(() => {});
  }

  function unmount() {
    const p = document.getElementById(PANEL_ID);
    if (p) p.remove();
  }

  // Self login for app tabs only: press Facebook's own one-tap "Continue as …" (a saved
  // account on this browser). The app never reads, stores or types a password.
  (async () => {
    if (!/\/login|login\.php/i.test(location.pathname)) return;
    await sleep(1500);
    const ours = await chrome.runtime.sendMessage({ type: 'isAppTab' }).catch(() => null);
    if (!ours || !ours.app) return;
    try { if (sessionStorage.getItem('lhml-continue')) return; sessionStorage.setItem('lhml-continue', '1'); } catch (e) {}
    const tap = await waitFor(() => [...document.querySelectorAll('[role="button"], button, a')].find((x) => visible(x) && /^(Continue as|Log in as)\b/i.test(((x.getAttribute('aria-label') || '') + ' ' + (x.innerText || '')).trim()) && !/password|create|new account/i.test(x.innerText || '')), 6000, 300);
    if (tap) tap.click();
  })();

  let lastPath = '';
  setInterval(() => {
    if (location.pathname === lastPath) return;
    lastPath = location.pathname;
    COMPOSER.test(location.pathname) ? waitFor(() => findField('Vehicle type'), 15000, 300).then(mount) : unmount();
    if (SELLING.test(location.pathname) || EDIT.test(location.pathname) || RENEW.test(location.pathname)) {
      checkJob().then((hadJob) => { if (!hadJob && SELLING.test(location.pathname)) passiveSync(); });
    }
  }, 700);
})();
