/* Dashboard (home page): every vehicle as a box, merged with what's live on
 * Facebook after a sync. Price changes and Mark sold / pending / available /
 * Delete run on Facebook through the extension's Facebook tab. */
(function () {
  const D = { filter: 'all', search: '', fb: [], syncedAt: 0, busy: new Set() };

  // ---------- views ----------
  function showView(name) {
    const dash = name === 'dash', perf = name === 'perf', work = name === 'work';
    $('#dashView').hidden = !dash;
    $('#perfView').hidden = !perf;
    $('#workView').hidden = !work;
    $('#tabDash').classList.toggle('active', dash);
    $('#tabPerf').classList.toggle('active', perf);
    $('#tabWork').classList.toggle('active', work);
    if (dash) render();
    if (perf) renderPerf();
  }
  window.openInEditor = (id) => { showView('work'); select(id); window.scrollTo(0, 0); };

  // ---------- matching app vehicles to Facebook listings ----------
  const norm = (s) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const fbMatches = (l, f) => S.sameCar(l, f);
  const RANK = { Active: 0, Pending: 1, Sold: 2 };

  function items() {
    const fb = D.fb.map((f, i) => ({ ...f, key: 'fb' + i }));
    const used = new Set();
    const out = state.listings.map((l) => {
      const cands = fb.filter((f) => !used.has(f.key) && fbMatches(l, f))
        .sort((a, b) => (RANK[a.status] ?? 3) - (RANK[b.status] ?? 3) || (a.price === l.fb.price ? -1 : 0) - (b.price === l.fb.price ? -1 : 0));
      const f = cands[0] || null;
      if (f) used.add(f.key);
      return { l, f };
    });
    fb.filter((f) => !used.has(f.key)).forEach((f) => out.push({ l: null, f }));
    return out;
  }

  const statusOf = (it) => (it.f ? it.f.status || 'Active' : it.l && it.l.status === 'posted' ? 'Posted' : it.l && it.l.status === 'opened' ? 'Sent to Facebook' : 'Not posted');
  const titleOf = (it) => (it.l ? `${it.l.fb.year} ${it.l.fb.make} ${it.l.fb.model}` : it.f.title);
  const priceOf = (it) => (it.f && it.f.price ? it.f.price : it.l ? it.l.fb.price : '');
  const money = (n) => (n ? '$' + Number(n).toLocaleString('en-US') : 'No price');

  function visibleItems() {
    const q = D.search.toLowerCase();
    return S.sortItems(items().filter((it) => {
      const st = statusOf(it);
      if (D.filter === 'notposted' && (it.f || (it.l && it.l.status === 'posted'))) return false;
      if (['Active', 'Pending', 'Sold'].includes(D.filter) && st !== D.filter) return false;
      return !q || titleOf(it).toLowerCase().includes(q);
    }), D.sort);
  }

  // ---------- render ----------
  function render() {
    if ($('#dashView').hidden) return;
    const all = items();
    const count = (fn) => all.filter(fn).length;
    $('#stats').innerHTML = '';
    [
      ['Active on Facebook', count((it) => it.f && it.f.status === 'Active')],
      ['Pending', count((it) => it.f && it.f.status === 'Pending')],
      ['Not posted yet', count((it) => it.l && !it.f && it.l.status !== 'posted')],
      ['Sold', count((it) => it.f && it.f.status === 'Sold')],
      ['Clicks on active listings', all.filter((it) => it.f && it.f.status === 'Active').reduce((s, it) => s + (it.f.clicks || 0), 0)],
    ].forEach(([label, n]) => {
      const d = document.createElement('div');
      d.className = 'stat';
      d.innerHTML = '<b></b><span></span>';
      d.querySelector('b').textContent = n;
      d.querySelector('span').textContent = label;
      $('#stats').appendChild(d);
    });
    $('#syncInfo').textContent = D.syncedAt ? `Last synced ${timeAgo(D.syncedAt)}` : 'Not synced yet';
    chrome.storage.local.get('postQueueInfo').then(({ postQueueInfo }) => {
      const el = $('#queueInfo');
      el.hidden = !(postQueueInfo && postQueueInfo.waiting);
      if (!el.hidden) {
        el.innerHTML = '';
        el.append(document.createTextNode(`Posting line: ${queueText(postQueueInfo)} `));
        const b = document.createElement('button'); b.className = 'link'; b.textContent = 'Cancel line';
        b.onclick = async () => { await chrome.runtime.sendMessage({ type: 'cancelPostQueue' }); render(); };
        el.appendChild(b);
      }
    });
    $('#autoPostToggle').checked = !!state.settings.autoPost;
    $('#autoRenewToggle').checked = !!state.settings.autoRenew;
    chrome.storage.local.get('lastRenew').then(({ lastRenew }) => {
      const t = lastRenew ? `Last renew ${timeAgo(lastRenew.at)}${lastRenew.renewed && lastRenew.renewed.length ? ` (${lastRenew.renewed.length})` : ''}` : '';
      $('#renewNowBtn').title = t || 'Renew every car listing that\'s ready now';
    });

    const list = visibleItems();
    const box = $('#boxes');
    box.innerHTML = '';
    $('#dashEmpty').hidden = list.length > 0;
    list.forEach((it) => box.appendChild(card(it)));
    updatePostSelected();
  }

  function timeAgo(t) {
    const m = Math.round((Date.now() - t) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return `${m} min ago`;
    const h = Math.round(m / 60);
    return h < 24 ? `${h} hr ago` : new Date(t).toLocaleDateString();
  }

  function btn(label, cls, onClick, title) {
    const b = document.createElement('button');
    b.textContent = label;
    b.className = cls;
    if (title) b.title = title;
    b.onclick = (e) => { e.stopPropagation(); onClick(b); };
    return b;
  }

  function card(it) {
    const { l, f } = it;
    const st = statusOf(it);
    const key = l ? l.id : 'fb:' + f.title + f.listedOn;
    const el = document.createElement('article');
    el.className = 'box' + (D.busy.has(key) ? ' busy' : '');
    const photo = l ? (l.images.find((i) => i.on) || l.images[0]) : null;
    el.innerHTML = `
      <div class="box-img">${photo || (f && f.photo) ? '<img alt="" loading="lazy" referrerpolicy="no-referrer">' : '<div class="noimg">No photo</div>'}
        <span class="box-status"></span>
        ${l && !f && l.status !== 'posted' ? '<label class="box-pick"><input type="checkbox"></label>' : ''}
      </div>
      <div class="box-body">
        <h3></h3>
        <div class="box-price"><span class="amt"></span><button class="link edit-price">Change price</button></div>
        <div class="price-edit" hidden><span>$</span><input type="number" min="0" step="1"><button class="primary save">Save</button><button class="link cancel">Cancel</button></div>
        <p class="box-meta muted"></p>
        <div class="box-actions"></div>
      </div>`;
    if (photo) setThumb($('img', el), photo);
    else if (f && f.photo) $('img', el).src = f.photo;
    const s = $('.box-status', el);
    s.textContent = st;
    s.className = 'box-status st-' + norm(st);
    $('h3', el).textContent = titleOf(it);
    $('.amt', el).textContent = money(priceOf(it));
    $('.box-meta', el).textContent = [
      l && l.fb.mileage ? Number(l.fb.mileage).toLocaleString() + ' mi' : '',
      l && l.raw.stock ? 'Stock ' + l.raw.stock : '',
      f && f.listedOn ? 'Listed ' + f.listedOn : '',
      f && f.status !== 'Sold' ? `${f.clicks || 0} clicks` + (f.cpd != null && f.days >= 2 ? ` · ${f.cpd}/day${f.trend === 'up' ? ' ↑' : f.trend === 'down' ? ' ↓' : ''}` : '') : '',
      '',
      f && f.groupOnly ? `Group only${f.originGroup ? ' (' + f.originGroup + ')' : ''}, not on Marketplace` : '',
      !l ? 'On Facebook only' : '',
    ].filter(Boolean).join(' · ');

    // "In 3 groups" — click to see which.
    // Every live post shows its groups line, even before any are known.
    let gl = $('.box-groups', el);
    if (f && f.status !== 'Sold') {
      if (!gl) { gl = document.createElement('button'); gl.className = 'link box-groups'; $('.box-meta', el).after(gl); }
      const n = (f.groups || []).length;
      gl.textContent = n ? `In ${n} group${n === 1 ? '' : 's'} ▾` : f.inGroups ? 'In groups (tap to see which) ▾' : 'Groups: none yet ▾';
      gl.title = n ? f.groups.join('\n') : f.inGroups ? 'Facebook says this post is in at least one group. "Check groups on Facebook" finds which.' : 'Not in any groups the app knows of';
      gl.onclick = (e) => { e.stopPropagation(); showGroupList(f, it, key); };
    } else if (gl) gl.remove();

    // Flags: a slow post (with one-tap fixes) and a car that left the dealer website.
    let fl = $('.box-flags', el);
    const flags = [];
    if (f && f.slow && f.status === 'Active') flags.push(['Slow: fewer clicks than your other cars ▾', 'warn', () => showFixes(it, key)]);
    if (l && l.dealerGone && f && f.status !== 'Sold') flags.push(['Not on the dealer website anymore. Sold?', 'err', () => fbAction(it, key, 'sold')]);
    const lastTest = l && (l.heroTests || []).slice(-1)[0];
    if (lastTest && f) {
      const after = S.clicksPerDaySince(f, lastTest.day);
      const days = Math.round((Date.now() - lastTest.at) / 86400000);
      if (after != null && days >= 3) flags.push([`New first photo: ${lastTest.before != null ? lastTest.before.toFixed(1) : '?'} → ${after.toFixed(1)} clicks/day ${after > (lastTest.before || 0) ? '(better)' : '(no better)'}`, after > (lastTest.before || 0) ? 'ok' : 'warn', null]);
      else if (days < 3) flags.push([`Testing a new first photo (day ${days + 1} of 3)`, 'ok', null]);
    }
    if (flags.length) {
      if (!fl) { fl = document.createElement('div'); fl.className = 'box-flags'; $('.box-meta', el).after(fl); }
      fl.innerHTML = '';
      flags.forEach(([t, cls, fn]) => { const b = document.createElement(fn ? 'button' : 'span'); b.className = `flag ${cls}`; b.textContent = t; if (fn) b.onclick = (e) => { e.stopPropagation(); fn(); }; fl.appendChild(b); });
    } else if (fl) fl.remove();

    const pick = $('.box-pick input', el);
    if (pick) {
      pick.checked = state.checked.has(l.id);
      pick.onclick = (e) => { e.stopPropagation(); pick.checked ? state.checked.add(l.id) : state.checked.delete(l.id); updatePostSelected(); };
    }

    // price editing
    const editRow = $('.price-edit', el), showRow = $('.box-price', el), input = $('.price-edit input', el);
    editRow.onclick = (e) => e.stopPropagation();
    const pickLabel = $('.box-pick', el);
    if (pickLabel) pickLabel.onclick = (e) => e.stopPropagation();
    $('.edit-price', el).onclick = (e) => { e.stopPropagation(); editRow.hidden = false; showRow.hidden = true; input.value = priceOf(it) || ''; input.focus(); input.select(); };
    $('.cancel', el).onclick = (e) => { e.stopPropagation(); editRow.hidden = true; showRow.hidden = false; };
    const save = async () => {
      const v = Math.round(Number(input.value));
      if (!v || v < 100) { input.focus(); return; }
      editRow.hidden = true; showRow.hidden = false;
      await changePrice(it, key, v);
    };
    $('.save', el).onclick = (e) => { e.stopPropagation(); save(); };
    input.onkeydown = (e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') $('.cancel', el).click(); };

    // actions
    const acts = $('.box-actions', el);
    if (l) acts.appendChild(btn('Open', 'secondary', () => openInEditor(l.id), 'Photos, details and description'));
    if (l && !f) acts.appendChild(btn(state.settings.autoPost ? 'Post (auto)' : 'Post', 'primary', () => post([l.id])));
    if (f) {
      if (l && f.status !== 'Sold') acts.appendChild(btn('Update photos', 'secondary', () => updatePhotos(it, key), 'Replace the photos on Facebook with the ones selected in the app'));
      if (l && f.status !== 'Sold' && l.raw && l.raw.sourceUrl) acts.appendChild(btn('Use dealer photos', 'secondary', async () => {
        try { const m = await useDealerPhotos(l.id); if (m) say(`${f.title}: ${m}.`, 'ok'); }
        catch (e) { problem(`${f.title}: dealer photos not used`, e, () => useDealerPhotos(l.id, { ask: false })); }
      }, 'Swap your photos for the dealer website photos, on Facebook too'));
      if (f.status === 'Active') {
        acts.appendChild(btn('Mark sold', 'secondary', () => fbAction(it, key, 'sold')));
        acts.appendChild(btn('Mark pending', 'secondary', () => fbAction(it, key, 'pending')));
        acts.appendChild(btn('List in groups', 'secondary', () => listInGroups(it, key), 'List this car in the groups chosen in Settings'));
      }
      if (f.status === 'Pending') acts.appendChild(btn('Mark sold', 'secondary', () => fbAction(it, key, 'sold')));
      if (f.status === 'Sold') acts.appendChild(btn('Mark available', 'secondary', () => fbAction(it, key, 'available')));
      if (f.id) acts.appendChild(btn('View', 'link', () => window.open(`https://www.facebook.com/marketplace/item/${f.id}/`, '_blank'), 'Open the listing on Facebook'));
      acts.appendChild(btn('Delete', 'danger', () => fbAction(it, key, 'delete'), 'Delete the listing from Facebook'));
    }
    if (l) el.onclick = () => openInEditor(l.id);
    return el;
  }

  function updatePostSelected() {
    const ids = items().filter((it) => it.l && !it.f && state.checked.has(it.l.id)).map((it) => it.l.id);
    const b = $('#dashPostSelected');
    b.disabled = !ids.length;
    b.textContent = ids.length ? `Post selected (${ids.length})` : 'Post selected';
    b.onclick = () => post(ids);
  }

  function say(msg, kind = '') {
    const el = $('#dashStatus');
    el.textContent = msg;
    el.className = 'status ' + kind;
  }

  // ---------- Facebook jobs ----------
  // Runs a job in a Facebook tab and keeps an eye on it: a closed tab, a login page or a
  // page that stops responding ends it right away with a clear reason (err.code).
  class JobError extends Error { constructor(msg, code, tabId) { super(msg); this.code = code; this.tabId = tabId; } }
  async function runJob(job, label, quiet) {
    const r = await chrome.runtime.sendMessage({ type: 'startFbJob', job });
    if (!r || !r.ok) throw new Error((r && r.error) || 'Could not open Facebook');
    const jobId = r.jobId;
    if (!quiet) say(`${label}…`);
    const t0 = Date.now();
    let tabId = null;
    let waitingLogin = false;
    while (Date.now() - t0 < 15 * 60000) {
      await new Promise((res) => setTimeout(res, 1500));
      const s = await chrome.runtime.sendMessage({ type: 'jobStatus', jobId }).catch(() => null);
      if (!s) continue;
      if (s.tabId) tabId = s.tabId;
      if (s.done) {
        if (!s.result.ok && s.result.code) throw new JobError(s.result.error, s.result.code, tabId);
        return s.result;
      }
      if (s.login) {
        // Autopilot is waiting for you to log in; it carries on by itself afterwards.
        if (!waitingLogin) {
          waitingLogin = true;
          problem(label, Object.assign(new Error(s.need === 'checkpoint' ? 'Facebook wants a security check. Finish it on the Facebook tab and this carries on by itself.' : 'Facebook asked you to log in. Log in on the Facebook tab and this carries on by itself.'), { code: s.need || 'login', tabId }));
        }
        continue;
      }
      if (waitingLogin) { waitingLogin = false; say(`Logged in. ${label}…`); }
      if (!quiet && s.step && Date.now() - t0 > 8000) say(`${label}… (${s.step}, ${Math.round((Date.now() - t0) / 1000)}s)`);
    }
    chrome.runtime.sendMessage({ type: 'cancelJob', jobId });
    throw new JobError('Facebook stopped responding.', 'stuck', tabId);
  }

  // A problem message with a way to fix it: Try again, and Open Facebook when it needs you there.
  // Everything needed to see what happened, as plain text for a message.
  async function copyLog(btn) {
    const st = await chrome.storage.local.get(['lhLog', 'settings', 'fbListings', 'listings', 'fbSyncedAt', 'sellingUrl', 'fbJobs']);
    const t = (ms) => (ms ? new Date(ms).toLocaleString() : 'never');
    const fb = st.fbListings || [];
    const by = (x) => fb.filter((f) => (f.status || 'Active') === x).length;
    const cfg = st.settings || {};
    const lines = [
      `LH Marketplace Lister ${chrome.runtime.getManifest().version} — log copied ${t(Date.now())}`,
      `Browser: ${navigator.userAgent.match(/(Edg|Chrome)\/[\d.]+/g)?.join(' ') || navigator.userAgent}`,
      `Facebook listings in the app: ${fb.length} (${by('Active')} active, ${by('Pending')} pending, ${by('Sold')} sold), last sync ${t(st.fbSyncedAt)}`,
      `Cars in the app: ${(st.listings || []).length}; listings page: ${st.sellingUrl || 'default'}`,
      `Settings: work in ${cfg.workWhere || 'window'}, autopilot ${cfg.autopilot !== false ? 'on' : 'off'}, live sync every ${cfg.liveSyncMin || 15} min, auto publish ${cfg.publishOnPost !== false ? 'on' : 'off'}`,
      `Jobs running now: ${Object.values(st.fbJobs || {}).map((j) => [j.kind, j.action, j.title].filter(Boolean).join(' ')).join('; ') || 'none'}`,
      '',
      ...(st.lhLog || []).slice(-200).map(([ms, text]) => `${new Date(ms).toLocaleString([], { month: 'numeric', day: 'numeric', hour: 'numeric', minute: '2-digit', second: '2-digit' })}  ${text}`),
    ];
    const text = lines.join('\n');
    try { await navigator.clipboard.writeText(text); }
    catch (e) { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
    if (btn) { const was = btn.textContent; btn.textContent = 'Copied ✓'; setTimeout(() => { btn.textContent = was; }, 2000); }
    say('Log copied. Paste it into your message.', 'ok');
  }

  function problem(prefix, e, retry) {
    chrome.runtime.sendMessage({ type: 'log', text: `Shown to you: ${prefix}: ${e.message}` }).catch(() => {});
    const el = $('#dashStatus');
    el.className = 'status err problem';
    el.innerHTML = '';
    const msg = document.createElement('span');
    msg.textContent = `${prefix}: ${e.message}`;
    el.appendChild(msg);
    const add = (text, fn, cls = 'secondary') => { const b = document.createElement('button'); b.className = cls; b.textContent = text; b.onclick = fn; el.appendChild(b); };
    if (e.code === 'login' || e.code === 'checkpoint' || e.code === 'stuck' || e.code === 'needsYou') {
      add('Open Facebook', () => {
        if (e.tabId && e.code !== 'stuck') chrome.runtime.sendMessage({ type: 'reveal', tabId: e.tabId }).catch(() => window.open('https://www.facebook.com/', '_blank'));
        else window.open('https://www.facebook.com/marketplace/you/selling/', '_blank');
      });
    }
    if (retry) add('Try again', () => { say(''); retry(); }, 'primary');
    add('Copy log', (ev) => copyLog(ev.target), 'link');
    add('Dismiss', () => say(''), 'link');
  }

  async function loadFb() {
    const d = await chrome.storage.local.get(['fbListings', 'fbSyncedAt']);
    // A listing whose status word wasn't recognized (e.g. a brand new post) counts as Active.
    D.fb = (d.fbListings || []).map((f) => (f.status ? f : { ...f, status: 'Active' }));
    D.syncedAt = d.fbSyncedAt || 0;
  }

  // After a sync, cars that are live on Facebook count as posted.
  async function reconcile() {
    let changed = false;
    items().forEach(({ l, f }) => {
      if (l && f && l.status !== 'posted') { l.status = 'posted'; changed = true; }
    });
    if (changed) { await saveNow(); renderList(); }
  }

  // Quick sync runs in a background tab and refreshes your newest listings.
  // Full sync (first time, or "Full sync") opens in front so Facebook loads everything.
  let syncing = false;
  async function sync({ full = false, quiet = false } = {}) {
    if (syncing) return;
    syncing = true;
    const b = $('#syncBtn');
    b.disabled = true;
    // Full sync when asked, the first time, or once a day so older listings stay right.
    let lastFull = 0; try { lastFull = +localStorage.getItem('lhFullSyncAt') || 0; } catch (e) {}
    full = full || !D.fb.length || (!quiet && Date.now() - lastFull > 20 * 3600 * 1000);
    try {
      const res = await runJob({ kind: 'sync', full }, full ? 'Full sync with Facebook (a Facebook tab opens for a moment)' : 'Refreshing from Facebook in the background', quiet);
      if (!res.ok) throw new Error(res.error);
      if (full) { try { localStorage.setItem('lhFullSyncAt', String(Date.now())); } catch (e) {} }
      await loadFb();
      await reconcile();
      if (!quiet) { const act = D.fb.filter((x) => (x.status || 'Active') === 'Active').length; say(`Synced ${D.fb.length} vehicle listing${D.fb.length === 1 ? '' : 's'} from Facebook (${act} active).`, 'ok'); }
      setTimeout(() => learnFromBest({ quiet: true }), 3000); // keep learning from your best posts
    } catch (e) {
      if (!quiet || e.code === 'login' || e.code === 'checkpoint') problem('Sync didn\'t finish', e, () => sync({ full }));
    } finally {
      syncing = false;
      b.disabled = false;
      render();
    }
  }

  async function changePrice(it, key, v) {
    const { l, f } = it;
    const live = f && (f.status === 'Active' || f.status === 'Pending');
    if (l) { l.fb.price = v; l.updatedAt = Date.now(); await saveNow(); renderList(); }
    if (!live) { say(`Price set to ${money(v)}${f ? ' in the app (sold listings keep their Facebook price)' : ''}.`, 'ok'); render(); return; }
    D.busy.add(key); render();
    try {
      const res = await runJob({ kind: 'price', title: f.title, price: f.price, id: f.id, newPrice: v }, `Changing the price on Facebook to ${money(v)}`);
      if (!res.ok) throw new Error(res.error);
      const stored = D.fb.find((x) => x.title === f.title && x.listedOn === f.listedOn);
      if (stored) stored.price = v;
      await chrome.storage.local.set({ fbListings: D.fb });
      say(`${f.title} is now ${money(v)} on Facebook.`, 'ok');
      sync({ quiet: true }); // refresh from Facebook in the background
    } catch (e) {
      problem('Price not changed on Facebook', e, () => changePrice(it, key, v));
    } finally {
      D.busy.delete(key);
      render();
    }
  }

  // Replace a live listing's photos with the car's selected photos in the app.
  const photoJobImages = (l) => (l.images || []).filter((i) => i.on).slice(0, state.settings.maxPhotos || 20)
    .map(({ url, fallback, local, cloud, cropTop }) => ({ url, fallback, local, cloud, cropTop }));

  async function updatePhotos(it, key, { noConfirm = false } = {}) {
    const { l, f } = it;
    const imgs = photoJobImages(l);
    if (!imgs.length) { say('Select at least one photo for this car first (Open → Photos).', 'err'); return false; }
    if (!noConfirm && !confirm(`Replace the photos on "${f.title}" with the ${imgs.length} photo${imgs.length === 1 ? '' : 's'} selected in the app?`)) return;
    D.busy.add(key); render();
    try {
      const res = await runJob({ kind: 'photos', title: f.title, price: f.price, id: f.id || '', images: imgs }, `Updating photos on Facebook (${imgs.length})`);
      if (!res.ok) throw new Error(res.error);
      say(`${f.title}: photos updated on Facebook (${res.message || imgs.length + ' photos'}).`, 'ok');
      sync({ quiet: true });
      return true;
    } catch (e) {
      problem('Photos not updated', e, () => updatePhotos(it, key));
      return false;
    } finally {
      D.busy.delete(key);
      render();
    }
  }

  const ACTION_TEXT = {
    sold: ['Marking as sold', 'marked as sold'],
    pending: ['Marking as pending', 'marked as pending'],
    available: ['Marking as available', 'back on the market'],
    delete: ['Deleting', 'deleted from Facebook'],
  };

  // Pick groups for one or more live posts. Groups a post is already in are shown and left off.
  async function pickGroups(title, already = []) {
    const { fbGroups = [] } = await chrome.storage.local.get('fbGroups');
    if (!fbGroups.length) { say('Sync your groups first: Settings → Facebook groups → Sync my groups from Facebook.', 'err'); return null; }
    let dlg = document.getElementById('groupDlg');
    if (!dlg) { dlg = document.createElement('dialog'); dlg.id = 'groupDlg'; dlg.className = 'group-dlg'; document.body.appendChild(dlg); }
    const chosen = new Set((state.settings.groups || []).filter((g) => !already.includes(g)));
    dlg.innerHTML = `<form method="dialog"><h2></h2><p class="hint">Up to 20 per post. 3 to 5 local car buy/sell groups is safer than many.</p>
      <input type="search" class="gfilter" placeholder="Filter groups"><div class="group-list"></div>
      <label class="check"><input type="checkbox" class="gsave"> Make these my default groups</label>
      <div class="actions"><button value="cancel" class="secondary">Cancel</button><button value="ok" class="primary gpost">Post</button></div></form>`;
    $('h2', dlg).textContent = title;
    const list = $('.group-list', dlg);
    const draw = () => {
      const q = $('.gfilter', dlg).value.toLowerCase();
      list.innerHTML = '';
      [...fbGroups].sort((a, b) => (chosen.has(b.name) - chosen.has(a.name)) || (already.includes(a.name) - already.includes(b.name)))
        .filter((g) => !q || g.name.toLowerCase().includes(q)).forEach((g) => {
          const l = document.createElement('label'); l.className = 'check group-row';
          const c = document.createElement('input'); c.type = 'checkbox'; c.checked = chosen.has(g.name); c.disabled = already.includes(g.name);
          c.onchange = () => { if (c.checked && chosen.size >= 20) { c.checked = false; return; } c.checked ? chosen.add(g.name) : chosen.delete(g.name); count(); };
          const t = document.createElement('span'); t.textContent = g.name;
          const m = document.createElement('small'); m.className = 'muted'; m.textContent = already.includes(g.name) ? 'Already posted here' : [g.members && `${g.members} members`, g.privacy].filter(Boolean).join(' · ');
          l.append(c, t, m); list.appendChild(l);
        });
    };
    const count = () => { $('.gpost', dlg).textContent = chosen.size ? `Post to ${chosen.size} group${chosen.size === 1 ? '' : 's'}` : 'Pick groups'; $('.gpost', dlg).disabled = !chosen.size; };
    $('.gfilter', dlg).oninput = draw;
    draw(); count();
    dlg.showModal();
    const v = await new Promise((r) => dlg.addEventListener('close', () => r(dlg.returnValue), { once: true }));
    if (v !== 'ok' || !chosen.size) return null;
    if ($('.gsave', dlg).checked) { state.settings.groups = [...chosen]; state.settings.groupsAt = Date.now(); await chrome.storage.local.set({ settings: state.settings }); }
    return [...chosen];
  }

  // One-tap fixes for a slow post. (Price follows the dealer website, so it isn't one of them.)
  function showFixes(it, key) {
    const { l, f } = it;
    let dlg = document.getElementById('fixDlg');
    if (!dlg) { dlg = document.createElement('dialog'); dlg.id = 'fixDlg'; dlg.className = 'group-dlg'; document.body.appendChild(dlg); }
    const canRelist = l && f.days >= 21 && !(l.relistedAt && Date.now() - l.relistedAt < 30 * 86400000);
    dlg.innerHTML = `<form method="dialog"><h2></h2><p class="hint"></p><div class="fixes"></div><div class="actions"><button value="x" class="secondary">Close</button></div></form>`;
    $('h2', dlg).textContent = `${f.title}: ${f.cpd}/day`;
    $('.hint', dlg).textContent = `Up ${f.days} days, ${f.clicks} clicks. Your other cars average more. Try one fix, give it 3 days, then check again.`;
    const fixes = [
      l && ['New first photo', 'Puts a different front shot first (on Facebook too). The app compares clicks/day after 3 days.', () => newFirstPhoto(l.id)],
      l && ['Things to mention', 'Add what makes this car worth a look (new tires, one owner, no smoke…), then rewrite and update the post.', () => openInEditor(l.id)],
      ['List in groups', (f.groups || []).length ? `In ${f.groups.length} groups now. Add a couple of local car groups.` : 'Not in any groups yet. Add 3 to 5 local car buy/sell groups.', () => listInGroups(it, key)],
      l && (canRelist ? ['Re-list fresh', 'Takes this post down and posts the car again as new (at busy hours). Once a month per car.', () => doRelist(l, f)]
        : ['Re-list fresh', f.days < 21 ? `Available after 3 weeks up (day ${f.days}).` : 'Already re-listed this month.', null]),
    ].filter(Boolean);
    fixes.forEach(([t, d, fn]) => {
      const row = document.createElement('div'); row.className = 'fix';
      const b = document.createElement('button'); b.type = 'button'; b.className = fn ? 'primary' : 'secondary'; b.textContent = t; b.disabled = !fn;
      b.onclick = () => { dlg.close(); fn(); };
      const p = document.createElement('span'); p.className = 'muted'; p.textContent = d;
      row.append(b, p); $('.fixes', dlg).appendChild(row);
    });
    dlg.showModal();
  }
  async function doRelist(l, f) {
    if (!confirm(`Re-list "${f.title}" fresh?\n\nThe current post (${f.clicks} clicks) is taken down and the car is posted again as new${S.isBusyTime() ? '' : ' at the next busy time'}. Its saves and messages stay with the old post.`)) return;
    say(`Re-listing ${f.title}…`);
    const r = await chrome.runtime.sendMessage({ type: 'relist', id: l.id });
    if (!r || !r.ok) { problem(`${f.title} not re-listed`, new Error((r && r.error) || 'Something went wrong'), () => doRelist(l, f)); return; }
    say(`${f.title}: ${r.message}.`, 'ok');
  }

  // ---------- Performance view ----------
  function spark(hist) {
    const h = (hist || []).slice(-14);
    if (h.length < 2) return '';
    const daily = h.slice(1).map((x, i) => Math.max(0, x[1] - h[i][1]));
    const max = Math.max(1, ...daily);
    const w = 84, ht = 22, step = w / Math.max(1, daily.length - 1);
    const pts = daily.map((v, i) => `${(i * step).toFixed(1)},${(ht - (v / max) * (ht - 2) - 1).toFixed(1)}`).join(' ');
    return `<svg class="spark" viewBox="0 0 ${w} ${ht}" width="${w}" height="${ht}" aria-hidden="true"><polyline points="${pts}" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>`;
  }
  async function renderPerf() {
    await loadFb();
    const live = D.fb.filter((f) => (f.status || 'Active') === 'Active' && /^\d{4}\s/.test(f.title)).sort((a, b) => (b.cpd || 0) - (a.cpd || 0));
    const avg = live.length ? live.reduce((s, f) => s + (f.cpd || 0), 0) / live.length : 0;
    const total = live.reduce((s, f) => s + (f.clicks || 0), 0);
    const { dealerNews, dealerWatchAt } = await chrome.storage.local.get(['dealerNews', 'dealerWatchAt']);
    $('#perfSummary').innerHTML = '';
    [[live.length, 'Active posts'], [total, 'Total clicks'], [avg.toFixed(1), 'Avg clicks/day per car'], [live.filter((f) => f.slow).length, 'Slow posts']].forEach(([n, t]) => {
      const d = document.createElement('div'); d.className = 'stat'; d.innerHTML = '<b></b><span></span>'; d.querySelector('b').textContent = n; d.querySelector('span').textContent = t; $('#perfSummary').appendChild(d);
    });
    const tb = $('#perfTable tbody'); tb.innerHTML = '';
    for (const f of live) {
      const it = items().find((x) => x.f === f) || { f };
      const tr = document.createElement('tr');
      tr.innerHTML = `<td class="t"></td><td>${f.days || ''}</td><td>${f.clicks || 0}</td><td><b>${f.cpd != null ? f.cpd : ''}</b> ${f.trend === 'up' ? '<span class="up">↑</span>' : f.trend === 'down' ? '<span class="down">↓</span>' : ''}</td><td>${spark(f.hist)}</td><td>${(f.groups || []).length}</td><td class="act"></td>`;
      $('.t', tr).textContent = f.title;
      if (f.slow) { const b = document.createElement('button'); b.className = 'flag warn'; b.textContent = 'Slow: fixes ▾'; b.onclick = () => showFixes(it, it.l ? it.l.id : f.title); $('.act', tr).appendChild(b); }
      tb.appendChild(tr);
    }
    $('#perfEmpty').hidden = !!live.length;
    // Groups: average clicks/day of the cars in each group.
    const byGroup = {};
    live.forEach((f) => (f.groups || []).forEach((g) => { (byGroup[g] = byGroup[g] || []).push(f.cpd || 0); }));
    const gb = $('#perfGroups tbody'); gb.innerHTML = '';
    Object.entries(byGroup).map(([g, v]) => [g, v.length, v.reduce((a, b) => a + b, 0) / v.length]).sort((a, b) => b[2] - a[2]).forEach(([g, n, c]) => {
      const tr = document.createElement('tr'); tr.innerHTML = `<td class="t"></td><td>${n}</td><td>${c.toFixed(1)}</td>`; $('.t', tr).textContent = g; gb.appendChild(tr);
    });
    const notIn = live.filter((f) => !(f.groups || []).length);
    $('#perfGroupsNote').textContent = Object.keys(byGroup).length ? `Cars in no group average ${notIn.length ? (notIn.reduce((s, f) => s + (f.cpd || 0), 0) / notIn.length).toFixed(1) : '-'} clicks/day. Keep the groups near the top; drop ones that don't help.` : 'No group posts yet.';
    // First-photo tests
    const tests = []; state.listings.forEach((l) => (l.heroTests || []).forEach((t) => { const f = D.fb.find((x) => fbMatches(l, x)); if (f) tests.push({ l, f, t, after: S.clicksPerDaySince(f, t.day) }); }));
    const tt = $('#perfTests'); tt.innerHTML = '';
    tests.sort((a, b) => b.t.at - a.t.at).slice(0, 10).forEach(({ f, t, after }) => {
      const li = document.createElement('li');
      const days = Math.round((Date.now() - t.at) / 86400000);
      li.textContent = `${f.title}: ${new Date(t.at).toLocaleDateString()}, ${t.before != null ? t.before.toFixed(1) : '?'} → ${after != null && days >= 1 ? after.toFixed(1) : '…'} clicks/day${days < 3 ? ' (still testing)' : ''}`;
      tt.appendChild(li);
    });
    if (!tests.length) tt.innerHTML = '<li class="muted">No photo tests yet. "Slow" posts offer one.</li>';
    const pc = (dealerNews && dealerNews.prices) || [];
    $('#perfDealer').textContent = dealerWatchAt ? `Dealer website checked ${new Date(dealerWatchAt).toLocaleString()}.${pc.length ? ' Price changes: ' + pc.map((p) => `${p.title} $${p.from.toLocaleString()} → $${p.to.toLocaleString()}`).join(', ') + '.' : ''}` : 'Dealer website not checked yet.';
  }

  function showGroupList(f, it, key) {
    let dlg = document.getElementById('groupListDlg');
    if (!dlg) { dlg = document.createElement('dialog'); dlg.id = 'groupListDlg'; dlg.className = 'group-dlg'; document.body.appendChild(dlg); }
    const gs = f.groups || [];
    dlg.innerHTML = '<form method="dialog"><h2></h2><p class="hint"></p><ul class="glist"></ul><div class="actions"><button value="check" class="secondary">Check on Facebook</button><button value="list" class="secondary">List in more groups</button><button value="ok" class="primary">Close</button></div></form>';
    $('h2', dlg).textContent = gs.length ? `${f.title}: ${gs.length} group${gs.length === 1 ? '' : 's'}` : f.inGroups ? `${f.title}: in groups` : `${f.title}: no groups yet`;
    $('.hint', dlg).textContent = !gs.length && f.inGroups ? `Facebook says it's in at least one group${f.originGroup ? ' (first posted in ' + f.originGroup + ')' : ''}. Tap "Check on Facebook" to see which ones.` : f.groupsCheckedAt ? `Checked on Facebook ${new Date(f.groupsCheckedAt).toLocaleString()}.`
      : gs.length ? 'Groups the app posted it to. "Check on Facebook" also finds ones you posted yourself.' : 'The app hasn\'t posted it to any groups. "Check on Facebook" finds groups you posted it to yourself.';
    gs.forEach((g) => { const li = document.createElement('li'); li.textContent = g; $('.glist', dlg).appendChild(li); });
    dlg.onclose = () => {
      if (dlg.returnValue === 'check') checkGroupsFor([f]);
      if (dlg.returnValue === 'list' && it) listInGroups(it, key);
    };
    dlg.showModal();
  }

  // Read-only pass over your active posts: which groups each one is in.
  async function checkAllGroups() {
    const live = items().filter((it) => it.f && it.f.status === 'Active' && /^\d{4}\s/.test(it.f.title));
    if (!live.length) { say('No active posts.', 'err'); return; }
    return checkGroupsFor(live.map((it) => it.f));
  }
  async function checkGroupsFor(list) {
    const b = $('#groupsCheckBtn'); b.disabled = true;
    try {
      const res = await runJob({ kind: 'groupsCheck', items: list.map((f) => ({ title: f.title, price: f.price })) }, `Checking which groups ${list.length === 1 ? `"${list[0].title}" is` : `your ${list.length} posts are`} in (nothing is posted)`);
      if (!res.ok) throw new Error(res.error);
      await loadFb();
      const n = Object.values(res.inGroups || {}).filter((x) => x.length).length;
      say(`Checked ${Object.keys(res.inGroups || {}).length} posts on Facebook; ${n} are in groups. Click "In N groups" on a box to see which.`, 'ok');
    } catch (e) {
      problem("Couldn't check groups", e, () => checkGroupsFor(list));
    } finally { b.disabled = false; render(); }
  }

  async function listInGroups(it, key, picked) {
    const groups = picked || (await pickGroups(`List "${it.f.title}" in groups`, it.f.groups || []));
    if (!groups) return;
    D.busy.add(key); render();
    try {
      const res = await runJob({ kind: 'groupsPost', title: it.f.title, price: it.f.price, groups }, 'Listing in your groups');
      if (!res.ok) throw new Error(res.error);
      say(`${it.f.title}: ${res.message}.`, 'ok');
    } catch (e) {
      problem(`${it.f.title} not listed in groups`, e, () => listInGroups(it, key, groups));
    } finally {
      D.busy.delete(key);
      render();
    }
  }

  // Every live post (or the ones checked) into groups, one car every 5 to 10 minutes.
  async function listAllInGroups() {
    const live = items().filter((it) => it.f && it.f.status === 'Active');
    if (!live.length) { say('No active posts to list.', 'err'); return; }
    const groups = await pickGroups(`List ${live.length} active post${live.length === 1 ? '' : 's'} in groups`);
    if (!groups) return;
    const todo = live.map((it) => ({ title: it.f.title, price: it.f.price, groups: groups.filter((g) => !(it.f.groups || []).includes(g)) })).filter((x) => x.groups.length);
    if (!todo.length) { say('Those posts are already in those groups.', 'ok'); return; }
    const r = await chrome.runtime.sendMessage({ type: 'queueGroups', items: todo });
    say(`${todo.length} post${todo.length === 1 ? '' : 's'} lined up for groups. One car goes every 5 to 10 minutes so Facebook sees a normal pace (${r.waiting} waiting).`, 'ok');
  }

  async function fbAction(it, key, action) {
    const { f, l } = it;
    if (action === 'delete' && !confirm(`Delete "${f.title}" from Facebook? This can't be undone.${l ? '\n\nThe car stays in this app so you can post it again.' : ''}`)) return;
    D.busy.add(key); render();
    try {
      const res = await runJob({ kind: 'action', action, title: f.title, price: f.price }, `${ACTION_TEXT[action][0]} on Facebook`);
      if (!res.ok) throw new Error(res.error);
      await loadFb();
      if (l && action === 'delete') { l.status = 'draft'; await saveNow(); renderList(); }
      say(`${f.title} ${ACTION_TEXT[action][1]}.`, 'ok');
    } catch (e) {
      problem(`${f.title}: ${ACTION_TEXT[action][0].toLowerCase()} didn't finish`, e, () => fbAction(it, key, action));
    } finally {
      D.busy.delete(key);
      render();
    }
  }

  // Read the descriptions of your best posts (by clicks per day) so the AI can
  // learn what works. Read only: nothing on Facebook is changed. One at a time,
  // in background tabs; posts it can't reach quietly are skipped.
  let learning = false;
  async function learnFromBest({ quiet = false } = {}) {
    if (learning) return;
    learning = true;
    try {
      const { fbDescriptions = {} } = await chrome.storage.local.get('fbDescriptions');
      const todo = S.postsToLearnFrom(D.fb, fbDescriptions, 3);
      if (!todo.length) { if (!quiet) say('Already learned from your best posts. It checks again after your next sync.', 'ok'); return; }
      let got = 0;
      for (const f of todo) {
        try {
          const res = await runJob({ kind: 'readDesc', title: f.title, price: f.price, id: f.id || '', quiet: true }, `Reading your post "${f.title}" to learn from it`, quiet);
          fbDescriptions[S.fbKey(f)] = { text: (res.ok && res.description) || '', at: Date.now() };
          if (res.ok && res.description) got++;
        } catch (e) {
          fbDescriptions[S.fbKey(f)] = { text: '', at: Date.now() };
        }
        await chrome.storage.local.set({ fbDescriptions });
      }
      if (!quiet) say(got ? `Learned from ${got} of your best post${got === 1 ? '' : 's'}. New descriptions will use what works in them.` : "Couldn't read those posts this time. It will try again after the next sync.", got ? 'ok' : 'err');
    } finally {
      learning = false;
    }
  }

  // ---------- renew ----------
  async function renewNow() {
    const b = $('#renewNowBtn');
    b.disabled = true;
    say('Renewing your car listings that are ready (in a background tab)…');
    try {
      const r = await chrome.runtime.sendMessage({ type: 'renewNow' });
      if (!r || !r.ok) throw new Error((r && r.error) || 'Could not renew');
      const n = r.result.renewed.length;
      say(n ? `Renewed ${n}: ${r.result.renewed.join(', ')}.` : 'Nothing was ready to renew yet. Facebook allows it about once a week per listing.', 'ok');
      if (n) sync({ quiet: true });
    } catch (e) {
      problem("Renew didn't finish", e);
    } finally {
      b.disabled = false;
      render();
    }
  }

  async function setAutoRenew(on) {
    state.settings.autoRenew = on;
    state.settings.switchesAt = Date.now();
    await chrome.storage.local.set({ settings: state.settings });
    chrome.runtime.sendMessage({ type: 'cloudSyncNow' }).catch(() => {});
    say(on ? 'Auto renew is on. Once a day between 9am and 7pm, car listings that are ready get renewed in a background tab (Edge needs to be open).' : 'Auto renew is off.', 'ok');
    render();
  }

  async function setAutoPost(on) {
    if (on && !confirm('With Auto post on, each listing publishes by itself right after it fills in, without you checking it first. It only publishes when every field filled without a problem.\n\nTurn Auto post on?')) {
      $('#autoPostToggle').checked = false;
      return;
    }
    state.settings.autoPost = on;
    state.settings.switchesAt = Date.now();
    await chrome.storage.local.set({ settings: state.settings });
    chrome.runtime.sendMessage({ type: 'cloudSyncNow' }).catch(() => {});
    say(on ? 'Auto post is on. Listings publish right after they fill in.' : 'Auto post is off. You review and publish each listing yourself.', 'ok');
    render();
  }

  // ---------- init ----------
  function postedToast(names) {
    let t = document.getElementById('postedToast');
    if (!t) { t = document.createElement('div'); t.id = 'postedToast'; t.className = 'posted-toast'; document.body.appendChild(t); }
    t.innerHTML = '<span class="ck">✓</span><div><strong>Posted complete</strong><span></span></div>';
    t.querySelector('div span').textContent = `${names.join(', ')} ${names.length === 1 ? 'is' : 'are'} live on Facebook Marketplace.`;
    t.hidden = false;
    clearTimeout(t._h);
    t._h = setTimeout(() => (t.hidden = true), 7000);
    t.onclick = () => (t.hidden = true);
  }

  window.Dash = {
    show: (name) => showView(name),
    runJob,
    async init() {
      await loadFb();
      $('#tabDash').onclick = () => showView('dash');
      $('#tabPerf').onclick = () => showView('perf');
      $('#dealerCheckBtn').onclick = async () => {
        const b = $('#dealerCheckBtn'); b.disabled = true; b.textContent = 'Checking the dealer website…';
        const r = await chrome.runtime.sendMessage({ type: 'dealerWatch' });
        b.disabled = false; b.textContent = 'Check dealer prices now';
        say(r && r.ok ? `Checked ${r.checked} cars on the dealer website: ${r.prices} price change${r.prices === 1 ? '' : 's'}${r.gone ? `, ${r.gone} no longer listed` : ''}.` : `Couldn't check: ${r && r.error}`, r && r.ok ? 'ok' : 'err');
        renderPerf();
      };
      $('#tabWork').onclick = () => showView('work');
      $('#syncBtn').onclick = () => sync();
      $('#fullSyncBtn').onclick = () => sync({ full: true });
      $('#copyLogBtn').onclick = (ev) => copyLog(ev.target);
      $('#learnBtn').onclick = () => learnFromBest();
      $('#autoPostToggle').onchange = (e) => setAutoPost(e.target.checked);
      $('#autoRenewToggle').onchange = (e) => setAutoRenew(e.target.checked);
      $('#groupsAllBtn').onclick = listAllInGroups;
      $('#groupsCheckBtn').onclick = checkAllGroups;
      $('#renewNowBtn').onclick = renewNow;
      $('#dashSearch').oninput = (e) => { D.search = e.target.value; render(); };
      const sortSel = $('#dashSort');
      Object.entries(S.SORTS).forEach(([k, label]) => sortSel.appendChild(new Option(label, k)));
      try { D.sort = localStorage.getItem('lhSort') || 'newest'; } catch (e) { D.sort = 'newest'; }
      sortSel.value = D.sort;
      sortSel.onchange = () => { D.sort = sortSel.value; try { localStorage.setItem('lhSort', D.sort); } catch (e) {} render(); };
      $$('#dashFilters .fchip').forEach((b) => {
        b.onclick = () => {
          D.filter = b.dataset.f;
          $$('#dashFilters .fchip').forEach((x) => x.classList.toggle('active', x === b));
          render();
        };
      });
      // Keep in step with Facebook tabs (auto post) and other app tabs.
      chrome.storage.onChanged.addListener(async (ch) => {
        // A car's posting tab was closed or hit a login page before it published.
        if (ch.postProblem && ch.postProblem.newValue) {
          const p = ch.postProblem.newValue;
          problem(`${p.title} wasn't posted`, Object.assign(new Error(p.error), { code: p.code, tabId: p.tabId }), () => post([p.id]));
        }
        // A car just went live on Facebook: say so.
        if (ch.listings) {
          const before = new Map((ch.listings.oldValue || []).map((l) => [l.id, l.status]));
          const done = (ch.listings.newValue || []).filter((l) => l.status === 'posted' && before.has(l.id) && before.get(l.id) !== 'posted');
          if (done.length) postedToast(done.map((l) => `${l.fb.year} ${l.fb.make} ${l.fb.model}`));
        }
        if (ch.listings && !saveTimer) { state.listings = ch.listings.newValue || []; renderList(); }
        if (ch.settings && ch.settings.newValue) { state.settings.autoPost = !!ch.settings.newValue.autoPost; state.settings.autoRenew = !!ch.settings.newValue.autoRenew; state.settings.switchesAt = ch.settings.newValue.switchesAt; }
        if (ch.fbListings) await loadFb();
        if (ch.listings || ch.fbListings || ch.settings || ch.postQueueInfo) { render(); if (!$('#perfView').hidden) renderPerf(); }
      });
      setInterval(() => { if (!$('#dashView').hidden) $('#syncInfo').textContent = D.syncedAt ? `Last synced ${timeAgo(D.syncedAt)}` : 'Not synced yet'; }, 60000);
      showView(params.get('view') === 'work' ? 'work' : 'dash');
      // Opening the app: catch up with Facebook if the last sync is more than 5 minutes old.
      if (!params.get('cmd') && D.fb.length && Date.now() - D.syncedAt > 5 * 60000) setTimeout(() => sync({ quiet: true }), 1500);
      document.addEventListener('visibilitychange', () => { if (!document.hidden && !params.get('cmd') && D.fb.length && Date.now() - D.syncedAt > 5 * 60000) sync({ quiet: true }); });
    },
    render,
    // For the vehicle editor: the live Facebook listing for a car, if any.
    liveFor(id) { const it = items().find((x) => x.l && x.l.id === id); return it && it.f && it.f.status !== 'Sold' ? it : null; },
    async updateDesc(id, { noConfirm = false } = {}) {
      const it = items().find((x) => x.l && x.l.id === id);
      if (!it || !it.f) return false;
      const { l, f } = it;
      if (!noConfirm && !confirm(`Replace the description on the live Facebook post "${f.title}" with the one in the app?`)) return false;
      const key = l.id;
      D.busy.add(key); render();
      try {
        const res = await runJob({ kind: 'desc', title: f.title, price: f.price, id: f.id || '', description: l.fb.description }, 'Updating the description on Facebook');
        if (!res.ok) throw new Error(res.error);
        say(`${f.title}: description updated on Facebook.`, 'ok');
        return true;
      } catch (e) {
        problem('Description not updated on Facebook', e, () => window.Dash.updateDesc(id, { noConfirm: true }));
        return false;
      } finally { D.busy.delete(key); render(); }
    },
    updatePhotos(id, opts) { const it = items().find((x) => x.l && x.l.id === id); if (it && it.f) { if (!(opts && opts.noConfirm)) showView('dash'); return updatePhotos(it, it.l.id, opts); } return Promise.resolve(false); },
  };
})();
