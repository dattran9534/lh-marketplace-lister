const S = window.LHShared;
const IMG = window.LHImage;
const AI = window.LHAI;
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];

const state = { listings: [], settings: { ...S.DEFAULT_SETTINGS }, selectedId: null, filter: 'active', checked: new Set(), busy: false };
const params = new URLSearchParams(location.search);
const srcTabId = params.get('src') ? Number(params.get('src')) : null;

// ---------- storage ----------
async function load() {
  const d = await chrome.storage.local.get(['listings', 'settings']);
  state.listings = d.listings || [];
  state.settings = { ...S.DEFAULT_SETTINGS, ...(d.settings || {}) };
  // Your Supabase project is built in; fill it in if it was saved empty.
  if (!state.settings.cloudUrl || !state.settings.cloudKey) {
    state.settings.cloudUrl = S.DEFAULT_SETTINGS.cloudUrl;
    state.settings.cloudKey = S.DEFAULT_SETTINGS.cloudKey;
    await chrome.storage.local.set({ settings: state.settings });
  }
}
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { saveTimer = null; chrome.storage.local.set({ listings: state.listings }); }, 250);
}
async function saveNow() {
  clearTimeout(saveTimer);
  saveTimer = null;
  await chrome.storage.local.set({ listings: state.listings });
}
const current = () => state.listings.find((l) => l.id === state.selectedId);
const send = (msg) => chrome.runtime.sendMessage(msg);
const aiCfg = () => {
  const provider = state.settings.aiProvider === 'anthropic' ? 'anthropic' : 'gemini';
  return { provider, key: ((provider === 'gemini' ? state.settings.geminiKey : state.settings.apiKey) || '').trim() };
};
const aiReady = () => !!aiCfg().key;
const PROVIDER = {
  gemini: { name: 'Gemini', keyName: 'Google AI Studio API key', placeholder: 'AIza...', help: 'Free. Get one at aistudio.google.com (Get API key). Stored only in this browser.' },
  anthropic: { name: 'Claude', keyName: 'Anthropic API key', placeholder: 'sk-ant-...', help: 'Paid per use. Get one at console.anthropic.com. Stored only in this browser.' },
};

function setStatus(msg, kind = '') {
  const el = $('#importStatus');
  el.textContent = msg;
  el.className = 'status ' + kind;
}

// ---------- the import pipeline ----------
async function pool(items, n, fn) {
  const out = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); }
  }));
  return out;
}

// A CARFAX link you paste (from a share link, an email, a text): pulls the link out of whatever
// was pasted. Only carfax.com links are used.
// any: from the CARFAX box, where any link is taken (work apps may hand out their own short links);
// the report itself must still open as a CARFAX report.
function cleanCarfaxUrl(text, any) {
  const m = String(text || '').match(any ? /https?:\/\/[^\s"'<>]+/i : /https?:\/\/[^\s"'<>]*carfax[^\s"'<>]*/i);
  if (!m) return '';
  try { const u = new URL(m[0]); return any || /(^|\.)carfax(online)?\.com$/i.test(u.hostname) ? u.href : ''; } catch (e) { return ''; }
}

// Use a CARFAX link you pasted for a car already in the app: read it, then rewrite the description
// with its good points (your own edited description is kept).
async function applyCarfaxLink(l, text, say, { rewrite = true } = {}) {
  const url = cleanCarfaxUrl(text, true);
  if (!url) throw new Error("That isn't a link. Copy the CARFAX link (it starts with https://) and paste it.");
  l.raw.carfaxUrl = url;
  l.raw.carfaxUrlMine = url;
  l.carfax = await getCarfax(l.raw, say);
  if (l.carfax && l.carfax.error) { await saveNow(); throw new Error(`Saved the link, but ${l.carfax.error.charAt(0).toLowerCase() + l.carfax.error.slice(1)}. Open it once to check it loads, then try again.`); }
  if (l.carfax && l.carfax.cleanTitle) l.fb.cleanTitle = true;
  let kept = false;
  if (l.descBy === 'edited' || !rewrite) kept = l.descBy === 'edited';
  else {
    const d = await writeDescription(l, say);
    l.fb.description = d.text; l.descBy = d.by; l.descError = d.error || '';
  }
  l.updatedAt = Date.now();
  await saveNow();
  return { kept };
}

async function getCarfax(raw, say) {
  if (!raw.carfaxUrl) return null;
  say('reading the CARFAX report');
  const r = await send({ type: 'extractCarfax', url: raw.carfaxUrl });
  if (!r || !r.ok) return { error: (r && r.error) || 'CARFAX unavailable', positives: [], negatives: [] };
  const c = S.parseCarfax(r.text);
  return c ? { ...c, url: raw.carfaxUrl } : { error: 'Could not read the CARFAX report', positives: [], negatives: [] };
}

// A photo's bytes, wherever it lives: your PC, the cloud (added on the phone), or the dealer site.
function analyzeOne(im) {
  if (im.local) return LHLocal.get(im.local).then((b) => IMG.analyze('', '', b));
  if (im.cloud) {
    const c = cloudClient();
    return c ? c.photos.download(im.cloud).then((b) => IMG.analyze('', '', b)) : Promise.resolve({ cropTop: 0, thumb: null });
  }
  return IMG.analyze(im.url, im.fallback);
}
const isStockUrl = (u) => /stock_images|stockphoto|\/stock\//i.test(u || '');

// Banner check on every photo, then (optionally) AI sorting.
async function processPhotos(images, say, { sort = true } = {}) {
  say('checking photos');
  const results = await pool(images, 6, (im) => analyzeOne(im).catch(() => ({ cropTop: 0, thumb: null })));
  let out = images.map((im, i) => ({ ...im, cropTop: results[i].cropTop }));
  let note = '', colors = null;
  if (aiReady() && results.some((r) => r.thumb)) {
    const sorting = sort && state.settings.sortPhotos;
    say(sorting ? 'sorting photos and reading colors with AI' : 'reading colors with AI');
    try {
      const c = await AI.classifyPhotos(aiCfg(), results.map((r) => r.thumb));
      // A catalog picture shows a random color, not this car.
      if (!images.every((im) => isStockUrl(im.url))) colors = { exteriorColor: c.exteriorColor, interiorColor: c.interiorColor };
      if (sorting) { out = AI.sortImages(out, c.labels, c.hero, c.views); note = 'sorted'; }
    } catch (e) {
      note = 'AI photo check failed: ' + e.message;
    }
  }
  // The dealer's waterfront hero shot is the one that carries the banner: it goes first.
  const heroIdx = out.findIndex((im) => im.cropTop > 0 && (!im.kind || im.kind === 'exterior' || im.kind === 'unknown'));
  if (heroIdx > 0) out.unshift(out.splice(heroIdx, 1)[0]);
  const max = state.settings.maxPhotos || 20;
  // First 20 that aren't "other" (engine bay, keys, papers); free slots go to the rest.
  let on = 0;
  out.forEach((im) => { im.on = im.kind !== 'other' && on < max; if (im.on) on++; });
  out.forEach((im) => { if (!im.on && on < max) { im.on = true; on++; } });
  return { images: out, note, colors };
}

async function writeDescription(rec, say) {
  const fallback = S.describe(rec.raw, rec.fb, state.settings, rec.carfax);
  if (!state.settings.useAI || !aiReady()) return { text: fallback, by: 'template' };
  say('writing the description');
  try {
    const facts = S.factsFor(rec.raw, rec.fb, rec.carfax, state.settings);
    const { fbListings = [], fbDescriptions = {} } = await chrome.storage.local.get(['fbListings', 'fbDescriptions']);
    const learn = S.learningSet(state.listings, fbListings, rec.id, fbDescriptions);
    const text = await AI.writeDescription(aiCfg(), facts, state.settings.opening, learn, fallback, S.mustKeep(rec.raw, rec.fb, rec.carfax));
    rec.learnedFrom = { winners: learn.winners.map((w) => `${w.title} (${w.clicks} clicks)`), edits: learn.edits.length };
    return { text, by: 'ai' };
  } catch (e) {
    return { text: fallback, by: 'template', error: e.message };
  }
}

// Exterior: the dealer's paint name when it maps cleanly, else what the AI sees.
// Interior: what the AI sees in the photos (dealer interior names are often vague), else the dealer's.
// Facebook needs both before Next/Publish works.
function applyColors(rec, ai) {
  rec.aiColors = ai || rec.aiColors || null;
  const a = rec.aiColors || {};
  rec.fb.exteriorColor = S.mapColor(rec.raw.exteriorColor, S.EXT_RULES) || a.exteriorColor || rec.fb.exteriorColor || '';
  rec.fb.interiorColor = a.interiorColor || S.mapColor(rec.raw.interiorColor, S.INT_RULES) || rec.fb.interiorColor || '';
}

// Cars imported before color detection: look at a few photos once.
async function ensureColors(l) {
  if ((l.fb.exteriorColor && l.fb.interiorColor) || !aiReady()) return;
  try {
    const picks = (l.images || []).filter((i) => i.on).slice(0, 10);
    const res = await pool(picks.filter((im) => !isStockUrl(im.url)), 5, (im) => analyzeOne(im).catch(() => ({ thumb: null })));
    applyColors(l, await AI.detectColors(aiCfg(), res.map((r) => r.thumb)));
    await saveNow();
  } catch (e) {}
}

// extra: { photos: [cloud paths from the phone], onlyMine: true to drop the dealer's photos }
async function buildRecord(raw, existing, say, extra = {}) {
  // Your notes for the description: new ones from the import box, or the ones the car already had.
  // A CARFAX link you pasted (for cars whose report isn't on the dealer page yet) is kept on re-import.
  const myCarfax = cleanCarfaxUrl(extra.carfaxUrl, true) || (existing && existing.raw && existing.raw.carfaxUrlMine) || '';
  if (myCarfax) { raw.carfaxUrlMine = myCarfax; if (!raw.carfaxUrl || cleanCarfaxUrl(extra.carfaxUrl, true)) raw.carfaxUrl = myCarfax; }
  raw.highlights = (extra.highlights != null && String(extra.highlights).trim()) ? String(extra.highlights).trim() : (existing && existing.raw && existing.raw.highlights) || '';
  // Your own photos (added on the PC or the phone) are kept when re-importing.
  const mine = existing ? (existing.images || []).filter((im) => im.local || im.cloud).map(({ local, cloud }) => ({ local, cloud, url: '', fallback: '' })) : [];
  (extra.photos || []).forEach((cloud) => { if (!mine.some((m) => m.cloud === cloud)) mine.push({ cloud, url: '', fallback: '' }); });
  (extra.localPhotos || []).forEach((local) => { if (!mine.some((m) => m.local === local)) mine.push({ local, url: '', fallback: '' }); });
  let dealer = (raw.images || []).map((im) => ({ url: im.url, fallback: im.fallback || '' }));
  // The dealer's generic catalog picture goes away as soon as you have real photos.
  if (mine.length && (extra.onlyMine || raw.stockPhotos)) dealer = [];
  const photosP = processPhotos(mine.length && !dealer.length ? mine : [...dealer, ...mine], say);
  photosP.catch(() => {});
  // The trim's best features: from the dealer's list, or the AI's knowledge of the trim when the list is thin.
  const featsP = S.keyFeatures(raw).length >= 3 || !aiReady() ? null
    : AI.trimFeatures(aiCfg(), `${raw.year} ${raw.make} ${raw.model} ${raw.trim || ''}`.trim()).then((f) => { raw.trimFeatures = f; }).catch(() => {});
  // Market check: only call it rare / in demand when that's true (kept for 2 weeks per car).
  const old = existing && existing.raw && existing.raw.market;
  const marketP = old && Date.now() - old.at < 14 * 86400000 ? Promise.resolve((raw.market = old))
    : !aiReady() ? null
    : AI.marketCheck(aiCfg(), { name: `${raw.year} ${raw.make} ${raw.model} ${raw.trim || ''}`.trim(), mileage: raw.mileage, extras: /manual/i.test(raw.transmission || '') ? 'manual transmission' : '' })
        .then((mk) => { raw.market = mk; }).catch(() => {});
  const [carfax] = await Promise.all([getCarfax(raw, say), featsP, marketP]);
  const rec = {
    id: existing ? existing.id : crypto.randomUUID(),
    createdAt: existing ? existing.createdAt : Date.now(),
    updatedAt: Date.now(),
    status: existing ? existing.status : 'draft',
    raw,
    carfax,
    images: [],
    photoNote: '',
  };
  rec.fb = S.toFacebook(raw, state.settings, carfax);
  const keepMine = existing && existing.descBy === 'edited' && existing.fb && existing.fb.description && !(extra.highlights && String(extra.highlights).trim());
  const [photos, d] = await Promise.all([photosP, keepMine ? null : writeDescription(rec, say)]);
  rec.images = photos.images;
  rec.photoNote = photos.note;
  rec.stockOnly = rec.images.length > 0 && rec.images.every((im) => isStockUrl(im.url));
  applyColors(rec, photos.colors);
  if (keepMine) {
    // Keep your own rewrite; re-import only refreshes price, miles, photos and CARFAX.
    rec.fb.description = existing.fb.description;
    rec.descBy = 'edited';
    return rec;
  }
  rec.fb.description = d.text;
  rec.descBy = d.by;
  rec.descError = d.error || '';
  return rec;
}

function upsert(rec) {
  const i = state.listings.findIndex((l) => l.id === rec.id);
  if (i >= 0) state.listings[i] = rec;
  else state.listings.unshift(rec);
}

async function importOne(getRaw, label, onStep, extra) {
  const say = (step) => { setStatus(`${label}: ${step}…`); if (onStep) onStep(step); };
  say('reading the dealer page');
  const raw = await getRaw();
  const existing = (raw.vin && state.listings.find((l) => l.raw && l.raw.vin === raw.vin))
    || (extra && extra.manualId && state.listings.find((l) => l.id === extra.manualId));
  const rec = await buildRecord(raw, existing, say, extra);
  upsert(rec);
  await saveNow();
  renderList();
  return rec;
}

async function importUrls(urls, carfaxText) {
  urls = [...new Set(urls.map((u) => u.trim()).filter((u) => /^https?:\/\//i.test(u)))];
  // CARFAX links can go in the CARFAX box or in with the vehicle links.
  const carfaxes = [...urls.filter((u) => cleanCarfaxUrl(u)), ...String(carfaxText || '').split(/\s+/).filter((u) => cleanCarfaxUrl(u, true))].map((u) => cleanCarfaxUrl(u, true));
  urls = urls.filter((u) => !cleanCarfaxUrl(u));
  if (!urls.length) { setStatus(carfaxes.length ? 'Paste the vehicle link from lynnwoodhonda.com too (the CARFAX link goes with it).' : 'Paste at least one vehicle link.', 'err'); return; }
  if (String(carfaxText || '').trim() && !carfaxes.length) { setStatus("The CARFAX box doesn't have a link in it.", 'err'); return; }
  // One CARFAX per car, in the same order; with several cars and one CARFAX we can't tell which car it's for.
  if (carfaxes.length && carfaxes.length !== urls.length) { setStatus(`You pasted ${urls.length} vehicle links and ${carfaxes.length} CARFAX link${carfaxes.length === 1 ? '' : 's'}. Import that car on its own, or paste one CARFAX per car in the same order.`, 'err'); return; }
  if (state.busy) return;
  state.busy = true;
  $('#importBtn').disabled = true;
  let ok = 0, last = null;
  const errors = [];
  const imported = [];
  for (let i = 0; i < urls.length; i++) {
    try {
      last = await importOne(async () => {
        const r = await send({ type: 'extractFromUrl', url: urls[i] });
        if (!r || !r.ok) throw new Error(r ? r.error : 'no response');
        return r.data;
      }, `Vehicle ${i + 1} of ${urls.length}`, null, { highlights: $('#highlights').value, carfaxUrl: carfaxes[i] || '' });
      imported.push(last);
      ok++;
    } catch (e) {
      errors.push(`${urls[i].replace(/^https?:\/\/(www\.)?[^/]+/, '').slice(0, 50)}: ${e.message}`);
    }
  }
  state.busy = false;
  $('#importBtn').disabled = false;
  if (last) select(last.id);
  if (errors.length) setStatus(`Imported ${ok}. Problems: ${errors.join(' · ')}`, 'err');
  else { setStatus(`Imported ${ok} vehicle${ok === 1 ? '' : 's'}.`, 'ok'); $('#urls').value = ''; $('#highlights').value = ''; $('#carfaxUrl').value = ''; }
  await autoPostAfterImport(imported);
}

// With Auto post on, newly imported cars go straight to Facebook (in background tabs).
async function autoPostAfterImport(recs) {
  if (!state.settings.autoPost) return;
  const stock = recs.filter((r) => r && r.stockOnly);
  const ready = recs.filter((r) => r && r.status !== 'posted' && !missingFields(r).length && !r.stockOnly);
  if (stock.length) setStatus(`Not auto posted: ${stock.map((r) => `${r.fb.year} ${r.fb.model}`).join(', ')} only has the dealer's generic catalog photo. Add your own photos, then post.`, 'err');
  if (!ready.length) return;
  await post(ready.map((r) => r.id), { quiet: true });
  setStatus(`Auto post: posting ${ready.length} vehicle${ready.length === 1 ? '' : 's'} in background tabs. They publish by themselves when they finish filling.`, 'ok');
}

// ---------- a car that isn't on the dealer website yet ----------
let manualDecoded = null;
async function manualLookup() {
  const vin = S.cleanVin($('#mVin').value);
  $('#mVin').value = vin;
  if (vin.length !== 17) { $('#mVinMsg').textContent = `A VIN has 17 characters (this has ${vin.length}).`; return; }
  $('#mVinMsg').textContent = 'Looking up the VIN…';
  try {
    const d = await S.decodeVin(vin);
    manualDecoded = d;
    $('#mYear').value = d.year; $('#mMake').value = d.make; $('#mModel').value = d.model; $('#mTrim').value = d.trim;
    $('#mDrive').value = d.drive === 'AWD' || d.drive === '4WD' ? d.drive : '';
    // Same car already in the app: start from what it has.
    const had = state.listings.find((l) => l.raw && l.raw.vin === vin);
    if (had) {
      $('#mMiles').value = had.raw.mileage || ''; $('#mPrice').value = had.raw.price || '';
      $('#mVinMsg').textContent = `${d.year} ${d.make} ${d.model} ${d.trim} — already in the app; saving updates it.`;
    } else $('#mVinMsg').textContent = `${d.year} ${d.make} ${d.model} ${d.trim}${d.drive && d.drive !== '2WD' ? ' ' + d.drive : ''}${d.engine ? ' · ' + d.engine : ''}`;
    $('#mTrim').focus();
  } catch (e) { manualDecoded = null; $('#mVinMsg').textContent = `${e.message} You can type the details yourself.`; }
}
function openManual() {
  manualDecoded = null;
  ['mVin', 'mYear', 'mMake', 'mModel', 'mTrim', 'mMiles', 'mPrice', 'mExt', 'mInt', 'mStock', 'mCarfax', 'mNotes'].forEach((id) => { $('#' + id).value = ''; });
  $('#mCarfax').value = $('#carfaxUrl').value.trim();
  $('#mNotes').value = $('#highlights').value.trim();
  $('#mDrive').value = ''; $('#mPhotos').value = ''; $('#mVinMsg').textContent = ''; $('#mMsg').textContent = ''; $('#mGo').disabled = false;
  $('#manualDlg').showModal();
  $('#mVin').focus();
}
async function addManualCar() {
  const v = (id) => $('#' + id).value.trim();
  const vin = S.cleanVin(v('mVin'));
  const missing = [!/^\d{4}$/.test(v('mYear')) && 'year', !v('mMake') && 'make', !v('mModel') && 'model', !v('mMiles') && 'miles', !v('mPrice') && 'price'].filter(Boolean);
  if (missing.length) { $('#mMsg').textContent = `Fill in: ${missing.join(', ')}.`; return; }
  if (vin && vin.length !== 17) { $('#mMsg').textContent = 'The VIN should have 17 characters (or leave it empty).'; return; }
  if (state.busy) { $('#mMsg').textContent = 'Another import is running. Try again in a moment.'; return; }
  const d = manualDecoded && manualDecoded.vin === vin ? manualDecoded : {};
  const raw = S.manualRaw({
    ...d, vin, year: v('mYear'), make: v('mMake'), model: v('mModel'), trim: v('mTrim'), drive: $('#mDrive').value || (d.drive === '2WD' ? '2WD' : ''),
    mileage: v('mMiles'), price: v('mPrice'), exteriorColor: v('mExt'), interiorColor: v('mInt'), stock: v('mStock'),
  });
  const files = [...$('#mPhotos').files];
  $('#mGo').disabled = true;
  state.busy = true;
  try {
    const localPhotos = [];
    for (const f of files) { $('#mMsg').textContent = `Saving photo ${localPhotos.length + 1} of ${files.length}…`; localPhotos.push(await LHLocal.add(f)); }
    $('#manualDlg').close();
    const rec = await importOne(async () => raw, `${raw.year} ${raw.make} ${raw.model}`, null, { highlights: v('mNotes'), carfaxUrl: v('mCarfax'), localPhotos, onlyMine: true });
    select(rec.id);
    $('#highlights').value = ''; $('#carfaxUrl').value = '';
    setStatus(`Added ${rec.fb.year} ${rec.fb.make} ${rec.fb.model}.${files.length ? '' : ' Add your photos before posting.'} When it's on lynnwoodhonda.com, click "Add website link" in the editor.`, 'ok');
  } catch (e) {
    setStatus(`Couldn't add the car: ${e.message}`, 'err');
  } finally { state.busy = false; $('#mGo').disabled = false; }
}

async function importFromTab() {
  let tab;
  try { tab = await chrome.tabs.get(srcTabId); } catch (e) { setStatus('That tab is no longer open.', 'err'); return; }
  if (!/\/viewdetails\//i.test(tab.url || '')) {
    const r = await send({ type: 'listVehicleLinks', tabId: srcTabId });
    const links = (r && r.links) || [];
    if (links.length > 1) {
      if (!confirm(`This page lists ${links.length} vehicles. Import all of them? It takes about 15 seconds each.`)) return;
      return importUrls(links);
    }
  }
  if (state.busy) return;
  state.busy = true;
  try {
    const rec = await importOne(async () => {
      const r = await send({ type: 'extractFromTab', tabId: srcTabId });
      if (!r || !r.ok) throw new Error(r ? r.error : 'no response');
      return r.data;
    }, 'Importing');
    select(rec.id);
    setStatus(`Imported ${rec.fb.year} ${rec.fb.make} ${rec.fb.model}.`, 'ok');
    await autoPostAfterImport([rec]);
  } catch (e) {
    setStatus(e.message, 'err');
  } finally {
    state.busy = false;
  }
}

// ---------- list ----------
const money = (n) => (n ? '$' + Number(n).toLocaleString('en-US') : '');
const STATUS = { draft: 'Draft', opened: 'Sent to Facebook', posted: 'Posted' };

function visibleListings() {
  return state.listings.filter((l) =>
    state.filter === 'all' ? true : state.filter === 'posted' ? l.status === 'posted' || l.status === 'opened' : l.status !== 'posted' && l.status !== 'opened'
  );
}

function renderList() {
  const ul = $('#vehicleList');
  ul.innerHTML = '';
  const items = visibleListings();
  $('#emptyList').hidden = items.length > 0;
  for (const l of items) {
    const li = document.createElement('li');
    li.className = l.id === state.selectedId ? 'active' : '';
    const first = l.images.find((i) => i.on) || l.images[0];
    li.innerHTML = `
      <input type="checkbox" class="pick" aria-label="Select">
      <div class="thumb">${first ? '<img alt="" loading="lazy" referrerpolicy="no-referrer">' : ''}</div>
      <div class="info"><div class="t"></div><div class="s muted"></div><span class="chip ${l.status}"></span></div>`;
    if (first) setThumb($('img', li), first);
    $('.t', li).textContent = `${l.fb.year} ${l.fb.make} ${l.fb.model}`;
    $('.s', li).textContent = [money(l.fb.price), l.fb.mileage ? Number(l.fb.mileage).toLocaleString() + ' mi' : '', l.raw.stock ? '#' + l.raw.stock : ''].filter(Boolean).join(' · ');
    $('.chip', li).textContent = STATUS[l.status] || l.status;
    const box = $('.pick', li);
    box.checked = state.checked.has(l.id);
    box.onclick = (e) => { e.stopPropagation(); box.checked ? state.checked.add(l.id) : state.checked.delete(l.id); updateBatch(); };
    li.onclick = () => select(l.id);
    ul.appendChild(li);
  }
  updateBatch();
}

// Delete checked cars from the app. Only cars that were never posted (not on Facebook, live or
// sold) are removed; anything on Facebook stays so its history and stats aren't lost.
async function deleteCars(ids) {
  const onFb = (id) => window.Dash && Dash.onFacebook && Dash.onFacebook(id);
  const del = ids.filter((id) => !onFb(id));
  const kept = ids.length - del.length;
  if (!del.length) { setStatus(kept ? 'Those are on Facebook, so they stay. To remove one, delete it on Facebook first (Delete on its dashboard card).' : 'Check the cars to delete first.', 'err'); return; }
  const name = (id) => { const l = state.listings.find((x) => x.id === id); return l ? `${l.fb.year} ${l.fb.make} ${l.fb.model}` : ''; };
  const list = del.map(name).filter(Boolean);
  const msg = `Delete ${del.length} car${del.length === 1 ? '' : 's'} that ${del.length === 1 ? "isn't" : "aren't"} posted?\n\n${list.slice(0, 12).join('\n')}${list.length > 12 ? `\n…and ${list.length - 12} more` : ''}`
    + `${kept ? `\n\n${kept} checked car${kept === 1 ? ' is' : 's are'} on Facebook and will stay.` : ''}\n\nThis removes them from the app (and your phone) and can't be undone.`;
  if (!confirm(msg)) return;
  const gone = state.listings.filter((x) => del.includes(x.id));
  state.listings = state.listings.filter((x) => !del.includes(x.id));
  del.forEach((id) => state.checked.delete(id));
  if (del.includes(state.selectedId)) state.selectedId = null;
  await saveNow();
  // Photos you added from this PC for those cars.
  gone.forEach((l) => (l.images || []).forEach((im) => { if (im.local) LHLocal.del(im.local).catch(() => {}); }));
  renderList(); renderEditor();
  if (window.Dash && Dash.render) Dash.render();
  const text = `Deleted ${del.length} car${del.length === 1 ? '' : 's'}.${kept ? ` ${kept} on Facebook ${kept === 1 ? 'was' : 'were'} kept.` : ''}`;
  setStatus(text, 'ok');
  if (window.Dash && Dash.say) Dash.say(text, 'ok');
}

function updateBatch() {
  const ids = visibleListings().map((l) => l.id);
  for (const id of [...state.checked]) if (!state.listings.some((l) => l.id === id)) state.checked.delete(id);
  const n = ids.filter((id) => state.checked.has(id)).length;
  const btn = $('#postSelectedBtn');
  btn.disabled = n === 0;
  btn.textContent = n ? `Post selected (${n})` : 'Post selected';
  const dn = ids.filter((id) => state.checked.has(id) && !(window.Dash && Dash.onFacebook && Dash.onFacebook(id))).length;
  $('#deleteSelectedBtn').disabled = dn === 0;
  $('#deleteSelectedBtn').textContent = dn ? `Delete (${dn})` : 'Delete';
  $('#selectAll').checked = n > 0 && n === ids.length;
}

function setThumb(img, im) {
  if (im.local) { LHLocal.objectUrl(im.local).then((u) => { if (u) img.src = u; else if (im.cloud) cloudThumb(im.cloud).then((c) => (img.src = c)).catch(() => {}); }); return; }
  if (im.cloud) { cloudThumb(im.cloud).then((u) => (img.src = u)).catch(() => {}); return; }
  img.src = IMG.smallUrl(im.url);
  img.onerror = function () { if (this.src !== im.url) this.src = im.url; };
  if (state.settings.removeBanner && im.cropTop) img.style.objectViewBox = `inset(${(im.cropTop * 100).toFixed(1)}% 0 0 0)`;
}

// ---------- editor ----------
function fillSelect(sel, opts) {
  sel.innerHTML = '<option value="">Choose…</option>' + opts.map((o) => `<option>${o}</option>`).join('');
}

function select(id) {
  state.selectedId = id;
  renderList();
  renderEditor();
}

function renderEditor() {
  const l = current();
  $('#editor').hidden = !l;
  if (!l) return;
  $('#edTitle').textContent = `${l.fb.year} ${l.fb.make} ${l.fb.model}`;
  const meta = $('#edMeta');
  meta.innerHTML = '';
  const a = document.createElement(l.raw.sourceUrl ? 'a' : 'span');
  if (l.raw.sourceUrl) { a.href = l.raw.sourceUrl; a.target = '_blank'; a.rel = 'noopener'; a.textContent = 'Dealer page'; }
  else { a.className = 'muted'; a.textContent = 'Not on the website yet'; }
  $('#refreshBtn').textContent = l.raw.sourceUrl ? 'Re-import' : 'Add website link';
  meta.append(a, document.createTextNode([l.raw.stock && `  ·  Stock ${l.raw.stock}`, l.raw.engine && `  ·  ${l.raw.engine}`].filter(Boolean).join('')));
  const chip = $('#edStatus');
  chip.textContent = STATUS[l.status] || l.status;
  chip.className = 'chip ' + l.status;
  $('#markBtn').textContent = l.status === 'posted' ? 'Mark as not posted' : 'Mark as posted';
  if (document.activeElement !== $('#edHighlights')) $('#edHighlights').value = l.raw.highlights || '';

  for (const el of $$('[data-field]')) {
    const v = l.fb[el.dataset.field];
    if (el.type === 'checkbox') el.checked = !!v;
    else {
      if (el.tagName === 'SELECT' && v && !$$('option', el).some((o) => o.value === String(v))) {
        const o = document.createElement('option'); o.textContent = v; el.appendChild(o);
      }
      el.value = v == null ? '' : v;
    }
  }
  $$('[data-raw]').forEach((el) => { const r = l.raw[el.dataset.raw]; el.textContent = r ? `Dealer: ${r}` : ''; });
  renderHistory(l);
  $('#descHint').textContent =
    l.descBy === 'edited' ? 'Your edit. The AI uses your rewrites to learn how you like posts to sound.'
    : l.descBy === 'ai' ? 'Written by AI from the dealer page and the positive CARFAX facts' + (l.learnedFrom && (l.learnedFrom.winners.length || l.learnedFrom.edits)
        ? `, learning from ${[l.learnedFrom.winners.length ? `your best posts: ${l.learnedFrom.winners.join(', ')}` : '', l.learnedFrom.edits ? `${l.learnedFrom.edits} of your own rewrites` : ''].filter(Boolean).join(' and ')}.`
        : '. It learns from your best posts once you sync with Facebook.') + ' Edit anything before posting.'
      : l.descError ? `AI writer failed (${l.descError}), so this is the basic version.`
        : aiReady() && state.settings.useAI ? 'Basic version. Click "Rewrite with AI" for an AI written one.'
          : 'Basic version. Add an API key in Settings to have AI write these.';
  $('#regenBtn').disabled = !aiReady();
  $('#sortBtn').disabled = !aiReady();
  renderPhotos();
}

function renderHistory(l) {
  const box = $('#history');
  const c = l.carfax;
  const link = $('#carfaxLink');
  link.hidden = !l.raw.carfaxUrl;
  if (l.raw.carfaxUrl) link.href = l.raw.carfaxUrl;
  $('#edCarfaxUrl').value = '';
  $('#edCarfaxUrl').placeholder = l.raw.carfaxUrl ? 'Paste a different CARFAX link' : 'Paste the CARFAX link (not on the dealer page yet)';
  if (!c) { box.innerHTML = '<p class="muted">No CARFAX link on the dealer page. Paste one above if you have it.</p>'; return; }
  if (c.error) { box.innerHTML = ''; const p = document.createElement('p'); p.className = 'muted'; p.textContent = c.error; box.appendChild(p); return; }
  box.innerHTML = '<div class="col good"><h4>Used in the post</h4><ul></ul></div><div class="col bad"><h4>Left out</h4><ul></ul></div>';
  const add = (ul, items, empty) => {
    if (!items.length) { const li = document.createElement('li'); li.className = 'muted'; li.textContent = empty; ul.appendChild(li); return; }
    items.forEach((t) => { const li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
  };
  add($('.good ul', box), c.positives, 'Nothing stood out');
  add($('.bad ul', box), c.negatives, 'Nothing to leave out');
}

const KIND = { exterior: 'Ext', exterior_detail: 'Detail', interior: 'Int', other: 'Other' };

function renderPhotos() {
  const l = current();
  // Blank photos from the old sort bug: offer (and try once) to bring them back.
  const broken = brokenPhotos(l);
  const fix = $('#photoFix');
  fix.hidden = !broken;
  if (broken) {
    fix.innerHTML = '';
    fix.append(document.createTextNode(`${broken} photo${broken === 1 ? '' : 's'} lost their link. `));
    const b = document.createElement('button'); b.className = 'primary'; b.textContent = 'Recover photos';
    b.onclick = async () => {
      b.disabled = true; b.textContent = 'Recovering…';
      try { const n = await recoverPhonePhotos(l); setStatus(`Recovered ${n} photo${n === 1 ? '' : 's'}. Sorting them now…`, 'ok'); await resort(); }
      catch (e) { setStatus(e.message, 'err'); b.disabled = false; b.textContent = 'Recover photos'; }
    };
    fix.appendChild(b);
  }
  const live = window.Dash && Dash.liveFor && Dash.liveFor(l.id);
  $('#fbPhotosBtn').hidden = !live;
  $('#fbDescBtn').hidden = !live;
  const grid = $('#photoGrid');
  grid.innerHTML = '';
  const max = state.settings.maxPhotos || 20;
  let onIndex = 0;
  l.images.forEach((im, i) => {
    const d = document.createElement('div');
    d.className = 'ph' + (im.on ? ' on' : '');
    d.draggable = true;
    const n = im.on ? ++onIndex : 0;
    if (n > max) d.classList.add('over');
    d.innerHTML = `<img alt="" loading="lazy" referrerpolicy="no-referrer"><span class="n">${im.on ? n : ''}</span>` +
      (im.kind && KIND[im.kind] ? `<span class="kind ${im.kind}">${KIND[im.kind]}</span>` : '') +
      (im.cropTop && state.settings.removeBanner ? '<span class="trim" title="Dealer banner will be trimmed off">Banner off</span>' : '') +
      (im.local ? '<span class="mine">Yours</span><button class="rm" title="Remove this photo">×</button>' : '');
    setThumb($('img', d), im);
    d.onclick = () => { im.on = !im.on; save(); renderPhotos(); renderList(); };
    const rm = $('.rm', d);
    if (rm) rm.onclick = async (e) => {
      e.stopPropagation();
      l.images.splice(i, 1);
      await LHLocal.del(im.local).catch(() => {});
      await saveNow(); renderPhotos(); renderList();
    };
    d.ondragstart = (e) => { e.dataTransfer.setData('text/plain', String(i)); d.classList.add('drag'); };
    d.ondragend = () => d.classList.remove('drag');
    d.ondragover = (e) => { e.preventDefault(); d.classList.add('target'); };
    d.ondragleave = () => d.classList.remove('target');
    d.ondrop = (e) => {
      e.preventDefault();
      const from = Number(e.dataTransfer.getData('text/plain'));
      if (from === i || Number.isNaN(from)) return;
      const [moved] = l.images.splice(from, 1);
      l.images.splice(i, 0, moved);
      save(); renderPhotos(); renderList();
    };
    grid.appendChild(d);
  });
  const on = l.images.filter((i) => i.on).length;
  const trimmed = l.images.filter((i) => i.on && i.cropTop).length;
  $('#photoCount').textContent = `${Math.min(on, max)} of ${l.images.length} selected` + (on > max ? ` (only the first ${max} upload)` : '');
  $('#photoHint').textContent =
    (l.photoNote === 'sorted' ? 'Sorted by AI: exterior first, then details, interior, and other. ' : l.photoNote ? `${l.photoNote}. ` : '') +
    (trimmed && state.settings.removeBanner ? `The dealer banner gets trimmed off ${trimmed} photo${trimmed > 1 ? 's' : ''}. ` : '') +
    'Drag to reorder. Click a photo to include or skip it.';
}

function onFieldChange(e) {
  const el = e.target;
  const f = el.dataset.field;
  const l = current();
  if (!f || !l) return;
  let v = el.type === 'checkbox' ? el.checked : el.value;
  if (['year', 'mileage', 'price'].includes(f)) v = v === '' ? '' : Math.round(Number(v));
  if (f === 'vin') v = String(v).toUpperCase();
  if (f === 'description') l.descBy = 'edited'; // your rewrites teach the AI your voice
  l.fb[f] = v;
  l.updatedAt = Date.now();
  save();
  if (['year', 'make', 'model', 'price', 'mileage'].includes(f)) {
    $('#edTitle').textContent = `${l.fb.year} ${l.fb.make} ${l.fb.model}`;
    renderList();
  }
}

// ---------- actions ----------
function missingFields(l) {
  return ['year', 'make', 'model', 'price', 'mileage'].filter((f) => !l.fb[f]);
}

// Is this car already live on Facebook? Posting it twice looks like spam to Facebook.
async function liveOnFacebook(l) {
  const { fbListings = [] } = await chrome.storage.local.get('fbListings');
  return fbListings.find((f) => (f.status === 'Active' || f.status === 'Pending') && S.sameCar(l, f));
}

function queueText(q) {
  if (!q || !q.waiting) return '';
  const mins = Math.max(1, Math.round((q.nextAt - Date.now()) / 60000));
  const when = mins >= 60 ? new Date(q.nextAt).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' }) : `in about ${mins} min`;
  return `${q.waiting} more in line, next ${when}${q.why === 'daily limit' ? ' (daily limit reached)' : q.why === 'busy hours' ? ' (held for busy Marketplace hours)' : ''}.`;
}

async function post(ids, { quiet = false } = {}) {
  let list = ids.map((id) => state.listings.find((l) => l.id === id)).filter(Boolean);
  const stockOnly = list.filter((l) => { const on = (l.images || []).filter((i) => i.on); return on.length && on.every((i) => isStockUrl(i.url)); });
  if (stockOnly.length && (quiet || !confirm(`${stockOnly.map((l) => `${l.fb.year} ${l.fb.model}`).join(', ')}: only the dealer's generic catalog photo so far. Post anyway?\n\nOK = post anyway, Cancel = skip ${stockOnly.length === 1 ? 'it' : 'them'} and add your own photos first`))) {
    list = list.filter((l) => !stockOnly.includes(l));
    if (!list.length) { setStatus('Add your own photos first (the dealer site only has a generic catalog photo).', 'err'); return; }
  }
  // Facebook won't let Next/Publish through without both colors.
  const noColor = list.filter((l) => !l.fb.exteriorColor || !l.fb.interiorColor);
  if (noColor.length) {
    if (!quiet) setStatus(`Reading the colors from the photos for ${noColor.length} car${noColor.length === 1 ? '' : 's'}…`);
    for (const l of noColor) await ensureColors(l);
  }
  const dupes = [];
  for (const l of list) { const f = await liveOnFacebook(l); if (f) dupes.push({ l, f }); }
  if (dupes.length) {
    const names = dupes.map(({ f }) => `• ${f.title} ($${Number(f.price).toLocaleString()}, ${f.status})`).join('\n');
    const again = !quiet && confirm(`Already on Facebook:\n${names}\n\nPosting the same car twice is one of the things Facebook flags as spam. Post another copy anyway?\n\nOK = post anyway, Cancel = skip ${dupes.length === 1 ? 'it' : 'them'}`);
    if (!again) list = list.filter((l) => !dupes.some((d) => d.l === l));
    if (!list.length) { setStatus(`Skipped: already on Facebook (${dupes.map((d) => d.f.title).join(', ')}).`, 'ok'); return; }
  }
  const bad = list.filter((l) => missingFields(l).length);
  if (bad.length) {
    alert(bad.map((l) => `${l.fb.year} ${l.fb.make} ${l.fb.model}: fill in ${missingFields(l).join(', ')}`).join('\n'));
    return;
  }

  list.forEach((l) => { if (l.status !== 'posted') l.status = 'opened'; });
  await saveNow();
  renderList();
  renderEditor();
  // Slow hours: offer to hold the post for the evening/weekend crowd (more views), or post now.
  let now = quiet;
  if (!quiet && state.settings.busyTimes !== false && !S.isBusyTime()) {
    const at = new Date(S.nextBusyStart());
    now = !confirm(`More people browse Marketplace on weekday evenings and weekends.\n\nOK = post at the busy time (${at.toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })})\nCancel = post right now`);
  }
  const r = await send({ type: 'openComposer', ids: list.map((l) => l.id), now });
  const q = r && r.queue;
  const startedNow = !q || q.waiting < list.length;
  setStatus(`${startedNow ? 'Posting started in a background tab.' : 'Added to the posting line.'} ${queueText(q)} Cars post one at a time a few minutes apart so Facebook sees a normal pace.${state.settings.publishOnPost !== false || state.settings.autoPost ? ' Each one publishes by itself when it finishes filling, and you get a "Posted complete" message.' : ' Switch to the tab to review and publish.'}`.replace(/\s+/g, ' ').trim(), 'ok');
}

async function reimport() {
  const l = current();
  if (state.busy) return;
  if (l && !l.raw.sourceUrl) {
    // A car added without a website link: now it's on the site, bring in the dealer page.
    const link = (prompt(`Paste the lynnwoodhonda.com link for the ${l.fb.year} ${l.fb.make} ${l.fb.model}. Your photos, notes and CARFAX link stay.`) || '').trim();
    if (!link) return;
    if (!/^https?:\/\//i.test(link)) { setStatus("That isn't a link.", 'err'); return; }
    l.raw.sourceUrl = link;
  }
  state.busy = true;
  try {
    const rec = await importOne(async () => {
      const r = await send({ type: 'extractFromUrl', url: l.raw.sourceUrl });
      if (!r || !r.ok) throw new Error(r ? r.error : 'no response');
      // A car added by hand: keep it as the same car even if the VIN was left out.
      if (l.raw.manual && !l.raw.vin && r.data) r.data.vin = r.data.vin || '';
      return r.data;
    }, 'Re-importing', null, l.raw.manual ? { manualId: l.id } : undefined);
    select(rec.id);
    setStatus('Updated with the latest price, miles, photos and CARFAX.', 'ok');
  } catch (e) {
    setStatus(e.message, 'err');
  } finally {
    state.busy = false;
  }
}

// Swap the car's photos for the ones on the dealer website (your own photos are taken off),
// then, if the car is live on Facebook, replace the photos on the post too.
async function useDealerPhotos(id, { ask = true, onStep } = {}) {
  const l = state.listings.find((x) => x.id === id);
  if (!l || !l.raw || !l.raw.sourceUrl) throw new Error('This car has no dealer page link');
  const live = window.Dash && Dash.liveFor(id);
  if (ask && !confirm(`Replace this car's photos with the photos on the dealer website?${live ? '\n\nThe photos on the live Facebook post get replaced too.' : ''}\n\nYour own photos are taken off this car.`)) return null;
  const step = (t) => { setStatus(`${l.fb.year} ${l.fb.model}: ${t}…`); if (onStep) onStep(t); };
  step('reading the dealer website photos');
  const r = await send({ type: 'extractFromUrl', url: l.raw.sourceUrl });
  if (!r || !r.ok) throw new Error(r ? r.error : 'Could not read the dealer page');
  const raw = r.data;
  if (!(raw.images || []).length) throw new Error('No photos found on the dealer page');
  if (raw.stockPhotos) throw new Error("The dealer website still only has the generic catalog picture. Try again once the real photos are up");
  const photos = await processPhotos(raw.images.map((im) => ({ url: im.url, fallback: im.fallback || '' })), step);
  l.images = photos.images;
  l.photoNote = photos.note;
  l.raw.images = raw.images;
  l.raw.stockPhotos = false;
  l.stockOnly = false;
  if (photos.colors) applyColors(l, photos.colors);
  l.updatedAt = Date.now();
  await saveNow();
  renderList();
  if (state.selectedId === id) renderEditor();
  const n = l.images.filter((i) => i.on).length;
  if (live) {
    step('replacing the photos on Facebook');
    const ok = await Dash.updatePhotos(id, { noConfirm: true });
    return ok ? `Now using ${n} dealer website photos, on Facebook too` : `Now using ${n} dealer website photos in the app, but Facebook wasn't updated`;
  }
  return `Now using ${n} dealer website photos`;
}

// Try a different front shot first, on Facebook too, and remember clicks/day before, to compare in 3 days.
async function newFirstPhoto(id) {
  const l = state.listings.find((x) => x.id === id);
  const live = window.Dash && Dash.liveFor(id);
  const f = live && live.f;
  if (!l || !f) return;
  const on = l.images.filter((i) => i.on);
  const ext = on.slice(1).filter((i) => i.kind === 'exterior');
  const tried = new Set((l.heroTests || []).map((t) => t.key));
  const keyOf = (i) => i.cloud || i.local || i.url;
  const pickFrom = (arr) => arr.find((i) => /front/.test(i.view || '') && !tried.has(keyOf(i))) || arr.find((i) => !tried.has(keyOf(i)));
  const next = pickFrom(ext) || pickFrom(on.slice(1));
  if (!next) { setStatus('No other photo to try first. Add a few of your own (a clean front three-quarter shot works best).', 'err'); return; }
  const before = f.cpd != null ? f.cpd : null;
  l.images.splice(l.images.indexOf(next), 1);
  l.images.unshift(next);
  l.heroTests = [...(l.heroTests || []), { at: Date.now(), day: S.dayKey(), key: keyOf(next), before }].slice(-10);
  await saveNow();
  const ok = await Dash.updatePhotos(id, { noConfirm: true });
  setStatus(ok ? `${f.title}: new first photo is live. Clicks/day before: ${before ?? '?'}; the app compares after 3 days.` : 'First photo changed in the app, but Facebook wasn\'t updated.', ok ? 'ok' : 'err');
}

async function rewrite() {
  const l = current();
  l.raw.highlights = $('#edHighlights').value.trim();
  $('#regenBtn').disabled = true;
  $('#regenBtn').textContent = 'Writing…';
  const d = await writeDescription(l, () => {});
  l.fb.description = d.text;
  l.descBy = d.by;
  l.descError = d.error || '';
  await saveNow();
  $('#regenBtn').textContent = 'Rewrite with AI';
  renderEditor();
  // Live on Facebook? Offer to put the new description on the post too.
  if (window.Dash && Dash.liveFor(l.id) && confirm('New description written. Update the live Facebook post with it too?')) await Dash.updateDesc(l.id, { noConfirm: true });
}

// Your own photos go in after the dealer's exterior shots and are turned on.
async function addOwnPhotos(files) {
  const l = current();
  if (!l || !files.length) return;
  const btn = $('#addPhotosBtn');
  btn.disabled = true;
  try {
    let n = 0;
    for (const f of files) {
      btn.textContent = `Adding ${++n} of ${files.length}…`;
      const id = await LHLocal.add(f);
      l.images.push({ local: id, url: '', fallback: '', on: true, cropTop: 0, kind: '' });
    }
    // Real photos replace the dealer's generic catalog picture, and the colors get read from them.
    if (l.images.some((i) => isStockUrl(i.url))) {
      l.images = l.images.filter((i) => !isStockUrl(i.url));
      l.stockOnly = false;
      l.aiColors = null;
      l.fb.interiorColor = '';
      if (!S.mapColor(l.raw.exteriorColor, S.EXT_RULES)) l.fb.exteriorColor = '';
      await ensureColors(l);
    }
    l.updatedAt = Date.now();
    await saveNow();
    setStatus(`Added ${files.length} photo${files.length === 1 ? '' : 's'}. Drag to put them where you want, or click "Sort with AI".`, 'ok');
  } catch (e) {
    setStatus(`Couldn't add photos: ${e.message}`, 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Add your photos';
    renderPhotos(); renderList();
  }
}

// Photos from the phone that lost their link (the old "Sort with AI" bug): find them again
// from the import request that brought them in, and from the car's own photo folder.
async function recoverPhonePhotos(l) {
  const c = cloudClient();
  if (!c || !(await c.user())) throw new Error('Sign in to the phone app connection first (Settings → Phone app)');
  const uid = (await c.user()).id;
  const found = [];
  const rows = await c.db.select('commands', 'kind=eq.import&order=created_at.desc&limit=100').catch(() => []);
  const mine = (rows || []).find((r) => r.payload && (r.payload.photos || []).length && r.payload.url && l.raw && r.payload.url.split('?')[0] === String(l.raw.sourceUrl || '').split('?')[0]);
  if (mine) found.push(...mine.payload.photos);
  found.push(...(await c.photos.list(`${uid}/${l.id}`)));
  const have = new Set(l.images.map((im) => im.cloud).filter(Boolean));
  const add = [...new Set(found)].filter((p) => !have.has(p));
  if (!add.length) throw new Error("Couldn't find this car's phone photos in your cloud storage");
  l.images = [...l.images.filter((im) => im.url || im.local || im.cloud), ...add.map((cloud) => ({ cloud, url: '', fallback: '', on: true, cropTop: 0, kind: '' }))];
  await saveNow();
  return add.length;
}
const brokenPhotos = (l) => (l.images || []).filter((im) => !im.url && !im.local && !im.cloud).length;

async function resort() {
  const l = current();
  $('#sortBtn').disabled = true;
  $('#sortBtn').textContent = 'Sorting…';
  const keep = l.images.filter((im) => im.url || im.local || im.cloud);
  const r = await processPhotos(keep.map(({ url, fallback, local, cloud }) => ({ url, fallback, local, cloud })), () => {});
  l.images = r.images;
  l.photoNote = r.note;
  if (r.colors) applyColors(l, r.colors);
  await saveNow();
  $('#sortBtn').textContent = 'Sort with AI';
  renderEditor();
  renderList();
}

// ---------- settings ----------
const SETTING_INPUTS = {
  opening: '#setOpening', location: '#setLocation', condition: '#setCondition',
  useAI: '#setUseAI', sortPhotos: '#setSortPhotos', removeBanner: '#setRemoveBanner', autoFill: '#setAutoFill', publishOnPost: '#setPublishOnPost', autopilot: '#setAutopilot', busyTimes: '#setBusyTimes', matchDealerPrice: '#setMatchDealerPrice', workWhere: '#setWorkWhere', liveSyncMin: '#setLiveSync', groupAuto: '#setGroupAuto',
  fillVin: '#setFillVin', fillLocation: '#setFillLocation', postsPerDay: '#setPostsPerDay', cloudUrl: '#setCloudUrl', cloudKey: '#setCloudKey',
};

const keyDraft = { gemini: '', anthropic: '' };
function showProvider() {
  const p = PROVIDER[$('#setProvider').value];
  $('#keyLabel').textContent = p.keyName;
  $('#setApiKey').placeholder = p.placeholder;
  $('#setApiKey').value = keyDraft[$('#setProvider').value] || '';
  $('#keyStatus').textContent = p.help;
}

// ---------- phone app / cloud ----------
const PHONE_APP_URL = 'https://dattran9534.github.io/lh-marketplace-lister/';
const chromeStore = { get: async (k) => (await chrome.storage.local.get(k))[k], set: async (k, v) => chrome.storage.local.set({ [k]: v }) };
function cloudClient(urlOverride, keyOverride) {
  const url = urlOverride || state.settings.cloudUrl, key = keyOverride || state.settings.cloudKey;
  return url && key ? LHCloud({ url, key, store: chromeStore }) : null;
}

async function renderCloud() {
  const c = cloudClient();
  const who = c && (await c.user());
  $('#cloudSignedOut').hidden = !!who;
  $('#cloudSignedIn').hidden = !who;
  $('#cloudWho').textContent = who ? `Signed in as ${who.email}` : '';
  const { cloudLastSync, cloudError } = await chrome.storage.local.get(['cloudLastSync', 'cloudError']);
  $('#cloudStatus').textContent = !who ? 'Not connected.' : cloudError ? `Last sync problem: ${cloudError}` : cloudLastSync ? `Last synced ${new Date(cloudLastSync).toLocaleTimeString()}.` : 'Waiting for the first sync.';
  const a = $('#phoneLink'); a.href = PHONE_APP_URL; a.textContent = PHONE_APP_URL;
}

async function cloudAuth(mode) {
  const url = $('#setCloudUrl').value.trim(), key = $('#setCloudKey').value.trim();
  const email = $('#cloudEmail').value.trim(), pw = $('#cloudPassword').value;
  if (!url || !key) { $('#cloudStatus').textContent = 'Paste the project URL and publishable key first.'; return; }
  if (!email || pw.length < 6) { $('#cloudStatus').textContent = 'Enter your email and a password of at least 6 characters.'; return; }
  state.settings.cloudUrl = url; state.settings.cloudKey = key;
  await chrome.storage.local.set({ settings: state.settings });
  const c = cloudClient();
  $('#cloudStatus').textContent = mode === 'up' ? 'Creating your account…' : 'Signing in…';
  try {
    if (mode === 'up') {
      const r = await c.signUp(email, pw);
      if (r.confirm) { $('#cloudStatus').textContent = 'Check your email and click the confirm link (the page it opens may look broken, that is fine). Then come back and click Sign in.'; return; }
    } else {
      await c.signIn(email, pw);
    }
    $('#cloudPassword').value = '';
    await send({ type: 'cloudSyncNow' });
  } catch (e) {
    $('#cloudStatus').textContent = /confirm/i.test(e.message) ? 'Confirm your email first (check your inbox), then Sign in.' : e.message;
    return;
  }
  renderCloud();
}

// The phone asked this PC to import a car: done in a background tab, then it closes.
async function runPhoneImport() {
  const cmdId = params.get('cmd'), url = params.get('importUrl');
  if (!cmdId || !url) return;
  const c = cloudClient();
  let status = 'done', result = '';
  const canceled = async () => {
    if (!c) return false;
    const rows = await c.db.select('commands', `id=eq.${cmdId}&select=status`).catch(() => null);
    return !!(rows && rows[0] && rows[0].status !== 'running');
  };
  try {
    let lastStep = 'starting';
    const progress = (step) => { lastStep = String(step || ''); if (c) c.db.update('commands', { id: cmdId }, { result: lastStep.charAt(0).toUpperCase() + lastStep.slice(1) + '…' }).catch(() => {}); };
    // Photos you picked on the phone before importing travel with the request.
    const row = c ? await c.db.select('commands', `id=eq.${cmdId}&select=payload`).catch(() => null) : null;
    const p = (row && row[0] && row[0].payload) || {};
    // A car added on the phone without a website link comes with what you typed.
    const work = importOne(p.manual ? async () => S.manualRaw(p.manual) : async () => {
      const r = await send({ type: 'extractFromUrl', url });
      if (!r || !r.ok) throw new Error(r ? r.error : 'no response');
      return r.data;
    }, 'Importing for your phone', progress, { photos: p.photos || [], onlyMine: !!p.onlyMine || !!p.manual, highlights: p.highlights || '', carfaxUrl: p.carfaxUrl || '' });
    // Never leave the phone spinning: give up after 6 minutes.
    const rec = await Promise.race([work, new Promise((_, no) => setTimeout(() => no(new Error(`Took too long (stuck at: ${lastStep}). Tap Try again.`)), 6 * 60000))]);
    if (await canceled()) { if (c) await send({ type: 'cloudSyncNow' }); const me = await chrome.tabs.getCurrent(); if (me) chrome.tabs.remove(me.id); return; }
    const name = `${rec.fb.year} ${rec.fb.make} ${rec.fb.model}`;
    if (state.settings.autoPost) progress(`imported ${name}, posting to Facebook`);
    await autoPostAfterImport([rec]);
    result = rec.stockOnly ? `Imported ${name}, but the dealer site only has a generic catalog photo. Add your own photos before posting.`
      : state.settings.autoPost ? `Imported ${name}. Auto post is publishing it on your PC.` : `Imported ${name}. Auto post is off, so it's waiting for you to post.`;
  } catch (e) {
    status = 'failed'; result = e.message;
  }
  if (c && !(status === 'failed' && await canceled())) await c.db.update('commands', { id: cmdId }, { status, result, done_at: new Date().toISOString() }).catch(() => {});
  await send({ type: 'cloudSyncNow' });
  const me = await chrome.tabs.getCurrent();
  if (me) chrome.tabs.remove(me.id);
}

// The phone asked for a new description (for example after adding things to mention).
async function runPhoneRewrite() {
  const cmdId = params.get('cmd'), id = params.get('rewrite');
  const c = cloudClient();
  let status = 'done', result = '';
  try {
    const l = state.listings.find((x) => x.id === id);
    if (!l) throw new Error('That car is not on the PC yet');
    const row = c ? await c.db.select('commands', `id=eq.${cmdId}&select=payload`).catch(() => null) : null;
    const p = (row && row[0] && row[0].payload) || {};
    // A CARFAX link pasted on the phone: read it first, so the new description uses it.
    if (p.carfaxUrl) {
      if (c) c.db.update('commands', { id: cmdId }, { result: 'Reading the CARFAX report…' }).catch(() => {});
      await applyCarfaxLink(l, p.carfaxUrl, () => {}, { rewrite: false });
    }
    const d = await writeDescription(l, () => {});
    l.fb.description = d.text; l.descBy = d.by; l.descError = d.error || ''; l.updatedAt = Date.now();
    await saveNow();
    result = d.by === 'ai' ? 'New description written' : 'New description written (without AI)';
    if (p.pushFb) {
      if (!window.Dash && document.readyState === 'loading') await new Promise((r) => document.addEventListener('DOMContentLoaded', r, { once: true }));
      if (window.Dash) await Dash.init();
      if (window.Dash && Dash.liveFor(id)) {
        if (c) c.db.update('commands', { id: cmdId }, { result: 'Updating the description on Facebook…' }).catch(() => {});
        const ok = await Dash.updateDesc(id, { noConfirm: true });
        result += ok ? ', and updated on Facebook' : ", but Facebook wasn't updated (open the car on the PC to retry)";
      }
    }
  } catch (e) { status = 'failed'; result = e.message; }
  if (c) await c.db.update('commands', { id: cmdId }, { status, result, done_at: new Date().toISOString() }).catch(() => {});
  await send({ type: 'cloudSyncNow' });
  const me = await chrome.tabs.getCurrent();
  if (me) chrome.tabs.remove(me.id);
}

async function runPhoneHeroTest() {
  const cmdId = params.get('cmd'), id = params.get('heroTest');
  const c = cloudClient();
  let status = 'done', result = '';
  try {
    if (!window.Dash && document.readyState === 'loading') await new Promise((r) => document.addEventListener('DOMContentLoaded', r, { once: true }));
    if (window.Dash) await Dash.init();
    await newFirstPhoto(id);
    result = $('#importStatus').textContent || 'Done';
    if (/wasn't|No other photo/.test(result)) status = 'failed';
  } catch (e) { status = 'failed'; result = e.message; }
  if (c) await c.db.update('commands', { id: cmdId }, { status, result, done_at: new Date().toISOString() }).catch(() => {});
  await send({ type: 'cloudSyncNow' });
  const me = await chrome.tabs.getCurrent();
  if (me) chrome.tabs.remove(me.id);
}

async function runPhoneDealerPhotos() {
  const cmdId = params.get('cmd'), id = params.get('dealerPhotos');
  const c = cloudClient();
  let status = 'done', result = '';
  try {
    if (!window.Dash && document.readyState === 'loading') await new Promise((r) => document.addEventListener('DOMContentLoaded', r, { once: true }));
    if (window.Dash) await Dash.init();
    const progress = (t) => { if (c) c.db.update('commands', { id: cmdId }, { result: t.charAt(0).toUpperCase() + t.slice(1) + '…' }).catch(() => {}); };
    result = await useDealerPhotos(id, { ask: false, onStep: progress });
  } catch (e) {
    status = 'failed'; result = e.message;
  }
  if (c) await c.db.update('commands', { id: cmdId }, { status, result, done_at: new Date().toISOString() }).catch(() => {});
  await send({ type: 'cloudSyncNow' });
  const me = await chrome.tabs.getCurrent();
  if (me) chrome.tabs.remove(me.id);
}

// Photos added on the phone show up here from the cloud.
const cloudUrls = new Map();
async function cloudThumb(path) {
  if (cloudUrls.has(path)) return cloudUrls.get(path);
  const c = cloudClient();
  if (!c) return '';
  const u = URL.createObjectURL(await c.photos.download(path));
  cloudUrls.set(path, u);
  return u;
}

function openSettings() {
  fillSelect($('#setCondition'), S.FB.conditions);
  for (const [k, sel] of Object.entries(SETTING_INPUTS)) {
    const el = $(sel);
    if (el.type === 'checkbox') el.checked = !!state.settings[k];
    else el.value = state.settings[k] == null ? '' : state.settings[k];
  }
  $('#setVersion').textContent = `Version ${chrome.runtime.getManifest().version}`;
  keyDraft.gemini = state.settings.geminiKey || '';
  keyDraft.anthropic = state.settings.apiKey || '';
  $('#setProvider').value = aiCfg().provider;
  $('#setProvider').dataset.prev = aiCfg().provider;
  showProvider();
  $('#updateStatus').textContent = '';
  renderCloud();
  renderGroups();
  $('#settingsDlg').showModal();
}

// ---------- Facebook groups ----------
let groupDraft = null;
async function renderGroups() {
  const { fbGroups = [], fbGroupsAt = 0 } = await chrome.storage.local.get(['fbGroups', 'fbGroupsAt']);
  if (!groupDraft) groupDraft = new Set(state.settings.groups || []);
  const box = $('#groupList');
  box.innerHTML = '';
  const q = ($('#groupFilter').value || '').toLowerCase();
  $('#groupFilter').hidden = fbGroups.length < 8;
  // Car buy/sell groups first, then the rest.
  const carish = (g) => /car|auto|vehicle|truck|honda|toyota|buy|sell|trade|bst|for sale|classified|mua|bán|chợ/i.test(g.name);
  const list = [...fbGroups].sort((a, b) => (groupDraft.has(b.name) - groupDraft.has(a.name)) || (carish(b) - carish(a)));
  list.filter((g) => !q || g.name.toLowerCase().includes(q)).forEach((g) => {
    const l = document.createElement('label');
    l.className = 'check group-row';
    const c = document.createElement('input');
    c.type = 'checkbox';
    c.checked = groupDraft.has(g.name);
    c.onchange = () => {
      if (c.checked && groupDraft.size >= 20) { c.checked = false; alert('Facebook allows up to 20 groups per listing.'); return; }
      c.checked ? groupDraft.add(g.name) : groupDraft.delete(g.name);
      $('#groupsInfo').textContent = `${groupDraft.size} selected`;
    };
    const t = document.createElement('span');
    t.textContent = g.name;
    const m = document.createElement('small');
    m.className = 'muted';
    m.textContent = [g.members && `${g.members} members`, g.privacy].filter(Boolean).join(' · ');
    l.append(c, t, m);
    box.appendChild(l);
  });
  $('#groupsInfo').textContent = fbGroups.length ? `${groupDraft.size} selected · ${fbGroups.length} groups, synced ${new Date(fbGroupsAt).toLocaleDateString()}` : 'Not synced yet';
}
async function syncGroups() {
  const b = $('#syncGroupsBtn');
  b.disabled = true;
  $('#groupsInfo').textContent = 'Reading your groups from Facebook (nothing is posted)…';
  try {
    const res = await Dash.runJob({ kind: 'groupsRead' }, 'Reading your groups', true);
    if (!res.ok) throw new Error(res.error);
    renderGroups();
  } catch (e) {
    $('#groupsInfo').textContent = `Couldn't read groups: ${e.message}`;
  } finally {
    b.disabled = false;
  }
}

async function saveSettings() {
  for (const [k, sel] of Object.entries(SETTING_INPUTS)) {
    const el = $(sel);
    state.settings[k] = el.type === 'checkbox' ? el.checked : el.value.trim();
  }
  keyDraft[$('#setProvider').value] = $('#setApiKey').value.trim();
  state.settings.aiProvider = $('#setProvider').value;
  state.settings.geminiKey = keyDraft.gemini;
  state.settings.apiKey = keyDraft.anthropic;
  if (!state.settings.condition) state.settings.condition = 'Excellent';
  state.settings.postsPerDay = Math.max(1, Math.min(20, Number(state.settings.postsPerDay) || 5));
  if (groupDraft) state.settings.groups = [...groupDraft];
  state.settings.groupsAt = Date.now();
  groupDraft = null;
  await chrome.storage.local.set({ settings: state.settings });
  renderAiTag();
  renderEditor();
}

function renderAiTag() {
  const t = $('#aiTag');
  const p = PROVIDER[aiCfg().provider];
  t.textContent = aiReady() ? `AI on (${p.name})` : 'AI off';
  t.className = 'chip ' + (aiReady() ? 'posted' : '');
  t.title = aiReady() ? `Descriptions and photo sorting use ${p.name}` : 'Add a free Gemini API key in Settings';
}

// ---------- updates ----------
let updateInfo = null;
async function checkForUpdate(manual) {
  try {
    const info = await LHUpdater.check(state.settings.updateSource);
    updateInfo = info.available ? info : null;
    $('#updateBar').hidden = !info.available;
    $('#settingsUpdateBtn').hidden = !info.available;
    if (info.available) $('#settingsUpdateBtn').textContent = `Update now to ${info.version}`;
    if (info.available) $('#updateText').textContent = `Version ${info.version} is ready${info.notes ? `: ${info.notes}` : '.'}`;
    if (manual) $('#updateStatus').textContent = info.available ? `Version ${info.version} is available.` : "You're on the latest version.";
  } catch (e) {
    $('#settingsUpdateBtn').hidden = true;
    if (manual) $('#updateStatus').textContent = e.message;
  }
}

async function runUpdate(forcePick) {
  if (!updateInfo) return;
  const btn = $('#updateBtn');
  btn.disabled = true;
  try {
    await LHUpdater.install(updateInfo, (s) => ($('#updateText').textContent = s), forcePick);
  } catch (e) {
    btn.disabled = false;
    if (e && e.name === 'AbortError') { $('#updateText').textContent = 'Update cancelled.'; return; }
    $('#updateText').textContent = e.message;
  }
}

// ---------- init ----------
async function init() {
  await load();
  $('#versionTag').textContent = `v${chrome.runtime.getManifest().version}`;
  $$('select[data-opts]').forEach((sel) => fillSelect(sel, S.FB[sel.dataset.opts]));
  $$('[data-field]').forEach((el) => { el.addEventListener('input', onFieldChange); el.addEventListener('change', onFieldChange); });

  $('#importBtn').onclick = () => importUrls($('#urls').value.split(/\s+/), $('#carfaxUrl').value);
  $('#urls').addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) $('#importBtn').click(); });
  if (srcTabId != null) {
    try {
      const t = await chrome.tabs.get(srcTabId);
      if (t && /^https?:/.test(t.url || '')) {
        const btn = $('#importTabBtn');
        btn.hidden = false;
        btn.textContent = /\/viewdetails\//i.test(t.url) ? 'Import the page I was on' : 'Import from the page I was on';
        btn.title = t.title || t.url;
        btn.onclick = importFromTab;
      }
    } catch (e) {}
  }
  $('#filter').onchange = (e) => { state.filter = e.target.value; renderList(); };
  $('#selectAll').onchange = (e) => {
    visibleListings().forEach((l) => (e.target.checked ? state.checked.add(l.id) : state.checked.delete(l.id)));
    renderList();
  };
  $('#postSelectedBtn').onclick = () => post(visibleListings().filter((l) => state.checked.has(l.id)).map((l) => l.id));
  $('#photosFirst20').onclick = () => { const l = current(); l.images.forEach((im, i) => (im.on = i < 20)); save(); renderPhotos(); };
  $('#photosNone').onclick = () => { current().images.forEach((im) => (im.on = false)); save(); renderPhotos(); };
  $('#sortBtn').onclick = resort;
  $('#fbPhotosBtn').onclick = () => Dash.updatePhotos(current().id);
  $('#dealerPhotosBtn').onclick = async () => {
    const b = $('#dealerPhotosBtn');
    b.disabled = true;
    try { const m = await useDealerPhotos(current().id); if (m) setStatus(m + '.', 'ok'); }
    catch (e) { setStatus(`Dealer photos not used: ${e.message}`, 'err'); }
    finally { b.disabled = false; }
  };
  $('#addPhotosBtn').onclick = () => $('#addPhotosInput').click();
  $('#addPhotosInput').onchange = async (e) => { await addOwnPhotos([...e.target.files]); e.target.value = ''; };
  const grid = $('#photoGrid');
  grid.addEventListener('dragover', (e) => { if ([...e.dataTransfer.types].includes('Files')) { e.preventDefault(); grid.classList.add('dropping'); } });
  grid.addEventListener('dragleave', () => grid.classList.remove('dropping'));
  grid.addEventListener('drop', async (e) => {
    if (!e.dataTransfer.files.length) return;
    e.preventDefault();
    grid.classList.remove('dropping');
    await addOwnPhotos([...e.dataTransfer.files].filter((f) => /^image\//.test(f.type) || /\.(heic|heif)$/i.test(f.name)));
  });
  $('#regenBtn').onclick = rewrite;
  $('#fbDescBtn').onclick = async () => { await saveNow(); if (window.Dash) await Dash.updateDesc(current().id); };
  $('#edHighlights').onchange = async () => { const l = current(); if (!l) return; l.raw.highlights = $('#edHighlights').value.trim(); l.updatedAt = Date.now(); await saveNow(); };
  $('#copyBtn').onclick = async () => {
    await navigator.clipboard.writeText(current().fb.description || '');
    $('#copyBtn').textContent = 'Copied';
    setTimeout(() => ($('#copyBtn').textContent = 'Copy'), 1200);
  };
  $('#postBtn').onclick = async () => {
    await post([current().id]);
    // The car is on its way to Facebook: back to the dashboard.
    if (current() && current().status === 'opened' && window.Dash && Dash.show) Dash.show('dash');
  };
  $('#markBtn').onclick = async () => {
    const l = current();
    l.status = l.status === 'posted' ? 'draft' : 'posted';
    await saveNow();
    renderList(); renderEditor();
  };
  $('#refreshBtn').onclick = reimport;
  $('#manualBtn').onclick = openManual;
  $('#mVinBtn').onclick = manualLookup;
  $('#mVin').oninput = () => { const v = S.cleanVin($('#mVin').value); if (v.length === 17 && (!manualDecoded || manualDecoded.vin !== v)) manualLookup(); };
  $('#mGo').onclick = addManualCar;
  $('#edCarfaxBtn').onclick = async () => {
    const l = current(); if (!l) return;
    const b = $('#edCarfaxBtn'); b.disabled = true;
    try {
      const r = await applyCarfaxLink(l, $('#edCarfaxUrl').value, (step) => setStatus(`${step.charAt(0).toUpperCase() + step.slice(1)}…`));
      const live = window.Dash && Dash.liveFor && Dash.liveFor(l.id);
      setStatus(r.kept ? 'CARFAX saved. Your own description was kept; click "Rewrite with AI" to add the CARFAX points.' : `CARFAX read and the description rewritten with it.${live ? ' Click "Update description on Facebook" to send it to the live post.' : ''}`, 'ok');
      renderEditor(); renderList();
    } catch (e) { setStatus(e.message, 'err'); renderEditor(); }
    finally { b.disabled = false; }
  };
  $('#deleteSelectedBtn').onclick = () => deleteCars(visibleListings().filter((l) => state.checked.has(l.id)).map((l) => l.id));
  $('#deleteBtn').onclick = async () => {
    const l = current();
    if (!confirm(`Delete ${l.fb.year} ${l.fb.make} ${l.fb.model} from this list?`)) return;
    state.listings = state.listings.filter((x) => x.id !== l.id);
    state.checked.delete(l.id);
    state.selectedId = null;
    await saveNow();
    renderList(); renderEditor();
  };
  $('#settingsBtn').onclick = openSettings;
  $('#saveSettings').onclick = saveSettings;
  $('#syncGroupsBtn').onclick = syncGroups;
  $('#groupFilter').oninput = renderGroups;
  $('#settingsDlg').addEventListener('close', () => { groupDraft = null; });
  $('#testKeyBtn').onclick = async () => {
    const cfg = { provider: $('#setProvider').value, key: $('#setApiKey').value.trim() };
    if (!cfg.key) { $('#keyStatus').textContent = 'Paste a key first.'; return; }
    $('#keyStatus').textContent = 'Testing…';
    try { await AI.testKey(cfg); $('#keyStatus').textContent = 'Key works.'; }
    catch (e) { $('#keyStatus').textContent = e.message; }
  };
  $('#setProvider').onchange = (e) => {
    keyDraft[e.target.dataset.prev || 'gemini'] = $('#setApiKey').value.trim();
    e.target.dataset.prev = e.target.value;
    showProvider();
  };
  $('#setProvider').onfocus = (e) => { e.target.dataset.prev = e.target.value; };
  $('#checkUpdateBtn').onclick = () => checkForUpdate(true);
  $('#settingsUpdateBtn').onclick = () => { $('#settingsDlg').close(); runUpdate(false); };
  $('#repickFolderBtn').onclick = async () => {
    try { await LHUpdater.pickFolder(); $('#updateStatus').textContent = 'Folder saved for updates.'; }
    catch (e) { if (e.name !== 'AbortError') $('#updateStatus').textContent = e.message; }
  };
  $('#updateBtn').onclick = () => runUpdate(false);

  renderAiTag();
  renderList();
  const first = state.listings.find((l) => l.status !== 'posted') || state.listings[0];
  if (first) select(first.id);
  $('#cloudSignInBtn').onclick = () => cloudAuth('in');
  $('#cloudSignUpBtn').onclick = () => cloudAuth('up');
  $('#cloudSignOutBtn').onclick = async () => { const c = cloudClient(); if (c) await c.signOut(); renderCloud(); };
  $('#cloudSyncBtn').onclick = async () => { $('#cloudStatus').textContent = 'Syncing…'; await send({ type: 'cloudSyncNow' }); renderCloud(); };
  if (params.get('cmd') && params.get('dealerPhotos')) { runPhoneDealerPhotos(); return; }
  if (params.get('cmd') && params.get('rewrite')) { runPhoneRewrite(); return; }
  if (params.get('cmd') && params.get('heroTest')) { runPhoneHeroTest(); return; }
  if (params.get('cmd')) { runPhoneImport(); return; }
  if (params.get('updated')) setStatus(`Updated to version ${chrome.runtime.getManifest().version}.`, 'ok');
  else if (!aiReady()) setStatus('Tip: add a free Gemini API key in Settings so AI can write descriptions and sort photos.');
  // dashboard.js loads after this file; wait for it instead of racing it.
  if (!window.Dash && document.readyState === 'loading') await new Promise((r) => document.addEventListener('DOMContentLoaded', r, { once: true }));
  if (window.Dash) await Dash.init();
  checkForUpdate(false);
}

init();
