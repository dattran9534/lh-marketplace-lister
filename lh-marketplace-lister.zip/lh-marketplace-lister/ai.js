/* AI calls made from the app page. Two providers:
 * - Google Gemini (default): free tier, key from aistudio.google.com
 * - Anthropic Claude: paid, key from console.anthropic.com
 * Keys are stored only in this browser. */
(function (global) {
  const GEMINI = 'https://generativelanguage.googleapis.com/v1beta/models/';
  // Writer tries the stronger model first, then the one with the bigger free allowance.
  const GEMINI_WRITER = ['gemini-3.8-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite'];
  const GEMINI_SORTER = ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'];
  const ANTHROPIC = 'https://api.anthropic.com/v1/messages';
  const CLAUDE_WRITER = ['claude-sonnet-5-5'];
  const CLAUDE_SORTER = ['claude-haiku-5-5'];

  class AIError extends Error {
    constructor(msg, retryOther) { super(msg); this.retryOther = retryOther; }
  }

  // parts: [{ text } | { image: base64 jpeg }]
  async function geminiCall(key, model, { system, parts, json, maxTokens, search }) {
    const body = {
      contents: [{ role: 'user', parts: parts.map((p) => (p.image ? { inline_data: { mime_type: 'image/jpeg', data: p.image } } : { text: p.text })) }],
      generationConfig: { maxOutputTokens: maxTokens || 2048, ...(json ? { responseMimeType: 'application/json' } : {}) },
    };
    if (system) body.systemInstruction = { parts: [{ text: system }] };
    // Google Search grounding: lets Gemini look at current listings and prices.
    if (search) { body.tools = [{ google_search: {} }]; delete body.generationConfig.responseMimeType; }
    const r = await fetch(`${GEMINI}${model}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(60000),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      const msg = (j.error && j.error.message) || `HTTP ${r.status}`;
      if (r.status === 400 && /api key/i.test(msg)) throw new AIError('The Google API key was not accepted. Check it in Settings.');
      if (r.status === 403) throw new AIError('The Google API key was not accepted. Check it in Settings.');
      // Quota used up, model busy, or model not offered: try the next model.
      if (r.status === 429 || r.status === 503 || r.status === 404) throw new AIError(r.status === 429 ? "Today's free Gemini limit is used up. It resets at midnight Pacific." : msg, true);
      throw new AIError(msg);
    }
    const cand = (j.candidates || [])[0];
    const text = cand && cand.content && (cand.content.parts || []).filter((p) => p.text && !p.thought).map((p) => p.text).join('').trim();
    if (!text) throw new AIError(cand && cand.finishReason ? `Gemini returned no text (${cand.finishReason})` : 'Gemini returned no text', true);
    return text;
  }

  async function claudeCall(key, model, { system, parts, maxTokens }) {
    const content = parts.map((p) => (p.image ? { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: p.image } } : { type: 'text', text: p.text }));
    const body = { model, max_tokens: maxTokens || 4000, messages: [{ role: 'user', content }] };
    if (system) body.system = system;
    const r = await fetch(ANTHROPIC, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(60000),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      const msg = (j.error && j.error.message) || `HTTP ${r.status}`;
      if (r.status === 401) throw new AIError('The Anthropic API key was not accepted. Check it in Settings.');
      if (/credit/i.test(msg)) throw new AIError('Your Anthropic account is out of credits.');
      throw new AIError(msg, r.status === 429 || r.status === 529);
    }
    return (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('').trim();
  }

  // cfg: { provider: 'gemini' | 'anthropic', key }
  async function run(cfg, role, req) {
    const gem = cfg.provider !== 'anthropic';
    const models = gem ? (role === 'writer' ? GEMINI_WRITER : GEMINI_SORTER) : role === 'writer' ? CLAUDE_WRITER : CLAUDE_SORTER;
    let last;
    // "High demand" / busy replies are usually gone in seconds: two more rounds, a little apart.
    for (let round = 0; round < 3; round++) {
      for (const m of models) {
        try {
          return gem ? await geminiCall(cfg.key, m, req) : await claudeCall(cfg.key, m, req);
        } catch (e) {
          last = e;
          if (!e.retryOther) throw e;
        }
      }
      if (/free Gemini limit|credits/i.test((last && last.message) || '')) break; // quota: waiting won't help
      await new Promise((r) => setTimeout(r, 4000 + round * 6000));
    }
    throw last;
  }

  const parseJson = (text) => {
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) throw new Error('Unexpected reply from the photo sorter');
    return JSON.parse(m[0]);
  };

  const ORDER = { exterior: 0, exterior_detail: 1, interior: 2, other: 3, unknown: 4 };

  // thumbs: base64 JPEGs (null for photos that failed). Returns 0 based results.
  async function classifyPhotos(cfg, thumbs) {
    const parts = [];
    thumbs.forEach((b64, i) => {
      if (!b64) return;
      parts.push({ text: `Image ${i + 1}:` });
      parts.push({ image: b64 });
    });
    parts.push({
      text:
        'These are photos from a used car listing. Label every image with one category:\n' +
        '- "exterior": the whole vehicle seen from outside, any angle\n' +
        '- "exterior_detail": close up of an outside part (wheel, headlight, badge, grille, tailgate)\n' +
        '- "interior": inside the cabin (seats, dashboard, steering wheel, screen, door panel, headliner) or the cargo area / trunk\n' +
        '- "other": engine bay, keys, manuals, documents, window sticker, logos or anything else\n' +
        'For every "exterior" image also give its "view": "front_three_quarter" (front and one side), "front" (straight on), "side", "rear_three_quarter" or "rear".\n' +
        'Also choose "hero": the photo to show first. It must show the FRONT of the car: the front three quarter view of the whole car (front and driver side), often parked on the waterfront with mountains and a ferry behind it. If there is no such photo, pick the best front three quarter or straight-front exterior. Never a rear or side view if a front view exists.\n' +
        COLOR_ASK +
        'Reply with JSON only, using the image numbers shown: {"labels": {"1": "exterior", "2": "interior"}, "views": {"1": "front_three_quarter"}, "hero": 1, "exteriorColor": "Red", "interiorColor": "Gray"}',
    });
    const text = await run(cfg, 'sorter', { parts, json: true, maxTokens: 4096 });
    const j = parseJson(text);
    const valid = (v) => (typeof v === 'string' && ORDER[v.toLowerCase().trim()] !== undefined ? v.toLowerCase().trim() : 'unknown');
    const src = j.labels || {};
    const labels = thumbs.map((_, i) => valid(Array.isArray(src) ? src[i] : src[String(i + 1)]));
    const vs = j.views || {};
    const views = thumbs.map((_, i) => String((Array.isArray(vs) ? vs[i] : vs[String(i + 1)]) || '').toLowerCase());
    const h = Number(j.hero);
    let hero = h >= 1 && h <= thumbs.length && labels[h - 1] === 'exterior' ? h - 1 : -1;
    // Front first: if the pick isn't a front view but one exists, use the first front view.
    const front = (i) => /front/.test(views[i]);
    if (hero < 0 || (views[hero] && !front(hero))) { const f = views.findIndex((v, i) => labels[i] === 'exterior' && /front_three/.test(v)); const f2 = views.findIndex((v, i) => labels[i] === 'exterior' && /front/.test(v)); hero = f >= 0 ? f : f2 >= 0 ? f2 : hero >= 0 ? hero : labels.indexOf('exterior'); }
    return { labels, views, hero, ...pickColors(j) };
  }

  // Facebook's color choices. The car's paint and the seat color, as seen in the photos.
  const FB_COLORS = ['Black', 'Blue', 'Brown', 'Gold', 'Green', 'Gray', 'Pink', 'Purple', 'Red', 'Silver', 'Orange', 'White', 'Yellow', 'Charcoal', 'Off white', 'Tan', 'Beige', 'Burgundy', 'Turquoise'];
  const COLOR_ASK =
    `Also give "exteriorColor" (the paint) and "interiorColor" (the main color of the seats and dash), each exactly one of: ${FB_COLORS.join(', ')}. ` +
    'Light grey or dark grey seats are "Gray". Cream or light tan seats are "Beige". Metallic silver paint is "Silver", darker grey paint is "Gray". Ignore the background, reflections and the dealer banner.\n';
  function pickColors(j) {
    const one = (v) => { const s = String(v || '').toLowerCase().replace(/grey/g, 'gray').trim(); return FB_COLORS.find((c) => c.toLowerCase() === s) || [...FB_COLORS].sort((x, y) => y.length - x.length).find((c) => new RegExp(`\\b${c.toLowerCase()}\\b`).test(s)) || ''; };
    return { exteriorColor: one(j.exteriorColor), interiorColor: one(j.interiorColor) };
  }

  // Is this car actually rare or in demand right now? Gemini searches current listings
  // (Google Search grounding), then answers. Falls back to its own knowledge if search isn't available.
  async function marketCheck(cfg, car) {
    const ask = (search) => run(cfg, 'sorter', {
      search,
      maxTokens: 2048,
      parts: [{ text:
        `A used ${car.name} with ${Number(car.mileage || 0).toLocaleString('en-US')} miles${car.extras ? ` (${car.extras})` : ''} is for sale at a dealer near Seattle, WA. ` +
        (search ? 'Look at how many comparable ones are for sale near Seattle right now and how fast this model sells. ' : '') +
        'Be strict and honest: most cars are NOT rare, and a popular model with normal miles for its age is NOT special. ' +
        'Never say a car sells fast or is in demand just because the model is popular (for example "Odysseys are in high demand"). ' +
        'Only call it rare or in demand if it also has low miles for its year (well under 12,000 miles a year); if so, the closing line should mention the low miles. ' +
        'Most cars are NOT rare. Call it rare only if comparable ones (same model, similar year and miles or trim) are genuinely scarce. Call demand high only if this model is known to sell fast or hold value unusually well. ' +
        'If it is rare or in high demand, also write one short closing line for a Facebook Marketplace post that says why in plain words, specific to this car (no hype words, no price, max 14 words, end with ! or .). Otherwise closing is "". ' +
        'Reply with JSON only: {"rare": false, "demand": "high" | "normal" | "low", "why": "short reason", "closing": ""}' }],
    });
    let text;
    try { text = await ask(cfg.provider !== 'anthropic'); } catch (e) { text = await ask(false); }
    const j = parseJson(text);
    const closing = String(j.closing || '').replace(/["*]/g, '').trim();
    return {
      rare: j.rare === true,
      demand: ['high', 'normal', 'low'].includes(j.demand) ? j.demand : 'normal',
      why: String(j.why || '').slice(0, 200),
      closing: (j.rare === true || j.demand === 'high') && closing.split(/\s+/).length <= 16 && !/price|\$|deal of|steal/i.test(closing) ? closing : '',
      at: Date.now(),
    };
  }

  // Standard features of a trim, from the model's own knowledge, when the dealer page lists few.
  async function trimFeatures(cfg, car) {
    const text = await run(cfg, 'sorter', {
      parts: [{ text:
        `List the 4 features of a ${car} that a used car shopper would find most appealing (for example heated seats, leather, moonroof, premium audio, parking sensors, adaptive cruise, wireless CarPlay, remote start). ` +
        'Only list features that are standard on this exact trim and year, and only if you are sure. Skip basics like Bluetooth, airbags, backup camera, keyless entry. ' +
        'Reply with JSON only: {"features": ["heated seats", "leather seats"]}' }],
      json: true, maxTokens: 1024,
    });
    const j = parseJson(text);
    return (Array.isArray(j.features) ? j.features : []).map((x) => String(x).trim()).filter((x) => x && x.length < 50).slice(0, 6);
  }

  // Colors only, for cars imported before color detection (a few photos are enough).
  async function detectColors(cfg, thumbs) {
    const parts = [];
    thumbs.filter(Boolean).slice(0, 10).forEach((b64, i) => { parts.push({ text: `Image ${i + 1}:` }); parts.push({ image: b64 }); });
    if (!parts.length) return { exteriorColor: '', interiorColor: '' };
    parts.push({ text: 'These are photos of one used car for sale. ' + COLOR_ASK + 'Reply with JSON only: {"exteriorColor": "Red", "interiorColor": "Gray"}' });
    return pickColors(parseJson(await run(cfg, 'sorter', { parts, json: true, maxTokens: 1024 })));
  }

  // Returns a new image array: hero first, then exterior, details, interior, other.
  // Exterior walk-around order: front three quarter, front, side, rear three quarter, rear.
  const VIEW = { front_three_quarter: 0, front: 1, side: 2, rear_three_quarter: 3, rear: 4 };
  function sortImages(images, labels, hero, views = []) {
    return images
      .map((im, i) => ({ im: { ...im, kind: labels[i] || 'unknown', view: views[i] || '' }, i }))
      .sort((a, b) => {
        if (a.i === hero) return -1;
        if (b.i === hero) return 1;
        const k = (ORDER[a.im.kind] ?? 4) - (ORDER[b.im.kind] ?? 4);
        if (k) return k;
        if (a.im.kind === 'exterior') return (VIEW[a.im.view] ?? 2.5) - (VIEW[b.im.view] ?? 2.5) || a.i - b.i;
        return a.i - b.i;
      })
      .map((x) => x.im);
  }

  // Dat's own example of how he wants a post to read.
  const EXAMPLE =
    '\u{1F4CD} Contact me, Dat, for more information or schedule for test drive!!!\n' +
    'Recently arrived! 2024 Honda Civic Sedan Touring. Comes equipped with heated leather seats, a moonroof, navigation, and remote start. Will be reconditioned and be Honda Pre-owned Certified, which will have the Honda warranty up to 2031!';
  // How the seller's notes should be worked in (an illustration of flow, not a real car).
  const NOTES_EXAMPLE =
    'Notes "one owner, new tires, timing belt done, no smoke, no pets" read smoothly as: ' +
    '"One owner with no accidents reported, and it comes from a non-smoking, pet-free home. The timing belt was just done and it has a brand new set of tires."';

  const SYSTEM =
    'You help Dat, a car salesperson at Lynnwood Honda in Edmonds, Washington, write his Facebook Marketplace car posts. ' +
    'You get a rough draft with this car\'s real facts and the seller\'s notes. Rewrite it so it reads smoothly, like Dat wrote it in one go for a customer: friendly, confident, plain everyday words.\n\n' +
    'This is his voice:\n' + EXAMPLE + '\n\n' +
    'How the post goes:\n' +
    '- Line 1: the opening line from the draft, copied exactly.\n' +
    '- Then ONE flowing paragraph. Start with "Recently arrived!" and the car with its biggest standout (low miles for the year, a sporty trim, AWD...). ' +
    'Then its history and the seller\'s notes, then "Comes equipped with ..." and the features, then the Honda certified / warranty sentence if the draft has one (keep its year exactly), and the closing line last if the draft has one.\n' +
    '- Make it flow: join related facts in the same sentence (history with ownership, care notes together), use natural connectors (and, with, plus, it also), and vary how sentences start. ' +
    'No list of short fragments, no sentence shorter than four words (except "Recently arrived!"), and never say the same fact twice.\n' +
    '- The seller\'s notes matter most. Keep every one, but say it the way a person would, grouping related ones. ' + NOTES_EXAMPLE + '\n' +
    '- Keep every fact and number from the draft (miles, warranty year, one owner, clean title, no accidents, AWD, each feature named). Never add a fact that is not in the draft or notes.\n' +
    '- About the same length as the draft; a sentence longer at most.\n' +
    '- Never mention damage beyond "no accidents reported", price, payments, financing, phone numbers, hashtags, emojis other than the opening line\'s, MPG or markdown.\n' +
    '- Never use: "Pacific Northwest", "making it a great", "perfect for", "great choice", "look no further", "won\'t last", "must see", "packed with", "boasts", "whether you\'re", "adventures", "on the go", "peace of mind", "hit the road", "amazing", "incredible", "stunning", "don\'t miss", "Just got this one in".\n' +
    '- If you are shown Dat\'s best performing posts or his own edits, borrow their wording and rhythm, never their facts.\n' +
    'Reply with the post text only.';

  // learn: { winners: [{ text, title, clicks, perDay }], edits: [text] } from Dat's own posts.
  function learnBlock(learn) {
    if (!learn) return '';
    const out = [];
    if (learn.winners && learn.winners.length) {
      out.push("Dat's posts that got the most clicks per day on Facebook. Copy what makes them work, not their facts:");
      learn.winners.forEach((w, i) => out.push(`--- Top post ${i + 1}: ${w.title}, ${w.clicks} clicks (${w.perDay} a day) ---\n${w.text}`));
    }
    if (learn.edits && learn.edits.length) {
      out.push('Descriptions Dat rewrote himself. This is exactly how he likes them to sound:');
      learn.edits.forEach((t, i) => out.push(`--- Dat's edit ${i + 1} ---\n${t}`));
    }
    return out.length ? out.join('\n') + '\n\nNow write the post for this car:\n' : '';
  }

  // What's wrong with a reply, or '' if it's fine.
  function problems(out, draft, keep) {
    const FILLER = /(\bMPG\b|miles per gallon|Pacific Northwest|making it a great|perfect for|great choice|great option|look no further|won't last|must see|packed with|boasts|whether you're|on the go|peace of mind|hit the road|don't miss|amazing|incredible|stunning)/i;
    const SCARCE = /hard(er)? to find|high demand|won't (sit|last)|don't sit|go(es)? fast|rare/i;
    const words = (t) => t.split(/\s+/).filter(Boolean).length;
    const lc = out.toLowerCase();
    const missing = (keep || []).filter((k) => !lc.includes(String(k).toLowerCase()));
    if (missing.length) return `you left out: ${missing.join(', ')}`;
    const f = out.match(FILLER);
    if (f) return `don't use "${f[0]}"`;
    if (SCARCE.test(out) && !SCARCE.test(draft)) return 'don\'t call it rare or in demand (the draft doesn\'t)';
    if (!/Recently arrived/i.test(out)) return 'start the paragraph with "Recently arrived!"';
    if (words(out) > words(draft) * 1.6 + 12) return 'it is too long, keep it close to the draft\'s length';
    if (words(out) < words(draft) * 0.6) return 'it is too short, keep every fact from the draft';
    // Choppy: a run of tiny sentences ("New tires. No pets.") after the opening line.
    const body = out.split('\n').slice(1).join(' ');
    const tiny = body.split(/(?<=[.!?])\s+/).filter((x) => x && !/^Recently arrived!?$/i.test(x.trim()) && words(x) < 4);
    if (tiny.length) return `these read choppy, work them into full sentences: ${tiny.slice(0, 3).map((x) => `"${x.trim()}"`).join(', ')}`;
    return '';
  }
  const tidyReply = (text, opening) => {
    let out = text.replace(/^["'`]+|["'`]+$/g, '').replace(/\*\*/g, '').replace(/\n{2,}/g, '\n').trim();
    if (opening && !out.startsWith(opening.slice(0, 12))) out = `${opening}\n${out}`;
    return out.replace(/just got this one in/gi, 'Recently arrived');
  };

  // draft: Dat-style post built from the facts. keep: strings that must survive (miles, warranty year,
  // a stem of each of your notes). One retry with what was wrong; then the draft itself is used.
  async function writeDescription(cfg, facts, opening, learn, draft, keep) {
    const base = learnBlock(learn) + `Draft:\n${draft}`;
    let last = '';
    for (let attempt = 0; attempt < 2; attempt++) {
      const prompt = attempt ? `${base}\n\nYour last version:\n${last}\n\nFix this and write it again: ${problems(last, draft, keep)}.` : base;
      const out = tidyReply(await run(cfg, 'writer', { system: SYSTEM, parts: [{ text: prompt }], maxTokens: 2000 }), opening);
      if (!problems(out, draft, keep)) return out;
      last = out;
    }
    const e = new Error(`AI reply didn't pass (${problems(last, draft, keep)}), used the draft`);
    e.draft = true;
    throw e;
  }

  async function testKey(cfg) {
    await run(cfg, 'sorter', { parts: [{ text: 'Reply with OK.' }], maxTokens: 1024 });
    return true;
  }

  global.LHAI = { problems, marketCheck, trimFeatures, detectColors, classifyPhotos, sortImages, writeDescription, testKey, ORDER };
})(typeof window !== 'undefined' ? window : globalThis);
