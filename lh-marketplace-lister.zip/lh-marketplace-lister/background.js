importScripts('shared.js', 'extractor.js', 'localphotos.js', 'cloud.js', 'cloudsync.js');

const APP_URL = chrome.runtime.getURL('app.html');
const COMPOSER_URL = 'https://www.facebook.com/marketplace/create/vehicle';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function openApp(query = '') {
  const tabs = await chrome.tabs.query({});
  const existing = tabs.find((t) => (t.url || '').startsWith(APP_URL));
  const target = APP_URL + query;
  if (existing) {
    await chrome.tabs.update(existing.id, { url: target, active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: target });
  }
}

// Toolbar button: open the app, remembering the tab you were on.
chrome.action.onClicked.addListener((tab) => {
  const usable = tab && tab.id != null && /^https?:/i.test(tab.url || '') && !/facebook\.com/i.test(tab.url || '');
  openApp(usable ? `?src=${tab.id}` : '');
});

// After a one-click update the app tab closes; bring it back.
chrome.runtime.onInstalled.addListener((d) => {
  if (d.reason === 'update') openApp('?updated=1');
});

function waitForComplete(tabId, timeout = 45000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (err) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      err ? reject(err) : resolve();
    };
    const listener = (id, info) => { if (id === tabId && info.status === 'complete') finish(); };
    const timer = setTimeout(() => finish(new Error('The page took too long to load')), timeout);
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((t) => t.status === 'complete' && finish()).catch(() => {});
  });
}

// ---------- hidden work window ----------
// Facebook, dealer and CARFAX pages the app works in open in one minimized browser window
// (Settings → "Where the app works"), so no tabs pop up next to yours.
let workLock = Promise.resolve();
async function openWork(url, { visible = false } = {}) {
  const run = async () => {
    const { settings = {}, workWindowId, workGroupId } = await chrome.storage.local.get(['settings', 'workWindowId', 'workGroupId']);
    const mode = settings.workWhere || 'window';
    if (visible || mode === 'tab') return chrome.tabs.create({ url, active: !!visible });
    if (mode === 'group') {
      const t = await chrome.tabs.create({ url, active: false });
      try {
        let gid = workGroupId;
        const g = gid != null ? await chrome.tabGroups.get(gid).catch(() => null) : null;
        if (g && g.windowId === t.windowId) await chrome.tabs.group({ tabIds: [t.id], groupId: gid });
        else { gid = await chrome.tabs.group({ tabIds: [t.id] }); await chrome.storage.local.set({ workGroupId: gid }); }
        await chrome.tabGroups.update(gid, { collapsed: true, title: 'LH working', color: 'grey' });
      } catch (e) {}
      return t;
    }
    const win = workWindowId != null ? await chrome.windows.get(workWindowId).catch(() => null) : null;
    if (win) return chrome.tabs.create({ windowId: win.id, url, active: true });
    let w;
    try { w = await chrome.windows.create({ url, focused: false, state: 'minimized' }); }
    catch (e) { w = await chrome.windows.create({ url, focused: false }); }
    if (w.state !== 'minimized') chrome.windows.update(w.id, { state: 'minimized' }).catch(() => {});
    await chrome.storage.local.set({ workWindowId: w.id });
    return w.tabs[0];
  };
  const p = workLock.then(run, run).then(async (t) => {
    // Remember every tab the app opened, so none are left behind.
    const { workTabs = {} } = await chrome.storage.local.get('workTabs');
    if (t && t.id != null) { workTabs[t.id] = Date.now(); await chrome.storage.local.set({ workTabs }); }
    return t;
  });
  workLock = p.catch(() => {});
  return p;
}
async function closeWorkTab(tabId) {
  await chrome.tabs.remove(Number(tabId)).catch(() => {});
  const { workTabs = {} } = await chrome.storage.local.get('workTabs');
  if (workTabs[tabId]) { delete workTabs[tabId]; await chrome.storage.local.set({ workTabs }); }
}
// Every few minutes: close app tabs whose work is over (finished, failed, or forgotten).
async function sweepWorkTabs() {
  const { workTabs = {}, fbJobs = {}, composerTabs = {}, loginPosts = {}, pendingTabs = {}, cmdTabs = {} } =
    await chrome.storage.local.get(['workTabs', 'fbJobs', 'composerTabs', 'loginPosts', 'pendingTabs', 'cmdTabs']);
  const busy = new Set([...Object.keys(fbJobs), ...Object.keys(loginPosts), ...Object.keys(pendingTabs),
    ...Object.entries(composerTabs).filter(([, c]) => !c.needsYou).map(([k]) => k), ...Object.values(cmdTabs).map((c) => String(c.tabId))]);
  const now = Date.now();
  for (const [tabId, at] of Object.entries(workTabs)) {
    const tab = await chrome.tabs.get(Number(tabId)).catch(() => null);
    if (!tab) { delete workTabs[tabId]; continue; }
    const c = composerTabs[tabId];
    const tooOld = now - at > (c && c.needsYou ? 6 * 3600000 : 25 * 60000); // a post waiting for you gets hours
    if ((!busy.has(tabId) && now - at > 3 * 60000 && !(c && c.needsYou)) || tooOld) { chrome.tabs.remove(Number(tabId)).catch(() => {}); delete workTabs[tabId]; }
  }
  for (const [tabId, j] of Object.entries(fbJobs)) if (now - j.at > 30 * 60000 && j.state !== 'login') { delete fbJobs[tabId]; chrome.tabs.remove(Number(tabId)).catch(() => {}); }
  await chrome.storage.local.set({ workTabs, fbJobs });
}
chrome.alarms.create('sweepTabs', { periodInMinutes: 3 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'sweepTabs') sweepWorkTabs(); });
// A post that needs you (a field didn't fill): show its tab, keep it open, and tell the app.
async function needYou({ id, why }, sender) {
  const tabId = sender.tab && sender.tab.id;
  const { composerTabs = {}, listings = [] } = await chrome.storage.local.get(['composerTabs', 'listings']);
  if (composerTabs[tabId]) composerTabs[tabId].needsYou = true;
  const l = listings.find((x) => x.id === id);
  await chrome.storage.local.set({ composerTabs, postProblem: { id, title: l ? `${l.fb.year} ${l.fb.make} ${l.fb.model}` : 'A car', code: 'needsYou', error: `It needs you on Facebook: ${why}. The Facebook window is open; fix it and click Publish.`, at: Date.now(), tabId } });
  await reveal(tabId);
  return {};
}
// Bring a work tab to the front (to log in, or when Facebook needs it visible).
async function reveal(tabId) {
  const t = await chrome.tabs.update(Number(tabId), { active: true }).catch(() => null);
  if (!t) return;
  const { workWindowId } = await chrome.storage.local.get('workWindowId');
  if (t.groupId != null && t.groupId > -1) chrome.tabGroups.update(t.groupId, { collapsed: false }).catch(() => {});
  await chrome.windows.update(t.windowId, t.windowId === workWindowId ? { state: 'normal', focused: true } : { focused: true }).catch(() => {});
}
// Put the work window back out of sight.
async function hideWork() {
  const { workWindowId } = await chrome.storage.local.get('workWindowId');
  if (workWindowId != null) chrome.windows.update(workWindowId, { state: 'minimized' }).catch(() => {});
}

async function withBackgroundTab(url, wait, fn) {
  const tab = await openWork(url);
  try {
    await waitForComplete(tab.id);
    await sleep(wait);
    return await fn(tab.id);
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function runExtractor(tabId) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: extractVehicle, world: 'MAIN' });
  const data = res && res.result;
  if (!data || (!data.vin && !data.model)) throw new Error("Couldn't find vehicle details on that page. Open a single vehicle's page and try again.");
  return data;
}

// Second source that doesn't depend on how the tab rendered: the page's HTML,
// read directly. Fills anything the tab missed (miles, photos, MPG, price...).
async function htmlFacts(url) {
  try {
    const resp = await fetch(url, { credentials: 'include', signal: AbortSignal.timeout(20000) });
    if (resp.status === 404 || resp.status === 410) return { gone: true, images: [] };
    const html = await resp.text();
    // A sold car's page redirects to the inventory list or says it's no longer available.
    if (!/viewdetails/i.test(resp.url) || /no longer available|vehicle (has been )?sold|not available/i.test(html.slice(0, 200000)) && !/mileageFromOdometer/.test(html)) return { gone: true, images: [] };
    const nodes = [];
    const walk = (o) => {
      if (!o || typeof o !== 'object') return;
      if (Array.isArray(o)) return o.forEach(walk);
      nodes.push(o);
      ['@graph', 'itemOffered', 'mainEntity', 'about'].forEach((k) => o[k] && walk(o[k]));
    };
    for (const m of html.matchAll(/<script[^>]*application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi)) { try { walk(JSON.parse(m[1])); } catch (e) {} }
    // lynnwoodhonda.com adds the Vehicle schema with JavaScript after the page loads;
    // it sits in the HTML as plain JSON, so cut that object out by matching braces.
    for (const m of html.matchAll(/"@type"\s*:\s*"(?:Vehicle|Car)"/g)) {
      let depth = 0, a = m.index;
      for (; a >= 0; a--) { const ch = html[a]; if (ch === '}') depth++; else if (ch === '{') { if (!depth) break; depth--; } }
      if (a < 0) continue;
      let b = a, d = 0, inStr = false;
      for (; b < html.length; b++) {
        const ch = html[b];
        if (inStr) { if (ch === '\\') b++; else if (ch === '"') inStr = false; continue; }
        if (ch === '"') inStr = true; else if (ch === '{') d++; else if (ch === '}' && !--d) break;
      }
      try { walk(JSON.parse(html.slice(a, b + 1))); } catch (e) {}
    }
    const ld = nodes.find((o) => /\b(Car|Vehicle|MotorVehicle)\b/i.test([].concat(o['@type'] || []).join(' '))) || {};
    const num = (s) => { const m = String(s ?? '').replace(/,/g, '').match(/\d+(\.\d+)?/); return m ? Math.round(parseFloat(m[0])) : null; };
    const odo = ld.mileageFromOdometer;
    const fe = [].concat(ld.fuelEfficiency || []);
    const mpg = (re) => { const x = fe.find((q) => re.test(q.name || '')); return x ? num(x.value) : null; };
    const text = html.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ');
    const photos = [];
    (html.match(/https?:\/\/content\.homenetiol\.com\/[^"'\s<>()\\,]+?\.(?:jpe?g|png|webp)/gi) || []).forEach((u) => {
      u = u.replace(/\/\d+x\d+\//, '/0x0/');
      if (!photos.includes(u)) photos.push(u);
    });
    const offers = [].concat(ld.offers || []);
    const prices = offers.map((o) => num(o.price ?? o.lowPrice)).filter((p) => p && p > 500);
    return {
      mileage: num(odo && typeof odo === 'object' ? odo.value : odo) || num((text.match(/Mileage:?\s*([\d,]{2,7})\s*Mi/i) || [])[1]),
      mpgCity: mpg(/city/i), mpgHwy: mpg(/highway|hwy/i),
      price: prices.length ? Math.min(...prices) : null,
      vin: String(ld.vehicleIdentificationNumber || '').toUpperCase(),
      year: num(ld.vehicleModelDate || ld.modelDate),
      drivetrain: (html.match(/\bdrivetrain["']?\s*:\s*["']([^"']{1,40})["']/) || [])[1] || String(ld.driveWheelConfiguration || ''),
      images: photos,
    };
  } catch (e) {
    return null;
  }
}

function mergeFacts(data, h) {
  if (!h) return data;
  for (const k of ['mileage', 'mpgCity', 'mpgHwy', 'price', 'vin', 'year']) if (!data[k] && h[k]) data[k] = h[k];
  // The page's own vehicle data is the most reliable drive type.
  const d = h.drivetrain || '';
  const drive = /\b(AWD|all[\s-]?wheel)/i.test(d) ? 'AWD' : /\b(4WD|4x4|four[\s-]?wheel)/i.test(d) ? '4WD' : /\b(2WD|FWD|RWD|front|rear)/i.test(d) ? '2WD' : '';
  if (drive) data.drive = drive;
  // Prefer the HTML photo list when the tab saw fewer (the full list in the dealer's order).
  if (h.images.length > (data.images || []).length) {
    data.images = h.images.map((url) => ({ url, fallback: '' }));
    data.stockPhotos = h.images.every((u) => /stock_images|stockphoto|\/stock\//i.test(u));
  }
  return data;
}

async function extractFromTab({ tabId }) {
  const tab = await chrome.tabs.get(tabId);
  const [data, h] = await Promise.all([runExtractor(tabId), htmlFacts(tab.url)]);
  return { data: mergeFacts(data, h) };
}

async function extractFromUrl({ url }) {
  const hP = htmlFacts(url);
  let data = await withBackgroundTab(url, 900, runExtractor);
  data = mergeFacts(data, await hP);
  // A first visit sometimes gets a half-built page. One more try fixes it.
  if (!data.mileage || (data.images || []).length < 3) {
    await sleep(1500);
    const again = mergeFacts(await withBackgroundTab(url, 2500, runExtractor).catch(() => null) || {}, await htmlFacts(url));
    for (const k of Object.keys(again)) if (again[k] && (!data[k] || (k === 'images' && again.images.length > data.images.length))) data[k] = again[k];
  }
  return { data };
}

// CARFAX reports render in the browser, so read them from a real tab.
async function extractCarfax({ url }) {
  const text = await withBackgroundTab(url, 300, async (tabId) => {
    let t = '';
    // Check often instead of waiting a fixed time: most reports are ready in 1 to 3 seconds.
    for (let i = 0; i < 25; i++) {
      const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: () => document.body.innerText.slice(0, 40000) });
      t = (res && res.result) || '';
      if (/Ownership History|Service History|Title History/i.test(t) && /Detailed History|Vehicle sold|Registration/i.test(t)) break;
      await sleep(600);
    }
    return t;
  });
  if (!/carfax/i.test(text)) throw new Error('The CARFAX report did not load');
  return { text };
}

// Vehicle links on an inventory / search results page.
async function listVehicleLinks({ tabId }) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => [...new Set([...document.querySelectorAll('a[href*="/viewdetails/"]')].map((a) => a.href.split('?')[0].split('#')[0]))],
  });
  return { links: (res && res.result) || [] };
}

async function fetchImage({ url, fallback, local, cloud: cloudPath }) {
  if (local || cloudPath) {
    let blob = local ? await LHLocal.get(local).catch(() => null) : null;
    if (!blob && cloudPath) {
      // A photo added on the phone.
      const { settings = {} } = await chrome.storage.local.get('settings');
      const c = LHCloud({ url: settings.cloudUrl, key: settings.cloudKey, store: { get: async (k) => (await chrome.storage.local.get(k))[k], set: async (k, v) => chrome.storage.local.set({ [k]: v }) } });
      blob = await c.photos.download(cloudPath);
    }
    if (!blob) throw new Error('Your photo was not found');
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return { dataUrl: `data:${blob.type || 'image/jpeg'};base64,${btoa(bin)}` };
  }
  for (const u of [url, fallback].filter(Boolean)) {
    try {
      const r = await fetch(u, { credentials: 'omit' });
      if (!r.ok) continue;
      const blob = await r.blob();
      if (!/^image\//.test(blob.type) && blob.size < 5000) continue;
      const bytes = new Uint8Array(await blob.arrayBuffer());
      let bin = '';
      for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      return { dataUrl: `data:${blob.type || 'image/jpeg'};base64,${btoa(bin)}` };
    } catch (e) {}
  }
  throw new Error('Photo download failed');
}

// One Facebook form per vehicle. Each tab is told which vehicle is its own.
// ---------- safe pace posting ----------
// Cars go into a line and post one at a time with a random 3 to 8 minute gap,
// up to a daily cap (default 5), so the account looks like a person posting.
const DAY = 24 * 3600 * 1000;
async function paceSettings() {
  const { settings = {} } = await chrome.storage.local.get('settings');
  return {
    cap: Math.max(1, Math.min(20, Number(settings.postsPerDay) || 5)),
    gapMin: Math.max(1, Number(settings.postGapMin) || 3),
    gapMax: Math.max(2, Number(settings.postGapMax) || 8),
  };
}

async function openOneComposer(id) {
  const { pendingTabs = {} } = await chrome.storage.local.get('pendingTabs');
  // Opens behind your current tab so it doesn't interrupt you.
  // Review-before-publishing mode needs you to see it; otherwise it works out of sight.
  const { settings: st = {} } = await chrome.storage.local.get('settings');
  const review = st.publishOnPost === false && !st.autoPost;
  const tab = review ? await chrome.tabs.create({ url: COMPOSER_URL, active: false }) : await openWork(COMPOSER_URL);
  pendingTabs[tab.id] = { id, at: Date.now() };
  const { composerTabs = {}, retriedPosts = {} } = await chrome.storage.local.get(['composerTabs', 'retriedPosts']);
  composerTabs[tab.id] = { id, at: Date.now(), retried: !!(retriedPosts[id] && Date.now() - retriedPosts[id] < 3600000) };
  await chrome.storage.local.set({ pendingTabs, composerTabs });
}

let queueBusy = false;
async function processPostQueue() {
  if (queueBusy) return;
  queueBusy = true;
  try {
    const { postQueue = [], postLog = [], nextPostAt = 0 } = await chrome.storage.local.get(['postQueue', 'postLog', 'nextPostAt']);
    const now = Date.now();
    const log = postLog.filter((t) => now - t < DAY);
    if (!postQueue.length) { await chrome.storage.local.set({ postLog: log, postQueueInfo: null }); return; }
    const { cap, gapMin, gapMax } = await paceSettings();
    let when = Math.max(nextPostAt, now);
    let why = 'spacing';
    // Hold new posts for busy Marketplace hours (unless you chose "post now" for this car).
    const { settings: st = {}, postNow = [] } = await chrome.storage.local.get(['settings', 'postNow']);
    if (st.busyTimes !== false && !postNow.includes(postQueue[0]) && !LHShared.isBusyTime(new Date(when))) { when = LHShared.nextBusyStart(new Date(when)); why = 'busy hours'; }
    if (log.length >= cap) { when = Math.max(when, Math.min(...log) + DAY + 60000); why = 'daily limit'; }
    if (when > now + 1000) {
      chrome.alarms.create('postQueue', { when });
      await chrome.storage.local.set({ postLog: log, postQueueInfo: { waiting: postQueue.length, nextAt: when, why } });
      return;
    }
    const id = postQueue.shift();
    await chrome.storage.local.set({ postNow: postNow.filter((x) => x !== id) });
    log.push(now);
    const gap = (gapMin + Math.random() * (gapMax - gapMin)) * 60000;
    await chrome.storage.local.set({ postQueue, postLog: log, nextPostAt: now + gap });
    await openOneComposer(id);
    if (postQueue.length) {
      const next = log.length >= cap ? Math.min(...log) + DAY + 60000 : now + gap;
      chrome.alarms.create('postQueue', { when: next });
      await chrome.storage.local.set({ postQueueInfo: { waiting: postQueue.length, nextAt: next, why: log.length >= cap ? 'daily limit' : 'spacing' } });
    } else {
      await chrome.storage.local.set({ postQueueInfo: null });
    }
  } finally {
    queueBusy = false;
  }
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'postQueue') processPostQueue(); });

async function openComposer({ id, ids, now: rightAway }) {
  const list = ids || [id];
  const { postQueue = [], postNow = [] } = await chrome.storage.local.get(['postQueue', 'postNow']);
  for (const x of list) if (!postQueue.includes(x)) postQueue.push(x);
  await chrome.storage.local.set({ postQueue, postNow: rightAway ? [...new Set([...postNow, ...list])] : postNow });
  await processPostQueue();
  const { postQueueInfo } = await chrome.storage.local.get('postQueueInfo');
  return { queue: postQueueInfo };
}

async function cancelPostQueue() {
  await chrome.storage.local.set({ postQueue: [], postQueueInfo: null, postNow: [] });
  chrome.alarms.clear('postQueue');
  return {};
}

async function myListing(msg, sender) {
  const tabId = sender.tab && sender.tab.id;
  const { pendingTabs = {} } = await chrome.storage.local.get('pendingTabs');
  const hit = pendingTabs[tabId];
  if (hit) {
    delete pendingTabs[tabId];
    // Drop stale entries too.
    for (const k of Object.keys(pendingTabs)) if (Date.now() - pendingTabs[k].at > 30 * 60 * 1000) delete pendingTabs[k];
    await chrome.storage.local.set({ pendingTabs });
  }
  return { pending: hit && Date.now() - hit.at < 30 * 60 * 1000 ? hit.id : null };
}

// ---------- Facebook jobs: sync, price change, sold/pending/available/delete ----------
// The app asks for a job; a Facebook tab opens, the content script does the
// work with Facebook's own buttons and reports back here.
// Facebook moves this page now and then (Oct 2026 /marketplace/seller/listings, Nov 2026 back to
// /marketplace/you/selling). The page tells us which one worked and we remember it.
const SELLING_URLS = ['https://www.facebook.com/marketplace/you/selling/', 'https://www.facebook.com/marketplace/seller/listings/'];
async function sellingUrl() {
  const { sellingUrl: u } = await chrome.storage.local.get('sellingUrl');
  return SELLING_URLS.includes(u) ? u : SELLING_URLS[0];
}
async function sellingWorked({ path }) {
  const u = SELLING_URLS.find((x) => x.includes(path.replace(/\/$/, '')));
  if (u) await chrome.storage.local.set({ sellingUrl: u });
  return {};
}

async function startFbJob({ job }, sender) {
  const jobId = crypto.randomUUID();
  const url = job.kind === 'renew' ? 'https://www.facebook.com/marketplace/selling/renew_listings/'
    : (job.kind === 'price' || job.kind === 'photos' || job.kind === 'readDesc' || job.kind === 'desc') && job.id ? `https://www.facebook.com/marketplace/edit/?listing_id=${job.id}` : await sellingUrl();
  // Background tab so you can keep working. The one exception is a full sync
  // (first time, or when asked): Facebook only loads older listings in a visible tab.
  const front = job.kind === 'sync' && job.full;
  const tab = await openWork(url, { visible: !!front });
  const { fbJobs = {} } = await chrome.storage.local.get('fbJobs');
  fbJobs[tab.id] = { ...job, jobId, url, at: Date.now(), returnTo: front && sender.tab ? sender.tab.id : null };
  await chrome.storage.local.set({ fbJobs });
  return { jobId };
}

async function myJob(msg, sender) {
  const { fbJobs = {} } = await chrome.storage.local.get('fbJobs');
  const job = fbJobs[sender.tab && sender.tab.id];
  if (job && !job.picked) { job.picked = true; job.beat = Date.now(); await chrome.storage.local.set({ fbJobs }); }
  return { job: job && Date.now() - job.at < 10 * 60 * 1000 ? job : null };
}

// ---------- watching Facebook jobs: closed tab, login page, no response ----------
// Each problem ends the job right away with a clear reason (code) instead of a long silent wait.
const PROBLEM = {
  closed: 'The Facebook tab was closed before it finished.',
  login: 'Facebook is asking you to log in. Log in on the Facebook tab that just opened, then tap Try again.',
  checkpoint: 'Facebook wants a security check. Finish it on the Facebook tab that just opened, then tap Try again.',
  stuck: "Facebook stopped responding (the page didn't load or froze).",
};
// Autopilot (on by default): a closed or frozen tab gets one fresh try by itself, and a login
// page waits for you (or for Facebook's one-tap "Continue as …") and then carries on.
async function failJob(tabId, code, { close = false, show = false } = {}) {
  const { fbJobs = {}, jobResults = {}, settings = {} } = await chrome.storage.local.get(['fbJobs', 'jobResults', 'settings']);
  const job = fbJobs[tabId];
  if (!job || jobResults[job.jobId]) return;
  const auto = settings.autopilot !== false;
  if (auto && (code === 'closed' || code === 'stuck') && (job.tries || 0) < 1 && job.url) {
    delete fbJobs[tabId];
    if (code === 'stuck') chrome.tabs.remove(Number(tabId)).catch(() => {});
    await chrome.storage.local.set({ fbJobs });
    await sleep(code === 'closed' ? 4000 : 1000);
    const t = await openWork(job.url);
    const again = (await chrome.storage.local.get('fbJobs')).fbJobs || {};
    again[t.id] = { ...job, tries: (job.tries || 0) + 1, at: Date.now(), picked: false, beat: 0, step: 'trying again by itself' };
    await chrome.storage.local.set({ fbJobs: again });
    return;
  }
  if (job.state === 'login' && (code === 'login' || code === 'checkpoint')) return; // already waiting
  if (auto && (code === 'login' || code === 'checkpoint')) {
    fbJobs[tabId] = { ...job, state: 'login', loginAt: Date.now(), picked: false, step: code === 'login' ? 'waiting for Facebook login' : 'waiting for Facebook security check', need: code };
    await chrome.storage.local.set({ fbJobs });
    reveal(tabId);
    return;
  }
  delete fbJobs[tabId];
  jobResults[job.jobId] = { ok: false, code, error: PROBLEM[code], at: Date.now() };
  await chrome.storage.local.set({ fbJobs, jobResults });
  if (close) chrome.tabs.remove(Number(tabId)).catch(() => {});
  if (show) reveal(tabId);
}
chrome.tabs.onRemoved.addListener((tabId) => { failJob(tabId, 'closed'); composerProblem(tabId, 'closed'); });
// A posting tab that was closed, or landed on a login page, before the car was published:
// put the car back to "not posted" and tell the app so it can offer to post again.
async function composerProblem(tabId, code) {
  const { composerTabs = {}, listings = [], settings = {}, loginPosts = {} } = await chrome.storage.local.get(['composerTabs', 'listings', 'settings', 'loginPosts']);
  const c = composerTabs[tabId];
  if (!c) return;
  delete composerTabs[tabId];
  const auto = settings.autopilot !== false;
  if (auto && (code === 'login' || code === 'checkpoint')) {
    // Wait in this tab; once you're logged in it goes back to the form and posts.
    loginPosts[tabId] = c.id;
    await chrome.storage.local.set({ composerTabs, loginPosts });
    reveal(tabId);
    return;
  }
  const car = listings.find((x) => x.id === c.id);
  if (auto && code === 'closed' && car && car.status !== 'posted' && !c.retried) {
    // Closed by accident? Put it back in the posting line once.
    const { postQueue = [] } = await chrome.storage.local.get('postQueue');
    if (!postQueue.includes(c.id)) postQueue.unshift(c.id);
    await chrome.storage.local.set({ composerTabs, postQueue, retriedPosts: { ...((await chrome.storage.local.get('retriedPosts')).retriedPosts || {}), [c.id]: Date.now() } });
    chrome.alarms.create('postQueue', { delayInMinutes: 0.5 });
    return;
  }
  const l = listings.find((x) => x.id === c.id);
  const update = { composerTabs };
  if (l && l.status !== 'posted') {
    l.status = 'draft';
    update.listings = listings;
    update.postProblem = { id: l.id, title: `${l.fb.year} ${l.fb.make} ${l.fb.model}`, code, error: code === 'closed' ? 'The Facebook tab was closed before the car was published.' : PROBLEM[code], at: Date.now(), tabId };
  }
  await chrome.storage.local.set(update);
}
const LOGIN_RE = /\/login|\/recover|login\.php|two_step_verification|\/two_factor|\/checkpoint/i;
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  const url = info.url || (info.status === 'complete' && tab && tab.url) || '';
  if (!/facebook\.com/.test(url)) return;
  // Back from the login page: carry on with the job (or the post) in the same tab.
  if (info.status === 'complete' && !LOGIN_RE.test(url)) {
    const { fbJobs = {}, loginPosts = {} } = await chrome.storage.local.get(['fbJobs', 'loginPosts']);
    const j = fbJobs[tabId];
    if (j && j.state === 'login') {
      fbJobs[tabId] = { ...j, state: '', at: Date.now(), picked: false, beat: 0, step: 'logged in, carrying on' };
      await chrome.storage.local.set({ fbJobs, fbLoginAt: Date.now() });
      chrome.tabs.update(tabId, { url: j.url }).catch(() => {});
      setTimeout(hideWork, 1500);
      return;
    }
    if (loginPosts[tabId]) {
      const id = loginPosts[tabId];
      delete loginPosts[tabId];
      const { pendingTabs = {}, composerTabs = {}, retriedPosts = {} } = await chrome.storage.local.get(['pendingTabs', 'composerTabs', 'retriedPosts']);
      pendingTabs[tabId] = { id, at: Date.now() };
      composerTabs[tabId] = { id, at: Date.now(), retried: !!(retriedPosts[id] && Date.now() - retriedPosts[id] < 3600000) };
      await chrome.storage.local.set({ loginPosts, pendingTabs, composerTabs, fbLoginAt: Date.now() });
      chrome.tabs.update(tabId, { url: COMPOSER_URL }).catch(() => {});
      return;
    }
  }
  if (/\/login|\/recover|login\.php|two_step_verification|\/two_factor/i.test(url)) { failJob(tabId, 'login', { show: true }); composerProblem(tabId, 'login'); }
  else if (/\/checkpoint/i.test(url)) { failJob(tabId, 'checkpoint', { show: true }); composerProblem(tabId, 'checkpoint'); }
});
// Is this tab one the app opened (a job or a car being posted)?
async function isAppTab(msg, sender) {
  const id = sender.tab && sender.tab.id;
  const { fbJobs = {}, loginPosts = {}, composerTabs = {} } = await chrome.storage.local.get(['fbJobs', 'loginPosts', 'composerTabs']);
  return { app: !!(fbJobs[id] || loginPosts[id] || composerTabs[id]) };
}
// The Facebook page says "still working" every few seconds while it runs a job.
async function jobBeat({ step }, sender) {
  const tabId = sender.tab && sender.tab.id;
  const { fbJobs = {} } = await chrome.storage.local.get('fbJobs');
  if (fbJobs[tabId]) { fbJobs[tabId].beat = Date.now(); if (step) fbJobs[tabId].step = step; await chrome.storage.local.set({ fbJobs }); }
  return {};
}
// Where a job stands. Ends it as "stuck" if the page never picked it up or went quiet.
async function jobStatus({ jobId }) {
  const { fbJobs = {}, jobResults = {} } = await chrome.storage.local.get(['fbJobs', 'jobResults']);
  if (jobResults[jobId]) return { done: true, result: jobResults[jobId] };
  const hit = Object.entries(fbJobs).find(([, j]) => j.jobId === jobId);
  if (!hit) return { done: true, result: { ok: false, code: 'closed', error: PROBLEM.closed } };
  const [tabId, j] = hit;
  const tab = await chrome.tabs.get(Number(tabId)).catch(() => null);
  if (!tab) { await failJob(tabId, 'closed'); return jobStatus({ jobId }); }
  const now = Date.now();
  if (j.state === 'login') {
    if (now - j.loginAt > 10 * 60000) { delete fbJobs[tabId]; jobResults[j.jobId] = { ok: false, code: j.need || 'login', error: PROBLEM[j.need || 'login'], at: now }; await chrome.storage.local.set({ fbJobs, jobResults }); return jobStatus({ jobId }); }
    return { done: false, step: j.step, login: true, need: j.need, tabId: Number(tabId) };
  }
  const quiet = j.picked ? now - (j.beat || j.at) > 90000 : now - j.at > 50000;
  if (quiet) { await failJob(tabId, 'stuck', { close: true }); return jobStatus({ jobId }); }
  return { done: false, step: j.step || (j.picked ? 'working' : 'opening Facebook'), tabId: Number(tabId) };
}
// Wait for a job, checking on it as it goes. Used by phone requests and auto renew.
async function watchJob(jobId, timeoutMs = 900000, onStep) {
  const t0 = Date.now();
  let last = '';
  while (Date.now() - t0 < timeoutMs) {
    await sleep(1500);
    const s = await jobStatus({ jobId });
    if (s.done) return s.result;
    if (onStep && s.step && s.step !== last) { last = s.step; onStep(s.step, s); }
  }
  await cancelJob({ jobId });
  return { ok: false, code: 'stuck', error: PROBLEM.stuck };
}

async function jobDone({ jobId, result }, sender) {
  const tabId = sender.tab && sender.tab.id;
  const { fbJobs = {}, jobResults = {} } = await chrome.storage.local.get(['fbJobs', 'jobResults']);
  const job = fbJobs[tabId];
  delete fbJobs[tabId];
  for (const k of Object.keys(jobResults)) if (Date.now() - jobResults[k].at > 60 * 60 * 1000) delete jobResults[k];
  jobResults[jobId] = { ...result, at: Date.now() };
  const update = { fbJobs, jobResults };
  if (result.groups) { update.fbGroups = result.groups; update.fbGroupsAt = Date.now(); }
  if (result.inGroups) {
    // What Facebook shows, plus what the app posted (in case Facebook doesn't mark them).
    const { fbListings = [] } = await chrome.storage.local.get('fbListings');
    for (const [k, names] of Object.entries(result.inGroups)) {
      const [title, price] = k.split('|');
      const f = fbListings.find((x) => x.title === title && (!price || !x.price || String(x.price) === price));
      if (f) { f.groups = [...new Set([...(f.groups || []), ...names])]; f.groupsCheckedAt = Date.now(); }
    }
    update.fbListings = fbListings;
  }
  if (result.picked && job) {
    // Remember the groups each post went to (shown on the dashboard and phone, and skipped next time).
    const { fbListings = [] } = await chrome.storage.local.get('fbListings');
    const f = fbListings.find((x) => x.title === job.title && (!job.price || !x.price || String(x.price) === String(job.price)));
    if (f) { f.groups = [...new Set([...(f.groups || []), ...result.picked])]; f.groupsAt = Date.now(); update.fbListings = fbListings; }
  }
  if (result.listings) {
    update.fbListings = await mergeListings(result.listings, result.full, job, result.complete);
    update.fbSyncedAt = Date.now();
  }
  await chrome.storage.local.set(update);
  await sleep(result.ok ? 800 : 2500);
  await closeWorkTab(tabId);
  if (job && job.returnTo) chrome.tabs.update(job.returnTo, { active: true }).catch(() => {});
  hideWork();
  return {};
}

// A full sync replaces the list. A partial one (background tab, or the cards
// on screen when you visit your selling page) updates what it saw and keeps the rest.
// Match the same listing across syncs: by Facebook id, else title + price, else title + date.
// (The new table page has no "Listed on" date, so old dates are carried over.)
function sameListing(a, b) {
  if (a.id && b.id) return a.id === b.id;
  if (a.title !== b.title) return false;
  if (a.price && b.price && String(a.price) === String(b.price)) return true;
  return !!(a.listedOn && b.listedOn && a.listedOn === b.listedOn);
}
const keepFilled = (fresh) => Object.fromEntries(Object.entries(fresh).filter(([, v]) => v !== '' && v != null));
async function mergeListings(seen, full, job, complete = []) {
  const { fbListings = [] } = await chrome.storage.local.get('fbListings');
  seen = seen.map((l) => (l.status ? l : { ...l, status: 'Active' }));
  const used = new Set();
  const merged = seen.map((f) => {
    const old = fbListings.find((o, i) => !used.has(i) && sameListing(o, f) && used.add(i));
    return old ? { ...old, ...keepFilled(f) } : f;
  });
  if (full) return merged;
  let rest = fbListings.filter((_, i) => !used.has(i));
  // Those tabs were read in full: an old Active/Pending entry not seen there is a leftover
  // (renamed, deleted or sold) and would show up as a duplicate.
  if (complete && complete.length) rest = rest.filter((l) => !complete.includes(l.status || 'Active'));
  // A confirmed action: set the new status even if that listing wasn't on screen.
  const target = job && job.kind === 'action' && { sold: 'Sold', pending: 'Pending', available: 'Active' }[job.action];
  if (target) [...merged, ...rest].forEach((l) => { if (l.title === job.title && (!job.price || !l.price || String(l.price) === String(job.price))) l.status = target; });
  // A deleted listing won't be seen again: drop it.
  if (job && job.action === 'delete') rest = rest.filter((l) => !(l.title === job.title && String(l.price) === String(job.price)));
  // Click history (one number per day) and clicks/day, trend and "slow" for each live post.
  merged.forEach((f) => { if ((f.status || 'Active') !== 'Sold' && f.clicks != null) LHShared.addClicks(f); });
  const all = [...merged, ...rest];
  LHShared.annotatePerformance(all);
  return all;
}

async function showMe(msg, sender) {
  const tabId = sender.tab && sender.tab.id;
  if (tabId != null) {
    const { fbJobs = {} } = await chrome.storage.local.get('fbJobs');
    const t = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (fbJobs[tabId] && t[0] && t[0].id !== tabId) { fbJobs[tabId].returnTo = t[0].id; await chrome.storage.local.set({ fbJobs }); }
    await reveal(tabId);
  }
  return {};
}

async function passiveSync({ listings }) {
  const merged = await mergeListings(listings, false, null);
  await chrome.storage.local.set({ fbListings: merged, fbSyncedAt: Date.now() });
  return {};
}

async function cancelJob({ jobId }) {
  const { fbJobs = {} } = await chrome.storage.local.get('fbJobs');
  for (const [tabId, j] of Object.entries(fbJobs)) {
    if (j.jobId === jobId) { delete fbJobs[tabId]; chrome.tabs.remove(Number(tabId)).catch(() => {}); }
  }
  await chrome.storage.local.set({ fbJobs });
  return {};
}

// Auto post finished in a Facebook tab.
async function markPosted({ id }, sender) {
  const postTab = sender && sender.tab && sender.tab.id;
  if (postTab != null) (async () => { await sleep(5000); const t = await chrome.tabs.get(postTab).catch(() => null); if (t && /facebook\.com/.test(t.url || '')) { await closeWorkTab(postTab); hideWork(); } })();
  const { listings = [] } = await chrome.storage.local.get('listings');
  const l = listings.find((x) => x.id === id);
  if (l) { l.status = 'posted'; l.postedAt = Date.now(); await chrome.storage.local.set({ listings }); }
  const { composerTabs = {} } = await chrome.storage.local.get('composerTabs');
  for (const k of Object.keys(composerTabs)) if (composerTabs[k].id === id || Date.now() - composerTabs[k].at > 3 * 3600 * 1000) delete composerTabs[k];
  await chrome.storage.local.set({ composerTabs });
  // A minute later, quietly sync so the new listing shows as Active with its Facebook id.
  chrome.alarms.create('syncAfterPost', { delayInMinutes: 1.5 });
  // Then list it in your chosen groups, if that's turned on.
  const { settings = {} } = await chrome.storage.local.get('settings');
  if (l && settings.groupAuto && (settings.groups || []).length) {
    const { groupQueue = [] } = await chrome.storage.local.get('groupQueue');
    groupQueue.push({ title: `${l.fb.year} ${l.fb.make} ${l.fb.model}`.replace(/\s+/g, ' ').trim(), price: l.fb.price, at: Date.now() });
    await chrome.storage.local.set({ groupQueue });
    chrome.alarms.create('groupPost', { delayInMinutes: 4 });
  }
  return {};
}

// One car at a time, a few minutes apart, so group posts don't come in a burst.
async function groupPostTick() {
  const { groupQueue = [], settings = {} } = await chrome.storage.local.get(['groupQueue', 'settings']);
  const next = groupQueue.shift();
  await chrome.storage.local.set({ groupQueue });
  const groups = next && (next.groups || settings.groups || []);
  if (next && groups.length) {
    const { jobId } = await startFbJob({ job: { kind: 'groupsPost', title: next.title, price: next.price, groups, quiet: true } }, {});
    const { groupQueueInfo = {} } = await chrome.storage.local.get('groupQueueInfo');
    await chrome.storage.local.set({ groupQueueInfo: { ...groupQueueInfo, current: next.title, waiting: groupQueue.length, jobId } });
  } else {
    await chrome.storage.local.set({ groupQueueInfo: { waiting: groupQueue.length } });
  }
  if (groupQueue.length) chrome.alarms.create('groupPost', { delayInMinutes: 5 + Math.random() * 5 });
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'groupPost') groupPostTick(); });

// ---------- dealer website watch: prices follow the website; cars that left get flagged ----------
// Every 3 hours (8am to 8pm) read each live car's dealer page directly (no tab). If the website
// price changed, update the car and, if it's on, the Facebook post (one at a time). If the car is
// gone from the website, flag it on the dashboard (you decide whether it sold).
chrome.alarms.create('dealerWatch', { periodInMinutes: 180, delayInMinutes: 3 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'dealerWatch') dealerWatch(); });
async function dealerWatch(force = false) {
  const h = new Date().getHours();
  if (!force && (h < 8 || h >= 20)) return { checked: 0 };
  const { listings = [], fbListings = [], settings = {} } = await chrome.storage.local.get(['listings', 'fbListings', 'settings']);
  const live = listings.filter((l) => l.raw && l.raw.sourceUrl && fbListings.some((f) => (f.status || 'Active') !== 'Sold' && LHShared.sameCar(l, f)));
  const changes = [], gone = [];
  for (const l of live) {
    const facts = await htmlFacts(l.raw.sourceUrl);
    await sleep(1500 + Math.random() * 2000);
    if (!facts) continue;
    if (facts.gone) { if (!l.dealerGone) { l.dealerGone = Date.now(); gone.push(l); } continue; }
    l.dealerGone = 0;
    if (facts.price && Number(facts.price) !== Number(l.fb.price)) {
      const f = fbListings.find((x) => (x.status || 'Active') !== 'Sold' && LHShared.sameCar(l, x));
      l.priceHistory = [...(l.priceHistory || []), { at: Date.now(), from: Number(l.fb.price), to: Number(facts.price) }].slice(-20);
      l.fb.price = Number(facts.price); l.raw.price = Number(facts.price); l.updatedAt = Date.now();
      changes.push({ l, f });
    }
  }
  await chrome.storage.local.set({ listings, dealerWatchAt: Date.now(), dealerNews: { at: Date.now(), prices: changes.map(({ l }) => ({ id: l.id, title: `${l.fb.year} ${l.fb.make} ${l.fb.model}`, ...l.priceHistory[l.priceHistory.length - 1] })), gone: gone.map((l) => ({ id: l.id, title: `${l.fb.year} ${l.fb.make} ${l.fb.model}` })) } });
  // Facebook follows the website (a lower price also re-shows the post to people who saved it).
  if (settings.matchDealerPrice !== false) {
    for (const { l, f } of changes) {
      if (!f) continue;
      const { jobId } = await startFbJob({ job: { kind: 'price', title: f.title, price: f.price, id: f.id || '', newPrice: l.fb.price, quiet: true } }, {});
      await watchJob(jobId, 600000);
      await sleep(20000 + Math.random() * 40000);
    }
  }
  return { checked: live.length, prices: changes.length, gone: gone.length };
}

// Re-list fresh: take a slow, old post down and post the car again as new (at most once a month per car).
async function relist({ id }) {
  const { listings = [], fbListings = [] } = await chrome.storage.local.get(['listings', 'fbListings']);
  const l = listings.find((x) => x.id === id);
  if (!l) throw new Error('That car is not in the app');
  if (l.relistedAt && Date.now() - l.relistedAt < 30 * DAY) throw new Error(`Already re-listed on ${new Date(l.relistedAt).toLocaleDateString()}. Once a month per car keeps it from looking like spam`);
  const f = fbListings.find((x) => (x.status || 'Active') === 'Active' && LHShared.sameCar(l, x));
  if (!f) throw new Error('No active Facebook post found for this car');
  const { jobId } = await startFbJob({ job: { kind: 'action', action: 'delete', title: f.title, price: f.price, quiet: true } }, {});
  const r = await watchJob(jobId, 600000);
  if (!r.ok) throw new Error(`Couldn't take the old post down: ${r.error}`);
  const fresh = (await chrome.storage.local.get('listings')).listings || [];
  const car = fresh.find((x) => x.id === id);
  car.status = 'draft'; car.relistedAt = Date.now();
  await chrome.storage.local.set({ listings: fresh });
  const q = await openComposer({ ids: [id] });
  return { message: 'Old post taken down; the car is lined up to post fresh', queue: q.queue };
}

// ---------- live sync ----------
// Every few minutes (Settings, default 15) between 8am and 9pm, quietly read your listings
// in the hidden work window, so prices, status, clicks and sold cars stay current.
chrome.alarms.create('liveSync', { periodInMinutes: 5, delayInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'liveSync') liveSyncTick(); });
async function liveSyncTick() {
  const { settings = {}, fbSyncedAt = 0, fbJobs = {} } = await chrome.storage.local.get(['settings', 'fbSyncedAt', 'fbJobs']);
  const every = settings.liveSyncMin === undefined ? 15 : Number(settings.liveSyncMin);
  if (!every) return;
  const h = new Date().getHours();
  if (h < 8 || h >= 21) return;
  if (Date.now() - fbSyncedAt < (every - 1) * 60000) return;
  if (Object.values(fbJobs).some((j) => Date.now() - j.at < 10 * 60000)) return; // something else is on Facebook right now
  await startFbJob({ job: { kind: 'sync', quiet: true } }, {}).catch(() => {});
}
// Several live posts at once (dashboard "List all in groups"): one car every 5 to 10 minutes.
async function queueGroups({ items }) {
  const { groupQueue = [] } = await chrome.storage.local.get('groupQueue');
  for (const it of items || []) if (!groupQueue.some((q) => q.title === it.title && String(q.price) === String(it.price))) groupQueue.push({ ...it, at: Date.now() });
  await chrome.storage.local.set({ groupQueue, groupQueueInfo: { waiting: groupQueue.length } });
  const a = await chrome.alarms.get('groupPost');
  if (!a) chrome.alarms.create('groupPost', { delayInMinutes: 0.1 });
  return { waiting: groupQueue.length };
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'syncAfterPost') startFbJob({ job: { kind: 'sync', quiet: true } }, {}).catch(() => {}); });

// ---------- auto renew ----------
// Once a day between 9am and 7pm, renew every car listing Facebook says is ready.
async function waitJob(jobId, timeoutMs) {
  return watchJob(jobId, Math.max(timeoutMs, 900000));
}

async function renewNow({ titles } = {}) {
  const { jobId } = await startFbJob({ job: { kind: 'renew', carsOnly: true, titles: titles || null } }, {});
  const r = await waitJob(jobId, 400000);
  const lastRenew = { at: Date.now(), ok: !!r.ok, renewed: r.renewed || [], error: r.ok ? '' : r.error || '' };
  await chrome.storage.local.set({ lastRenew });
  if (!r.ok) throw new Error(r.error);
  return lastRenew;
}

async function autoRenewTick() {
  const { settings = {}, lastRenew } = await chrome.storage.local.get(['settings', 'lastRenew']);
  if (!settings.autoRenew) return;
  const h = new Date().getHours();
  // Renewed posts go back to the top: do it when the most people are browsing.
  if (settings.busyTimes !== false ? !LHShared.isBusyTime() : h < 9 || h >= 19) return;
  if (lastRenew && Date.now() - lastRenew.at < 20 * 3600 * 1000) return;
  try { await renewNow(); } catch (e) {}
}
chrome.alarms.create('autoRenew', { periodInMinutes: 60, delayInMinutes: 2 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'autoRenew') autoRenewTick(); });

const handlers = { sellingWorked, relist, dealerWatch: async () => dealerWatch(true), needYou, reveal: async ({ tabId }) => { await reveal(tabId); return {}; }, openWork: async ({ url }) => { const t = await openWork(url); return { tabId: t.id }; }, queueGroups, isAppTab, jobBeat, jobStatus, cancelPostQueue, extractFromTab, extractFromUrl, extractCarfax, listVehicleLinks, fetchImage, openComposer, myListing, startFbJob, myJob, jobDone, cancelJob, markPosted, passiveSync, showMe, renewNow: async (m) => ({ result: await renewNow(m) }), cloudSyncNow: async () => { await LHCloudSync.syncOnce(); return {}; } };

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const h = msg && handlers[msg.type];
  if (!h) return false;
  h(msg, sender).then(
    (r) => sendResponse({ ok: true, ...r }),
    (e) => sendResponse({ ok: false, error: String((e && e.message) || e) })
  );
  return true;
});
