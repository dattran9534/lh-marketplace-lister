/* PC side of the phone sync (runs in the extension's background worker).
 * Every minute, and a few seconds after any change:
 *  - sends your cars, your own photos and your Facebook listings to the cloud
 *  - brings in what you changed on the phone (prices, photos, descriptions)
 *  - does what you asked for on the phone (change price, mark sold, post...) */
(function () {
  const local = {
    get: async (k) => (await chrome.storage.local.get(k))[k],
    set: async (k, v) => chrome.storage.local.set({ [k]: v }),
  };

  async function cloud() {
    const { settings = {} } = await chrome.storage.local.get('settings');
    if (!settings.cloudUrl || !settings.cloudKey) return null;
    const c = LHCloud({ url: settings.cloudUrl, key: settings.cloudKey, store: local });
    return (await c.user()) ? c : null;
  }

  const fp = LHCloud.fingerprint;
  const iso = (t) => new Date(t || Date.now()).toISOString();

  // ---------- Facebook jobs started from the phone ----------
  async function runFbJob(job, timeoutMs = 150000) {
    const { jobId } = await startFbJob({ job }, {});
    const r = await watchJob(jobId, 900000, (step, s) => {
      // Show it on the phone, e.g. "Waiting for Facebook login on the PC".
      if (currentCmd) c0 && c0.db.update('commands', { id: currentCmd.id }, { result: s.login ? 'Facebook needs you to log in on the PC. It will carry on by itself after you log in.' : `On Facebook: ${step}…` }).catch(() => {});
    });
    if (!r.ok && r.code) throw new Error(r.error + (r.code === 'login' || r.code === 'checkpoint' ? '' : ' Tap Try again.'));
    return r;
  }

  async function setLocalPrice(vehicleId, price) {
    if (!vehicleId) return;
    const { listings = [] } = await chrome.storage.local.get('listings');
    const l = listings.find((x) => x.id === vehicleId);
    if (l) { l.fb.price = price; l.updatedAt = Date.now(); await chrome.storage.local.set({ listings }); }
  }

  const COMMANDS = {
    async price(p) {
      if (p.title) {
        const r = await runFbJob({ kind: 'price', title: p.title, price: p.price, id: p.fbId || '', newPrice: p.newPrice });
        if (!r.ok) throw new Error(r.error);
        const { fbListings = [] } = await chrome.storage.local.get('fbListings');
        const f = fbListings.find((x) => x.title === p.title && x.listedOn === p.listedOn);
        if (f) { f.price = p.newPrice; await chrome.storage.local.set({ fbListings }); }
      }
      await setLocalPrice(p.vehicleId, p.newPrice);
      return `Price is now $${Number(p.newPrice).toLocaleString('en-US')}`;
    },
    async groupsCheck(p) {
      const r = await runFbJob({ kind: 'groupsCheck', items: [{ title: p.title, price: p.price }] }, 240000);
      if (!r.ok) throw new Error(r.error);
      const names = Object.values(r.inGroups || {})[0] || [];
      return names.length ? `In ${names.length} group${names.length === 1 ? '' : 's'}: ${names.join(', ')}` : 'Facebook shows it in no groups';
    },
    async groupsAll(p) {
      const { fbListings = [], settings = {} } = await chrome.storage.local.get(['fbListings', 'settings']);
      const groups = (p.groups && p.groups.length ? p.groups : settings.groups) || [];
      if (!groups.length) throw new Error('No groups picked');
      const items = fbListings.filter((f) => (f.status || 'Active') === 'Active' && /^\d{4}\s/.test(f.title || ''))
        .map((f) => ({ title: f.title, price: f.price, groups: groups.filter((g) => !(f.groups || []).includes(g)) })).filter((x) => x.groups.length);
      if (!items.length) return 'Your active posts are already in those groups';
      const r = await queueGroups({ items });
      return `${items.length} post${items.length === 1 ? '' : 's'} lined up. One car goes every 5 to 10 minutes (${r.waiting} waiting)`;
    },
    async groups(p) {
      const { settings = {} } = await chrome.storage.local.get('settings');
      const groups = (p.groups && p.groups.length ? p.groups : settings.groups) || [];
      if (!groups.length) throw new Error('No groups picked yet. Sync your groups on the PC (Settings → Facebook groups), then pick them here');
      const r = await runFbJob({ kind: 'groupsPost', title: p.title, price: p.price, groups }, 360000);
      if (!r.ok) throw new Error(r.error);
      return r.message || 'Listed in your groups';
    },
    async action(p) {
      const r = await runFbJob({ kind: 'action', action: p.action, title: p.title, price: p.price });
      if (!r.ok) throw new Error(r.error);
      if (p.action === 'delete' && p.vehicleId) {
        const { listings = [] } = await chrome.storage.local.get('listings');
        const l = listings.find((x) => x.id === p.vehicleId);
        if (l) { l.status = 'draft'; await chrome.storage.local.set({ listings }); }
      }
      return { sold: 'Marked as sold', pending: 'Marked as pending', available: 'Back on the market', delete: 'Deleted from Facebook' }[p.action] || 'Done';
    },
    // Replace a live listing's photos with the car's current selection
    // (the phone's latest edits were pulled in just before this runs).
    async photos(p) {
      const { listings = [], settings = {} } = await chrome.storage.local.get(['listings', 'settings']);
      const l = listings.find((x) => x.id === p.vehicleId);
      if (!l) throw new Error('That car is not on the PC yet');
      const images = (l.images || []).filter((i) => i.on).slice(0, settings.maxPhotos || 20)
        .map(({ url, fallback, local, cloud, cropTop }) => ({ url, fallback, local, cloud, cropTop }));
      if (!images.length) throw new Error('No photos are selected for this car');
      const r = await runFbJob({ kind: 'photos', title: p.title, price: p.price, id: p.fbId || '', images }, 240000);
      if (!r.ok) throw new Error(r.error);
      return `Photos updated on Facebook (${r.message || images.length + ' photos'})`;
    },
    async post(p) {
      const { listings = [] } = await chrome.storage.local.get('listings');
      const l = listings.find((x) => x.id === p.vehicleId);
      if (!l) throw new Error('That car is not on the PC yet');
      const on = (l.images || []).filter((i) => i.on);
      if (on.length && on.every((i) => /stock_images|stockphoto|\/stock\//i.test(i.url || ''))) throw new Error("Only the dealer's generic catalog photo so far. Add your own photos first");
      const { fbListings = [] } = await chrome.storage.local.get('fbListings');
      const n = (s) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const dupe = fbListings.find((f) => (f.status === 'Active' || f.status === 'Pending') && LHShared.sameCar(l, f));
      if (dupe && !p.force) throw new Error(`Already on Facebook as "${dupe.title}" (${dupe.status}). Posting the same car twice gets flagged as spam`);
      l.status = l.status === 'posted' ? 'posted' : 'opened';
      await chrome.storage.local.set({ listings });
      const r = await openComposer({ ids: [p.vehicleId] });
      const q = r && r.queue;
      if (q && q.waiting) {
        const mins = Math.max(1, Math.round((q.nextAt - Date.now()) / 60000));
        return `In the posting line (${q.waiting} waiting, next in about ${mins >= 60 ? Math.round(mins / 60) + ' hr' : mins + ' min'}${q.why === 'daily limit' ? ', daily limit reached' : q.why === 'busy hours' ? ', held for busy Marketplace hours' : ''})`;
      }
      const { settings = {} } = await chrome.storage.local.get('settings');
      return settings.autoPost ? 'Posting on your PC (Auto post will publish it)' : 'Opened on your PC, waiting for you to publish';
    },
    async renew() {
      const r = await renewNow({});
      return r.renewed.length ? `Renewed ${r.renewed.length}: ${r.renewed.join(', ')}` : 'Nothing was ready to renew yet (Facebook allows it about once a week per listing)';
    },
    async sync() {
      const r = await runFbJob({ kind: 'sync' });
      if (!r.ok) throw new Error(r.error);
      return 'Synced with Facebook';
    },
    // Importing needs the full app (CARFAX, photos, AI), so open it in a background tab.
    // Swap a car's photos for the dealer website photos (and on Facebook); needs the full app.
    // Put the car's current description on its live Facebook post.
    async desc(p) {
      const { listings = [], fbListings = [] } = await chrome.storage.local.get(['listings', 'fbListings']);
      const l = listings.find((x) => x.id === p.vehicleId);
      if (!l) throw new Error('That car is not on the PC yet');
      const r = await runFbJob({ kind: 'desc', title: p.title, price: p.price, id: p.fbId || '', description: l.fb.description }, 240000);
      if (!r.ok) throw new Error(r.error);
      return 'Description updated on Facebook';
    },
    async relist(p) {
      const r = await relist({ id: p.vehicleId });
      return r.message;
    },
    async heroTest(p, cmd) {
      const tab = await openWork(chrome.runtime.getURL(`app.html?cmd=${cmd.id}&heroTest=${encodeURIComponent(p.vehicleId)}`));
      const { cmdTabs = {} } = await chrome.storage.local.get('cmdTabs');
      cmdTabs[cmd.id] = { tabId: tab.id, at: Date.now() };
      await chrome.storage.local.set({ cmdTabs });
      return { keepRunning: true };
    },
    async rewrite(p, cmd) {
      const tab = await openWork(chrome.runtime.getURL(`app.html?cmd=${cmd.id}&rewrite=${encodeURIComponent(p.vehicleId)}`));
      const { cmdTabs = {} } = await chrome.storage.local.get('cmdTabs');
      cmdTabs[cmd.id] = { tabId: tab.id, at: Date.now() };
      await chrome.storage.local.set({ cmdTabs });
      return { keepRunning: true };
    },
    async dealerPhotos(p, cmd) {
      const tab = await openWork(chrome.runtime.getURL(`app.html?cmd=${cmd.id}&dealerPhotos=${encodeURIComponent(p.vehicleId)}`));
      const { cmdTabs = {} } = await chrome.storage.local.get('cmdTabs');
      cmdTabs[cmd.id] = { tabId: tab.id, at: Date.now() };
      await chrome.storage.local.set({ cmdTabs });
      return { keepRunning: true };
    },
    async import(p, cmd) {
      const tab = await openWork(chrome.runtime.getURL(`app.html?cmd=${cmd.id}&importUrl=${encodeURIComponent(p.url || 'manual')}`));
      const { cmdTabs = {} } = await chrome.storage.local.get('cmdTabs');
      cmdTabs[cmd.id] = { tabId: tab.id, at: Date.now() };
      await chrome.storage.local.set({ cmdTabs });
      return { keepRunning: true }; // the app tab marks it done
    },
  };

  // Requests left "running" by a closed tab, an extension update or a restart
  // would spin on the phone forever. Close them out with a clear message.
  const inFlight = new Set();
  async function sweepStuck(c) {
    const running = await c.db.select('commands', 'status=eq.running&order=created_at.asc&limit=20');
    if (!running || !running.length) return;
    const { cmdTabs = {} } = await chrome.storage.local.get('cmdTabs');
    for (const cmd of running) {
      if (inFlight.has(cmd.id)) continue;
      let alive = false;
      const t = cmdTabs[cmd.id];
      if ((cmd.kind === 'import' || cmd.kind === 'dealerPhotos' || cmd.kind === 'rewrite' || cmd.kind === 'heroTest') && t && Date.now() - t.at < 12 * 60000) alive = !!(await chrome.tabs.get(t.tabId).catch(() => null));
      if (alive) continue;
      delete cmdTabs[cmd.id];
      await c.db.update('commands', { id: cmd.id }, { status: 'failed', result: 'Stopped before it finished (the PC tab closed, Edge restarted, or the extension updated). Tap Try again.', done_at: iso() });
    }
    for (const k of Object.keys(cmdTabs)) if (Date.now() - cmdTabs[k].at > 30 * 60000) delete cmdTabs[k];
    await chrome.storage.local.set({ cmdTabs });
  }

  let currentCmd = null, c0 = null;
  async function runCommands(c) {
    c0 = c;
    await sweepStuck(c).catch(() => {});
    const queued = await c.db.select('commands', 'status=eq.queued&order=created_at.asc&limit=5');
    for (const cmd of queued || []) {
      const STEP = { price: 'Changing the price on Facebook…', action: 'Updating the listing on Facebook…', photos: 'Uploading photos to Facebook…', post: 'Opening Facebook…', sync: 'Syncing with Facebook…', renew: 'Renewing listings on Facebook…', import: 'Starting the import…', groups: 'Listing in your groups on Facebook…', dealerPhotos: 'Getting the dealer website photos…', groupsAll: 'Lining up your posts for groups…', rewrite: 'Writing a new description…', groupsCheck: 'Checking groups on Facebook…', desc: 'Updating the description on Facebook…', relist: 'Re-listing fresh…', heroTest: 'Trying a new first photo…' };
      await c.db.update('commands', { id: cmd.id }, { status: 'running', result: STEP[cmd.kind] || 'Working on it…' });
      try {
        inFlight.add(cmd.id);
        currentCmd = cmd;
        const fn = COMMANDS[cmd.kind];
        if (!fn) throw new Error(`Unknown request "${cmd.kind}"`);
        const res = await fn(cmd.payload || {}, cmd);
        if (res && res.keepRunning) continue;
        await c.db.update('commands', { id: cmd.id }, { status: 'done', result: String(res || 'Done'), done_at: iso() });
      } catch (e) {
        await c.db.update('commands', { id: cmd.id }, { status: 'failed', result: e.message || String(e), done_at: iso() });
      } finally {
        inFlight.delete(cmd.id);
      }
    }
  }

  // ---------- two way sync ----------
  async function uploadOwnPhotos(c, uid, listings) {
    let changed = false;
    for (const l of listings) {
      for (const im of l.images || []) {
        if (!im.local || im.cloud) continue;
        const blob = await LHLocal.get(im.local).catch(() => null);
        if (!blob) continue;
        im.cloud = await c.photos.upload(`${uid}/${l.id}/${im.local}.jpg`, blob);
        changed = true;
      }
    }
    return changed;
  }

  async function syncSwitches(c) {
    const { settings = {} } = await chrome.storage.local.get('settings');
    const remote = await c.account.get().catch(() => null);
    const localAt = settings.switchesAt || 0;
    if (remote && remote.at > localAt) {
      settings.autoPost = !!remote.autoPost;
      settings.autoRenew = !!remote.autoRenew;
      settings.switchesAt = remote.at;
      await chrome.storage.local.set({ settings });
    } else if (!remote || localAt > remote.at || remote.autoPost !== !!settings.autoPost || remote.autoRenew !== !!settings.autoRenew) {
      const at = localAt || Date.now();
      await c.account.set({ autoPost: !!settings.autoPost, autoRenew: !!settings.autoRenew, at });
      if (!localAt) { settings.switchesAt = at; await chrome.storage.local.set({ settings }); }
    }
  }

  // Your Facebook groups and the ones you picked, shared with the phone (newest pick wins).
  async function syncGroups(c) {
    const { settings = {}, fbGroups = [], groupsFp = '' } = await chrome.storage.local.get(['settings', 'fbGroups', 'groupsFp']);
    const remote = await c.account.getKey('lhGroups').catch(() => null);
    const localAt = settings.groupsAt || 0;
    if (remote && remote.at > localAt) {
      settings.groups = remote.chosen || [];
      settings.groupAuto = !!remote.auto;
      settings.groupsAt = remote.at;
      await chrome.storage.local.set({ settings });
    }
    const mine = { list: fbGroups.map((g) => g.name), chosen: settings.groups || [], auto: !!settings.groupAuto, at: settings.groupsAt || localAt || Date.now() };
    const f = fp(mine);
    if (f !== groupsFp && (!remote || fp(remote) !== f)) { await c.account.setKey('lhGroups', mine); }
    await chrome.storage.local.set({ groupsFp: f });
  }

  let running = false, again = false;
  async function syncOnce() {
    if (running) { again = true; return; }
    running = true;
    try {
      do { again = false; await syncSteps(); } while (again);
    } finally { running = false; }
    listen().catch(() => {});
  }

  // ---------- instant pickup: live connection to the phone ----------
  // The phone sends a "cmd" ping after each request; this hears it within a second.
  let ws = null, wsUid = '', wsAt = 0, hb = null, ref = 0;
  function wsSend(topic, event, payload) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ topic, event, payload, ref: String(++ref) }));
  }
  async function listen() {
    const c = await cloud();
    if (!c) { if (ws) ws.close(); return; }
    const u = await c.user();
    const topic = `realtime:lh-${u.id}`;
    if (ws && ws.readyState <= 1 && wsUid === u.id) {
      // Logins last an hour: hand the live connection a fresh one every 40 minutes.
      if (Date.now() - wsAt > 40 * 60000) { wsAt = Date.now(); wsSend(topic, 'access_token', { access_token: await c.token() }); }
      return;
    }
    if (ws) try { ws.close(); } catch (e) {}
    const { settings = {} } = await chrome.storage.local.get('settings');
    const token = await c.token();
    const sock = new WebSocket(`${settings.cloudUrl.replace(/\/+$/, '').replace(/^http/, 'ws')}/realtime/v1/websocket?apikey=${encodeURIComponent(settings.cloudKey)}&vsn=1.0.0`);
    ws = sock; wsUid = u.id; wsAt = Date.now();
    sock.onopen = () => {
      wsSend(topic, 'phx_join', { config: { broadcast: { self: false, ack: false }, presence: { key: '' }, private: false }, access_token: token });
      clearInterval(hb);
      hb = setInterval(() => wsSend('phoenix', 'heartbeat', {}), 20000); // also keeps the PC side awake
    };
    sock.onmessage = (e) => {
      let m; try { m = JSON.parse(e.data); } catch (x) { return; }
      if (m.event === 'broadcast') syncOnce();
    };
    sock.onclose = () => { if (ws === sock) { ws = null; clearInterval(hb); } };
    sock.onerror = () => {};
  }
  async function syncSteps() {
    try {
      const c = await cloud();
      if (!c) return;
      const uid = (await c.user()).id;
      const st = await chrome.storage.local.get(['listings', 'fbListings', 'fbSyncedAt', 'cloudFp', 'cloudPull']);
      let listings = st.listings || [];
      const sent = st.cloudFp || {};

      // 1. Bring in phone edits first, so they aren't overwritten.
      const since = st.cloudPull || '1970-01-01T00:00:00Z';
      const fromPhone = await c.db.select('vehicles', `updated_by=eq.phone&updated_at=gt.${encodeURIComponent(since)}&order=updated_at.asc`);
      let newest = since, pulled = false;
      for (const row of fromPhone || []) {
        newest = row.updated_at > newest ? row.updated_at : newest;
        const i = listings.findIndex((l) => l.id === row.id);
        if (row.deleted) { if (i >= 0) listings.splice(i, 1); delete sent[row.id]; }
        else if (i >= 0) listings[i] = row.data; else listings.unshift(row.data);
        if (!row.deleted) sent[row.id] = fp(row.data);
        pulled = true;
      }

      // 2. Send your own photos, then any car that changed on the PC.
      const photosAdded = await uploadOwnPhotos(c, uid, listings);
      if (pulled || photosAdded) await chrome.storage.local.set({ listings });
      const changed = listings.filter((l) => sent[l.id] !== fp(l));
      if (changed.length) {
        await c.db.upsert('vehicles', changed.map((l) => ({ id: l.id, user_id: uid, data: l, updated_at: iso(), updated_by: 'pc', deleted: false })), 'user_id,id');
        changed.forEach((l) => (sent[l.id] = fp(l)));
      }
      // Cars deleted on the PC.
      const gone = Object.keys(sent).filter((id) => !listings.some((l) => l.id === id));
      if (gone.length) {
        await c.db.upsert('vehicles', gone.map((id) => ({ id, user_id: uid, data: {}, updated_at: iso(), updated_by: 'pc', deleted: true })), 'user_id,id');
        gone.forEach((id) => delete sent[id]);
      }

      // 3. Facebook listings + "PC is online" heartbeat.
      const fbList = st.fbListings || [];
      const row = { user_id: uid, pc_seen_at: iso() };
      if (sent.__fb !== fp(fbList)) { row.listings = fbList; row.synced_at = iso(st.fbSyncedAt); sent.__fb = fp(fbList); }
      await c.db.upsert('fb_state', [row], 'user_id');

      await chrome.storage.local.set({ cloudFp: sent, cloudPull: newest, cloudLastSync: Date.now(), cloudError: '' });

      // 4. Auto post / Auto renew switches, shared with the phone (newest change wins).
      await syncSwitches(c);
      await syncGroups(c).catch(() => {});

    } catch (e) {
      await chrome.storage.local.set({ cloudError: e.message || String(e) });
    }
    // 5. Phone requests: always handled, even if a sync step above failed.
    try {
      const c = await cloud();
      if (c) {
        await c.db.upsert('fb_state', [{ user_id: (await c.user()).id, pc_seen_at: iso() }], 'user_id').catch(() => {});
        await runCommands(c);
      }
    } catch (e) {
      await chrome.storage.local.set({ cloudError: e.message || String(e) });
    }
  }

  chrome.alarms.create('cloudSync', { periodInMinutes: 0.5 });
  chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'cloudSync') syncOnce(); });

  // A few seconds after anything changes on the PC.
  let timer = null;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !(ch.listings || ch.fbListings)) return;
    clearTimeout(timer);
    timer = setTimeout(syncOnce, 4000);
  });

  self.LHCloudSync = { syncOnce };
})();
